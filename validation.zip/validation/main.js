
// 	var modalConfirm = function(callback){
  
//   $("#btn-confirm").on("click", function(){
//     $("#mi-modal").modal('show');
//   });

//   $("#modal-btn-si").on("click", function(){
//     callback(true);
//     $("#mi-modal").modal('hide');
//   });
  
//   $("#modal-btn-no").on("click", function(){
//     callback(false);
//     $("#mi-modal").modal('hide');
//   });
// }

$("form[name='addtask']").validate({

    rules: {
        taskName: {
            required: true,
        },
        description: {
            required: true,
        },
        priority:"required",
    },
    messages: {
        taskName: {
            required: "Task Name Required",
        },
        description: {
            required: "Description Required",
        },
        priority:"Select Priority",        
    },

    submitHandler: function(form) {
        form.submit();
    }
});

