//carousel

var index = 1;
show(index);

function next(img) {
  show(index += img);
}
function show(img) {
  var i;
  var x = $(".banner-img");
  if (img > x.length) {index = 1}    
  if (img < 1) {index = x.length}
  for (i = 0; i < x.length; i++) {
  	$(x[i]).hide();  
  }
  $(x[index-1]).fadeIn();  
}