$(document).ready(function(){
	total_products = $("#products li").size();
	x=6;
	$('#products li:lt('+x+')').show();
	$('#more-product-btn').click(function() {
		x= (x+6 <= total_products) ? x+6 : total_products;
		$('#products li:lt('+x+')').show();
		if(x>=total_products){
			$(this).css('display','none');
		}
	});
	if(total_products<=6){
		$('#more-product-btn').css('display','none');
	}
});