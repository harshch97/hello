$(document).ready(function(){
	var minValue=parseInt($("#minPrice").val());
    var maxValue=parseInt($("#maxPrice").val());
	$("#slider").slider({
		range: true,
		min: minValue,
		max: maxValue,
		values: [ minValue, maxValue ],
		slide: function( event, ui ) {
			$("#amount1").html(ui.values[0]);
			$("#amount2").html(ui.values[1]);
		},
		stop: function( event, ui ) {
			$("#slider").trigger("click");
		}
	});
});