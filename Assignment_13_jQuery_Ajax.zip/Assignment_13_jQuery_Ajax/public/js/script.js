$(document).ready(function(){
  	$("#cart").click(function(){
        $(".popover-data").slideToggle();
    });
    $("#stars li").click(function(){
    	$("#starVal").val(($(this).val()));
    });
    $(".product-block").click(function(e){
    	if(e.target.className!=="addToCart"){
    		var id=$(this).attr("title");
    		window.location=site_url+ 'product/detail/' + id;
    	}
    });
    $("#displayProduct").on("click",".product-block",function(e){
    	if(e.target.className!=="addToCart" && e.target.className!=="addToCart1"){
    		var id=$(this).attr("title");
    		window.location=site_url+ 'product/detail/' + id;
    	}
    });
    $("#menu li").click(function(e){
    	if(e.target.className=='submenu'){
    		$("#hidden-form").submit();
    	}
    });
    $(".qty-border").click(function () {
	    if (this.readOnly) {
	        $("#editMsg").html("Click on Edit to change quantity.");
	        $("#editAlert").slideDown("slow");
	    }
	});
    $("#reviewBtn").click(function(e){
    	var star=$("#starVal").val();
    	var msg=$("#message").val();
    	var id=$("#itemId").val();
    	var dataString="itemId=" + id + "&msg=" + msg + "&ratings=" + star;
    	$.ajax({
	        type: 'POST',
	        url: site_url+'product/addReview',
	        data: dataString,
	        success: function(response){
				var review = $.parseJSON(response);
				if(review.status==1){
					alert(review.msg);
				}else if(review.status==2){
					alert(review.msg);
				}
				else{
					$.each(review, function(i, val) {
						document.getElementById("new-title").innerHTML = val.firstname + ", " + val.review_date + " writes:";
						document.getElementById("new-review").innerHTML = val.review_text;
					});
				}
	        },
			error: function(response){
				alert("error : " + response);
			}
		});
		e.preventDefault();
	});
	$('#wishListBtn').click(function(e){
		var id=$("#itemId").val();
		var dataString="id=" + id;
		$.ajax({
			type: 'POST',
			url: site_url+'product/addToWishList',
			data: dataString,
			dataType : 'json',
			encode : true,
			success: function(response){
				var status=JSON.stringify(response);
				result = JSON.parse(status);
				if(result.status==1){
					swal({
						title:"",
						text:result.msg,
						imageUrl:assets_url + "images/warning.svg",
						confirmButtonColor: '#8A6D3B'
					});
				}
				else if(result.status==2){
					swal({
						title:"",
						text:result.msg,
						imageUrl:assets_url + "images/success.png",
						confirmButtonColor: '#428BCA'
					});
				}
			},
			error: function(response){
				alert(response);
			}
		});
	});
	$("#cart").popover({
	    html: true, 
		content: function() {
          	return $('#popover-content').html();
        }
	});
	$('body').click(function(e) {
		if(e.target.className !== "cart" && e.target.className !== "cart-a")
		{
			$('#popover-content').slideUp();
		}
	});
	$(".edit").click(function(){
		$("#editAlert").slideUp("slow");
		var editClassName="qty"+$(this).attr("title");
		$('.' + editClassName).attr("readonly", false);
		$('#' + editClassName).focus();
		$('.' + editClassName).css('background','#fff');
		$('.' + editClassName).css('font-weight','bold');
	});
	$('#country_ship').change(function()
	{
		var id=$(this).val();
		var dataString = 'id='+ id;
		$.ajax
		({
			type: "POST",
			url: site_url+'profile/fetchState',
			data: dataString,
			cache: false,
			success: function(data)
			{
				$("#state").empty();
				var state = $.parseJSON(data);
				$.each(state, function(i, val) {
					$("#state").append("<option value='" + val.id + "'>" + val.name + "</option>");
				});
			},
			error: function(){
				alert('error');
			}
		});
	});
	$('#country_bill').change(function()
	{
		var id=$(this).val();
		var dataString = 'id='+ id;
		$.ajax
		({
			type: "POST",
			url: site_url+'profile/fetchState',
			data: dataString,
			cache: false,
			success: function(data)
			{
				var state_bill = $.parseJSON(data);
				$("#state_bill").empty();
				$.each(state_bill, function(i, val) {
					$("#state_bill").append("<option value='" + val.id + "'>" + val.name + "</option>");
				});
			},
			error: function(){
				alert('error');
			}
		});
	});
	$('#cart').click(function() {
   		$('#popover-content').show();
	});
	$('#popover-content').click(function(event){
	   	event.stopPropagation();
	});
	$('.search,.search1,#search-btn').click(function(e) {
		$('.search-box').addClass('expanded');
		$("#search").focus();
  	});
	$('#search').on("keypress", function(e) {
		$("#searchText").show();
		if (e.keyCode == 13) {
			window.location=site_url + 'product/listing/' + $(this).val();
		}
	});
	$('body,html').click(function(e) {
		if(e.target.className!=='search1' && e.target.className!=='search' && e.target.id!=='search' && e.target.id!=='searchText' && e.target.id!=='subcategory'){
			$('.search-box').removeClass('expanded');
			$("#searchText").hide();
		}
  	});
	$("#searchText").hide();
  	$("body").click(function(){
  		if ($("#billing_address").is(':checked')){
			$("#street").keyup(function(){
				$("#street_bill").val($(this).val());
			});
			$("#city").keyup(function(){
				$("#city_bill").val($(this).val());
			});
			$("#country_ship").change(function(){
				$("#country_bill").val($(this).val());
				$('#country_bill').change();
			});
			$("#state").change(function(){
				var $options = $("#state > option").clone();
				$('#state_bill').empty();
			  	$('#state_bill').append($options);
			  	$('#state_bill').val($(this).val());
			});
		}
		else{
			$("#street").keyup(function(){
				$("#street_bill").val($("#street_bill").val());
			});
			$("#city").keyup(function(){
				$("#city_bill").val($("#city_bill").val());
			});
			$("#country_ship").change(function(){
				$("#country_bill").val($("#country_bill").val());
			});
			$("#state").change(function(){
				var $options = $("#state > option").clone();
				$('#state_bill').empty();
			  	$('#state_bill').append($options);
			  	$('#state_bill').val($('#state_bill').val());
			});
		}
  	});
  	$("#billing_address").click(function(){
	    var checkBox=document.getElementById("billing_address").checked;
	    if(checkBox==true){
		 	var $options = $("#state > option").clone();
		  	$('#state_bill').empty();
		  	$('#state_bill').append($options);
		  	$('#state_bill').val($('#state').val());
		  	$('#street_bill').attr("readonly", true);
		  	$('#city_bill').attr("readonly", true);
		  	$('#country_bill').attr("readonly", true);
		  	$('#state_bill').attr("readonly", true);
		}
		else{
	  		$('#country_bill').val();
	  		$('#state_bill').val();
	  		$('#street_bill').attr("readonly", false);
		  	$('#city_bill').attr("readonly", false);
		  	$('#country_bill').attr("readonly", false);
		  	$('#state_bill').attr("readonly", false);
		}
	});
  	$('#testimonial-carousel').carousel({
    	pause: true, interval: 5000,
  	});
	$('#topBtn').click(function(){
	    $('body,html').animate({
				scrollTop: 0
			}, 800);
		return false;
	});
	$('#myCarousel').carousel({
    	interval: 5000,
  	});
	imgCarousel();
	$(window).on('resize',function(){
		location.reload(true);
	});
	$('#thumbs img').click(function(){
		$('#largeImage').fadeOut(00);
	    $('#largeImage').attr('src',$(this).attr('src'));
	    $("#largeImage").data('zoom-image', $(this).data('zoom-image')).elevateZoom({
	  		borderSize:1,
			responsive: true,
   			zoomType: "lens",
   			lensShape:"round", 
   			containLensZoom: true
	    }); 
		$('#largeImage').fadeIn(1000);;
	});
	$('#stars li').on('mouseover', function(){
    	var onStar = parseInt($(this).data('value'), 10);
   
    	$(this).parent().children('li.star').each(function(e){
      		if (e < onStar) {
        		$(this).addClass('hover');
      		}
      		else {
        		$(this).removeClass('hover');
      		}
    	});
  	}).on('mouseout', function(){
	    $(this).parent().children('li.star').each(function(e){
	      	$(this).removeClass('hover');
	    });
  	});
  
	$('#stars li').on('click', function(){
		var onStar = parseInt($(this).data('value'), 10); 
		var stars = $(this).parent().children('li.star');

	    for (i = 0; i < stars.length; i++) {
	      	$(stars[i]).removeClass('selected');
	    }
	    for (i = 0; i < onStar; i++) {
	      	$(stars[i]).addClass('selected');
	    }
  	});
  	jQuery.validator.addMethod("lettersonly", function(value, element) {
	  	return this.optional(element) || /^[a-z]+$/i.test(value);
	}, "Letters only please"); 
  	jQuery.validator.addMethod("phone_regex", function(value, element) {
	  	return this.optional(element) || /^\d{10}$/i.test(value);
	}, "Enter valid phone number"); 
  	jQuery.validator.addMethod("usmobile", function(value, element) {
	  	return this.optional(element) || /^[+]\d{1}[ ]\d{3}[-]\d{3}[-]\d{3}$/i.test(value) || /^[+]\d{2}[ ]\d{10}$/i.test(value);
	}, "Enter valid number"); 
  	$("form[name='loginForm']").validate({
    	rules: {
    		username:{required:true,lettersonly: true},
    		password:"required"
    	},
    	messages:{
    		username:{required:"Please enter username!",lettersonly:"Please enter alphabets only"},
    		password:"Please enter password!"
    	},
    	submitHandler: function(form) {
     	 	form.submit();
    	}
	});
  	$("form[name='form1']").validate({
    	rules: {
    		street:"required",
    		city:"required",
    		country:"required",
    		state:"required"
    	},
    	messages:{
    		street:"Please select country!",
    		city:"Please select country!",
    		country:"Please select country!",
    		state:"Please select state!"
    	},
    	submitHandler: function(form) {
     	 	form.submit();
    	}
	});
	$("#login_btn").click(function(e){
      	$.ajax({
	        type: 'POST',
	        url: site_url+'login',
	        data: $('#loginForm').serialize(),
	        success: function(data){
				var response= $.parseJSON(data);
				if(response.status==0){
					$("#invalidAlert").show();
		        	document.getElementById("invalidMsg").innerHTML= response.msg;
		        	$('.modal-width').css('height','400px');
				}
				else if(response.status==1){
					$("#invalidAlert").hide();
					$("#successAlert").show();
		        	document.getElementById("successMsg").innerHTML= response.msg;
		        	$('.modal-width').css('height','400px');
					window.location = site_url+"profile";
				}
				else if(response.status==2){
					$("#invalidAlert").hide();
					$("#successAlert").show();
		        	document.getElementById("successMsg").innerHTML= response.msg;
		        	$('.modal-width').css('height','400px');
					window.location = site_url+"profile";
				}
	        },
			error: function(response){
				console.log(response);
			}
		});
      	e.preventDefault();
    });
    $("#logout").click(function(){
		swal({
			title: "",
			text: "Are you sure you want to <span style='color:#A94442'>Logout</span>?",
			imageUrl:assets_url + "images/error.svg",
			html: true,
			showCancelButton: true,
			confirmButtonColor: '#A94442',
			confirmButtonText: 'Yes, I am sure!',
			cancelButtonText: "No!",
			closeOnConfirm: false,
			closeOnCancel: true
		},
		function(isConfirm) {
			if (isConfirm) {
				swal({
					title: '',	
					text: 'Successfully logged out!',
					imageUrl:assets_url + "images/success.png",
					confirmButtonColor: '#428BCA'
			}, function() {
					window.location.href = site_url + 'logout'
 				});
			}
		});
	});
    $("#clear-cart").click(function(){
    	swal({
            title: "Are you sure you want to clear cart?",
            imageUrl:assets_url + "images/warning.svg",
            showCancelButton: true,
            confirmButtonColor: '#8A6D3B',
            confirmButtonText: 'Yes, I am sure!',
            cancelButtonText: "No!",
            closeOnConfirm: false,
            closeOnCancel: true
        },
        function(isConfirm) {
            if (isConfirm) {
                swal({
                    title: '',
					text: 'Cart is empty!',
					confirmButtonColor: '#428BCA',
					imageUrl:assets_url + "images/success.png"
                }, function() {
					window.location.href = site_url + 'cart/clearShoppingCart'
                });
            } 
        });
	});
	$("#registerUser").click(function(e){
		$("form[name='registrationForm']").validate({
			rules: {
				'register[username]':{required:true,lettersonly: true},
				'register[gender]':"required",
				'register[password]':"required",
				'register[confirm_password]':{equalTo : "#password_value"},
				'register[email]':{required:true,email:true},
				'register[firstName]':{required:true,lettersonly:true},
				'register[mobile]':{required:true},
				'register[lastName]':{required:true,lettersonly:true},
				'register[phone]':{phone_regex:true},
				mandatory:"required"
			},
			messages:{
				'register[username]':{required:"Please enter username!",lettersonly:"Please enter alphabets only"},
				'register[gender]':"Please select gender!",
				'register[password]':"Please enter password!",
				'register[confirm_password]':"Password doesn't match",
				'register[email]':{required:"Please enter email address",email:"Please enter valid email!"},
				'register[firstName]':{required:"Please enter first name",lettersonly:"Please enter alphabets only"},
				'register[mobile]':{required:"Please enter mobile number"},
				'register[lastName]':{required:"Please enter last name",lettersonly:"Please enter alphabets only"},
				mandatory:"Please agree with terms and mandatory!",
				errorElement : 'label',
				errorLabelContainer: '.errorMsg'
			},
			submitHandler: function(form) {
				$.ajax({
					type: 'POST',
					url: site_url+'register/registerUser',
					data: $('#registrationForm').serialize(),
					success: function(data){
						var response= $.parseJSON(data);
						if(response.status==1){
							$("#repeatAlert").hide();
							document.getElementById("successMsg").innerHTML= response.msg;
							$("#successAlert").slideDown(2000,function(){	
								window.location = site_url+"profile";
							});
						}
						else if(response.status==2){
							$("#repeatAlert").show();
							document.getElementById("repeatMsg").innerHTML = response.msg;
						}else if(response.status==3){
							document.getElementById("repeatMsg").innerHTML = response.msg;
							$("#repeatAlert").slideDown(1000,function(){	
								window.location = site_url+"profile";
							});
							document.getElementById("repeatMsg").innerHTML = response.msg;
						}else if(response.status==4){
							$("#repeatAlert").show();
							document.getElementById("repeatMsg").innerHTML = response.msg;
						}else if(response.status==5){
							var errors= $.parseJSON(response.error);
							$.each( errors, function( key, value ) {
								$("#" + key + "_error").html(value);
							});
						}
					},
					error: function(response){
						console.log(response);
					}
				});
				e.preventDefault();
			}
		});
	});
	$("#search").keyup(function(){
		var value=$(this).val();
		if(value==''){
			$("#searchText").css('display','none');
		}
		else{
			$("#searchText").css('display','block');
		}
		var dataString="term=" + value;
		$.ajax({
			type: 'POST',
			url: site_url + "product/allProductList",
			data: dataString,
			success: function(data){
				$("#searchText").html(data);
			}	
		});
	});
	$("#updateUser").click(function(e){
		$.ajax({
			type: 'POST',
			url: site_url + 'profile/updateProfile',
			data: $('#updateForm').serialize(),
			success: function(data){
				var response= $.parseJSON(data);
				if(response.status==1){
					$("#uniqAlert").hide();
					document.getElementById("updateMsg").innerHTML= response.msg;
					$("#updateAlert").show();
					document.getElementById("welcome-message").innerHTML=response.username;
				}
				else if(response.status==2){
					$("#updateAlert").hide();
					$("#uniqAlert").show();
					document.getElementById("uniqMsg").innerHTML= response.msg;
				}
			},
			error: function(response){
				console.log(response);
			}
		});
		e.preventDefault();
	});
	$("a .cancel-cart").click(function(e){
		e.preventDefault();
		var id=$(this).attr("title");
		var parent = $(this).parent().parent().parent();
		swal({
			title: "",
			text: "Are you sure you want to remove this item from cart?",
			imageUrl:assets_url + "images/error.svg",
			showCancelButton: true,
			confirmButtonColor: '#A94442',
			confirmButtonText: 'Yes, Remove this item!',
			cancelButtonText: "No!",
			closeOnConfirm: false,
			closeOnCancel: true
		},
		function(isConfirm) {
			if (!isConfirm) {return;}
			var dataString="id=" + id;
			$.ajax({
				type: 'POST',
				url: site_url+'cart/removeItem',
				data:  dataString,
				success: function(data){
					var response= $.parseJSON(data);
					$(function(){
						parent.fadeOut(1000,function() {
							parent.remove();
						});
					});
					if( response.status == 1 ){
						document.getElementById("popover-content").innerHTML=response.content;
						if(e.target.className!=='cancel-popup'){
							swal({
								title:"",
								text:response.msg,
								imageUrl:assets_url + "images/info.svg",
								confirmButtonColor: '#31708F'
							});
							document.getElementById("subtotal").innerHTML="$" + response.subtotal + ".00";
							document.getElementById("total").innerHTML="$" + response.subtotal + ".00";
						}
					}
					else if( response.status == 2 ){
						document.getElementById("popover-content").innerHTML="<h3 class='popover-title' id='popover-title'>No item(s) in cart</h3>";
						document.getElementById("removeItem").innerHTML= response.msg;
						swal({
							title:"",
							text:response.msg,
							imageUrl:assets_url + "images/info.svg",
							confirmButtonColor: '#31708F'
						});
						setTimeout(function(){
							window.location.replace(site_url + "/cart/clearShoppingCart");
						},2000);
					}
				},
				error: function(response){
					console.log(response);
				}
			});		
		});
	});
	$("#popover-content").on("click", "a .cancel-popup", function(e){
		e.preventDefault();
		var id=$(this).attr("title");
		var parent = $(this).parent().parent().parent();
		swal({
			title: "",
			text: "Are you sure you want to remove this item from cart?",
			imageUrl:assets_url + "images/error.svg",
			showCancelButton: true,
			confirmButtonColor: '#A94442',
			confirmButtonText: 'Yes, Remove this item!',
			cancelButtonText: "No!",
			closeOnConfirm: false,
			closeOnCancel: true
		},
		function(isConfirm) {
			if (!isConfirm) {return;}
			var dataString="id=" + id;
			$.ajax({
				type: 'POST',
				url: site_url+'cart/removeItem',
				data:  dataString,
				success: function(data){
					var response= $.parseJSON(data);
					if( response.status == 1 ){
						$(function(){
							parent.fadeOut(1000,function() {
								parent.remove();
							});
						});
						swal({
							title:"",
							text:response.msg,
							imageUrl:assets_url + "images/info.svg",
							confirmButtonColor: '#31708F'
						});
						document.getElementById("popover-content").innerHTML=response.content;
						if(e.target.className!=='cancel-popup'){
							document.getElementById("subtotal").innerHTML="$" + response.subtotal + ".00";
						}
					}
					else if( response.status == 2 ){
						swal({
							title:"",
							text:response.msg,
							imageUrl:assets_url + "images/info.svg",
							confirmButtonColor: '#31708F'
						});
						document.getElementById("popover-content").innerHTML="<h3 class='popover-title' id='popover-title'>No item(s) in cart</h3>";
					}
				},
				error: function(response){
					console.log(response);
				}
			});
		});
	});
	$("#resetBtn").click(function () {
		$(".color").attr('checked',false);
		$.each($(".color"), function(index,element){   
			var select=$(this).val();
			$(".color"+select).css('color','#333');
		});
		$(".size").attr('checked',false);
		displayAllProducts();
	});
	var minValue=parseInt($("#minPrice").val());
	var maxValue=parseInt($("#maxPrice").val());
	$(".color").click(function(){
		$.each($(".color:checked"), function(index,element){   
			var select=$(this).val();
			$(".color"+select).css('color','#a9a9a9');
		});
		$.each($(".color:unchecked"), function(index,element){   
			var select=$(this).val();
			$(".color"+select).css('color','#333');
		});
	});
	$('.size,.color,#slider,#sortby').click(function(e){
		var sortby=$("#sortby").val();
		var selectedSize=$(".size:checked").length;
		var selectedColor=$(".color:checked").length;
		var minValue=parseInt($("#minPrice").val());
		var maxValue=parseInt($("#maxPrice").val());
		var startingValue=document.getElementById("amount1").innerHTML;
		var endingValue=document.getElementById("amount2").innerHTML;

		if(sortby!=null){
			var sort='[{\"field\":' + '\"' + sortby + '\"' + '}]';
		}
		else{var sort=0;}
		if(selectedSize!=0){
			var sizeId = '[';
			$.each($(".size:checked"), function(index,element){            
				sizeId+='{\"id\":'+ '\"' + $(this).val() + '\"}';
				if(index!=selectedSize-1){
					sizeId += ',';
				}
			});
			sizeId+=']';
		}
		else{var sizeId=0;}
		if(selectedColor!=0){
			var colorId = '[';
			$.each($(".color:checked"), function(index,element){   
				colorId+='{\"id\":'+ '\"' + $(this).val() + '\"}';
				if(index!=selectedColor-1){
					colorId += ',';
				}
			});
			colorId+=']';
		}
		else{var colorId=0;}
		if(startingValue!=minValue || endingValue!=maxValue){
			var price='[{\"startRange\":' + '\"' + startingValue + '\"' + ',\"endRange\":' + '\"' + endingValue + '\"' + '}]';
		}
		else{
			var price='[{\"startRange\":' + '\"' + minValue + '\"' + ',\"endRange\":' + '\"' + maxValue + '\"' + '}]';
		}
		$.ajax({
			type: 'POST',
			url: site_url+'product/filterProducts',
			data: "sortBy=" + sort + "&productSize=" + sizeId + "&productColor=" + colorId + "&productPrice=" + price,
			beforeSend: function(){
				$("#displayProduct").hide();
				$("#notAvailableAlert").hide();
				$("#loading-image").show();
			},
			success: function(response){
				var filterData = $.parseJSON(response);
				if(filterData.rows==0){
					setTimeout(function() {
						$("#loading-image").hide();
						$("#loginAlert").hide();
						$("#insertAlert").hide();
						$("#displayProduct").hide();
						document.getElementById("notAvailableMsg").innerHTML="Product not available according to search.";
						document.getElementById("items").innerHTML=filterData.rows;
						$("#notAvailableAlert").show();
					},2000);
				}
				else{
					setTimeout(function() {
						$("#notAvailableAlert").hide();
						$("#loginAlert").hide();
						$("#displayProduct").show();
						$("#loading-image").hide();
						document.getElementById("displayProduct").innerHTML=filterData.content;
						document.getElementById("items").innerHTML=filterData.rows;
					},2000);
				}
			},
			error: function(response){
				console.log(response);
			}
		});
	});
	$('#subscriber-btn').click(function(){
		var email=$("#email").val();
		if(email!=''){
			if (validateEmail(email)) {
				var dataString="email=" + email;
				$.ajax({
					type: 'POST',
					url: site_url+'home/addSubscriber',
					data: dataString,
					success: function(data){
						var response= $.parseJSON(data);
						if(response.status == 0){
							document.getElementById("success_msg").style.color = "#ea4748";
							document.getElementById("success_msg").innerHTML= response.msg;
						}
						else if(response.status == 1) {
							document.getElementById("success_msg").style.color = "#badba1";
							document.getElementById("success_msg").innerHTML= response.msg;
						}
						else if(response.status == 2) {
							document.getElementById("success_msg").style.color = "#ea4748";
							document.getElementById("success_msg").innerHTML= response.msg;
						}
						else if(response.status == 3) {
							document.getElementById("success_msg").style.color = "#ea4748";
							document.getElementById("success_msg").innerHTML= response.msg;
						}
					},
					error: function(response){
						alert("error : " + response);
					}
				});
			}
			else{
				$("#success_msg").css('color','#ea4748');
				$("#success_msg").html('Please enter valid email id');
			}
		}
		else{
			$("#success_msg").html('Please enter email id');
			$("#success_msg").css('color','#ea4748');
		}
	});
	$('.addToCart').click(function(e){
		var id=$(this).attr("title");
		var dataString="itemId=" + id;
		$.ajax({
			type: 'POST',
			url: site_url+'home/addToCart',
			data: dataString,
			success: function(data){
				var response= $.parseJSON(data);
				if(response.status == 1){
					$("#loginAlert").slideDown(1000);
					$('#loginModal').modal('toggle');
					document.getElementById("loginMsg").innerHTML = response.msg;
				}
				else if(response.status == 2) {
					swal({
						title:"",
						text:response.msg,
						imageUrl:assets_url + "images/success.png",
						confirmButtonColor: '#428BCA'
					});
					document.getElementById("popover-content").innerHTML = response.content;
				}
			},
			error: function(response){
				alert("error : " + response);
			}
		});
	});
	$('#displayProduct').on("click",".addToCart1",function(e){
		var id=$(this).attr("title");
		var dataString="itemId=" + id;
		$.ajax({
			type: 'POST',
			url: site_url+'home/addToCart',
			data: dataString,
			success: function(data){
				var response= $.parseJSON(data);
				if(response.status==1){
					$("#loginAlert").slideDown(1000);
					document.getElementById("loginMsg").innerHTML= response.msg;
				}
				else if(response.status == 2) {
					swal({
						title:"",
						text:response.msg,
						imageUrl:assets_url + "images/success.png",
						confirmButtonColor: '#428BCA'
					});
					document.getElementById("popover-content").innerHTML=response.content;
				}
			},
			error: function(response){
				alert("error : " + response);
			}
		});
	});
	$("#update-cart,#update-shopping-cart").click(function(){
		var id=document.getElementsByName("itemId");
		var qty=document.getElementsByName("qty_js");
		var qtyArray,flag=0;

		qtyArray = '[';
		for(var i = 0; i < qty.length; i++) 
		{
			if(qty[i].value!=0){
				qtyArray += '{\"id\":'+ '\"' + id[i].value+ '\"' +',\"qty\":'+ '\"'+qty[i].value+ '\"'+'}';
				if(i!=qty.length-1){
					qtyArray += ',';
				}
			}
			else{
				flag=1;
				break;
			}
		}
		if(flag==1){
			alert("Quantity should be greate than or equal to 1.");
		}
		else{
			qtyArray += ']';
			$.ajax({
				type: 'POST',
				url: site_url+'cart/updateCart',
				data:  "dataString=" + qtyArray,
				success: function(data){
					var response= $.parseJSON(data);
					swal({
						title:"",
						text:response.msg,
						imageUrl:assets_url + "images/success.png",
						confirmButtonColor: '#428BCA'
					});
					document.getElementById("popover-content").innerHTML=response.content;
					document.getElementById("subtotal").innerHTML="$" + response.subtotal + ".00";
					document.getElementById("total").innerHTML="$" + response.subtotal + ".00";
					$('.qty-border').attr("readonly", true);
					$('.qty-border').css('background','#E8E8E8');
					$('.qty-border').css('font-weight','');
				},
				error: function(response){
					console.log(response);
				}
			});
		}
	});
});
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
	if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
		document.getElementById("topBtn").style.display = "block";
	} else {
		document.getElementById("topBtn").style.display = "none";
	}
}
function imgCarousel(){
	$('.img-carousel .item').each(function(){
		var next = $(this).next();
		if (!next.length) {
			next = $(this).siblings(':first');
		}
		next.children(':first-child').clone().appendTo($(this));
		if ($(window).width() < 768) {//alert('here');
			for (var i=0;i<1;i++) {
				next=next.next();
				if (!next.length) {
					next = $(this).siblings(':first');
					}
				next.children(':first-child').clone().appendTo($(this));
			}
		}
		else{
			for (var i=0;i<2;i++) {
				next=next.next();
				if (!next.length) {
					next = $(this).siblings(':first');
					}
				next.children(':first-child').clone().appendTo($(this));
			}
		}
	});
}
function displayAllProducts(){
	var category=$("#category-name").val();
	var sub_category=$("#sub-category-name").val();
	$.ajax({
		type: 'POST',
		url: site_url+'product/allProducts/' + category + "/" + sub_category,
		beforeSend: function(){
			$("#displayProduct").hide();
			$("#loading-image").show();
		},
		success: function(response){
			var filterData = $.parseJSON(response);
			setTimeout(function() {
				$("#displayProduct").show();
				$("#loading-image").hide();
				$("#notAvailableAlert").hide();
				$("#loginAlert").hide();
				document.getElementById("displayProduct").innerHTML=filterData.content;
				document.getElementById("items").innerHTML=filterData.rows;
			},800);
		},
		error: function(response){
			console.log(response);
		}
	});
}
function validateEmail(email){
	var filter = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
	if (filter.test(email)) {
		return true;
	}
	else {
		return false;
	}
}
function passwordValidate(password){
	var password = document.registrationForm.password;
	var capitalRegex="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	var digitRegex="0123456789";
	var charRegex="$!@#";
	var capital_count = 0; 
	var digit_count = 0;
	var character_count = 0;
	for(var x = 0; x < password.length ; x++)
	{
		if (capitalRegex.indexOf(password[x]) !== -1)
		{
			capital_count += 1;
		}
		else if(digitRegex.indexOf(password[x]) !== -1){
			digit_count += 1;
		}
		else if(charRegex.indexOf(password[x]) !== -1){
			character_count += 1;
		}
	}
	if(capital_count==2){
		if(digit_count>0){
			if( character_count>0){
				document.getElementById("password_error").innerHTML = "";
			}
			else{
				document.getElementById("password_error").innerHTML = "Password should be valid.";
				document.registrationForm.password.focus();
				return false;
			}
		}
		else{
			document.getElementById("password_error").innerHTML = "Password should be valid.";
			document.registrationForm.password.focus();
			return false;
		}
	}
	else{
		document.getElementById("password_error").innerHTML = "Password should be valid.";
		document.registrationForm.password.focus();
		return false;
	}
}
function billingValidation(){
	var street=document.getElementById("street");
	var city=document.getElementById("city");
	var country = document.getElementById("country_ship");
	var country_name = country.options[country.selectedIndex].value;
	var state=document.getElementById("state");
	var state_name = state.options[state.selectedIndex].value;
	var street_bill=document.getElementById("street_bill");
	var city_bill=document.getElementById("city_bill");
	var country_bill=document.getElementById("country_bill");
	var state_bill=document.getElementById("state_bill");
	if(street.value.length==0){
		document.getElementById("street_error").innerHTML = "Street should be filled.";
		street.focus();
		return false;
	}
	else{
		document.getElementById("street_error").innerHTML = "";
	}
	if(city.value.length==0){
		document.getElementById("city_error").innerHTML = "City should be filled.";
		city.focus();
		return false;
	}
	else{
		document.getElementById("city_error").innerHTML = "";
	}
	if(country_name.length==0){
		document.getElementById("country_error").innerHTML = "Country should be selected.";
		country.focus();
		return false;
	}
	else{
		document.getElementById("country_error").innerHTML = "";
	}
	if(state_name.length==0){
		document.getElementById("state_error").innerHTML = "State should be selected.";
		state.focus();
		return false;
	}
	else{
		document.getElementById("state_error").innerHTML = "";
	}
}
function displayPrice(){
	var qty=document.getElementById("qty").value;
	var price=document.getElementById("priceText").value;
	var amount=qty*price;
	document.getElementById("price").innerHTML = amount;
}
function showInputBox(){
	var checkboxes=document.getElementsByName("interest");
	if(document.getElementById("other").checked){
		document.getElementById("other_tb").style.display = "block";
		for(var i = 0; i < checkboxes.length; i++) 
		{
			checkboxes[i].disabled = true;
		}
	}
	else{
		document.getElementById("other_tb").style.display = "none";
		for(var i = 0; i < checkboxes.length; i++) 
		{
			checkboxes[i].disabled = false;
		}
	}
}
function select_all(select){
	var checkboxes=document.getElementsByName('interest');
	if(select.checked==true)
	{
		for(var i = 0; i < checkboxes.length; i++) 
		{
			checkboxes[i].checked = true;
			document.getElementById("other").disabled = true;
		}
	}
	else
	{
		for(var i = 0; i < checkboxes.length; i++) 
		{
			checkboxes[i].checked = false;
			document.getElementById("other").disabled = false;
		}
	}
}
function addToCart(){
	var amount=document.getElementById("price").innerHTML;
	var itemname=document.getElementById("itemname").innerHTML;
	var price=document.getElementById("priceText").value;
	var qty=document.getElementById("qty");
	var selectedQty = qty.options[qty.selectedIndex].text;
	var size=document.getElementById("size");
	var selectedSize = size.options[size.selectedIndex].text;
	var selectedId = size.options[size.selectedIndex].value;
	if(size.selectedIndex==0){
		swal({
			title:"",
			text:"Select size to add item",
			imageUrl:assets_url + "images/warning.svg",
			confirmButtonColor: '#8A6D3B'
		});
	}
	else if(qty.selectedIndex==0){
		swal({
			title:"",
			text:"Select quantity to add item",
			imageUrl:assets_url + "images/warning.svg",
			confirmButtonColor: '#8A6D3B'
		});
	}
	else{
		swal({
			title: "",
			text: "Are you sure you want to purchase this product? Your total bill amount is $" + amount + ".00.",
			imageUrl:assets_url + "images/info.svg",
			showCancelButton: true,
			confirmButtonColor: '#31708F',
			confirmButtonText: 'Continue',
			cancelButtonText: "No!",
			closeOnConfirm: false,
			closeOnCancel: true
		},
		function(isConfirm) {
			if (!isConfirm) {return;}
			var dataString="id=" + selectedId + "&name=" + itemname + "&size=" + selectedSize + "&qty=" + selectedQty + "&price=" + price;
			$.ajax({
				type: 'POST',
				url: site_url+'home/addToCart',
				data: dataString,
				success: function(data){
					var response= $.parseJSON(data);
					if(response.status==1){
						swal({
							title:"",
							text:response.msg,
							imageUrl:assets_url + "images/success.png",
							confirmButtonColor: '#428BCA'
						});
						document.getElementById("popover-content").innerHTML=response.content;
					}
					else if(response.status==2){
						swal({
							title:"",
							text:response.msg,
							imageUrl:assets_url + "images/error.svg",
							confirmButtonColor: '#A94442'
						});
					}
				},
				error: function(response){
					alert("error : " + response);
				}
			}); 
		});
	}	
}
function clearAllValue(){
	var confirmClear=confirm("Are you sure you want to clear all values?");
	if(confirmClear){
		return true;
	}
	else
	{
		return false;
	}
}
function changeSubtotal(){
	var price=document.getElementsByName("price_js");
	var qty=document.getElementsByName("qty_js");
	var total=0;
	for(var i=0;i<price.length;i++){
		document.getElementsByName("subtotal_js")[i].innerHTML = price[i].textContent*qty[i].value;	
		total=total+price[i].textContent*qty[i].value;	
	}
}
function fill_address(){
	var street=document.getElementById("street");
	var city=document.getElementById("city");
	var country = document.getElementById("country_ship").selectedIndex;
	var state=document.getElementById("state").selectedIndex;
	var street_bill=document.getElementById("street_bill");
	var city_bill=document.getElementById("city_bill");
	var country_bill=document.getElementById("country_bill");
	var state_bill=document.getElementById("state_bill");
	var billing_address=document.getElementById("billing_address");
	if(billing_address.checked){
		street_bill.value=street.value;
		city_bill.value=city.value;
		country_bill.selectedIndex=country;
		state_bill.selectedIndex=state;
	}
}