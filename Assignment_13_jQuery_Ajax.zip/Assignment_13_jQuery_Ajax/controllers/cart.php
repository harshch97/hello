<?php
error_reporting(0);
class Cart extends BaseController {
    /**
     * @author Tatvasoft
     * Default method of Cart controller and load header,main content,footer view.
     *   
     */
    public function index() {
        $this->load_model('HeaderModel');

        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $this->load_view('header', array('menuList' => $menuItemsList));
        
        $this->load_view('user/cart');
        $this->load_view('footer');
    }

    //  Update cart function
    public function updateCart(){
        $jsonArray=json_decode($_POST['dataString'],true);
        foreach ($jsonArray as $key => $value) {
            $flag=0;
            $idIndex=0;
            foreach ($_SESSION["cart"] as $index => $v) {
                if ($v['id'] == $value['id']) {
                    $flag=1;
                    $idIndex=$index;
                    $qty=$value['qty'];
                    break;
                }
            }  
            if($flag==1){
                $_SESSION["cart"][$idIndex]['qty']=$qty;
                $subtotal+=$_SESSION["cart"][$idIndex]['qty']*$_SESSION["cart"][$idIndex]['price'];
            }
        }
        $cartHTML=showCart();
        echo json_encode(array('msg'=>'Cart updated Successfully','subtotal'=>$subtotal,'content'=>$cartHTML));
    }

    //  Remove item from cart
    public function removeItem(){
        $id=$_POST['id'];
        $address=$_SERVER['HTTP_REFERER'];
        foreach ($_SESSION["cart"] as $i => $v) {
            if ($v['id'] == $id) {
                unset($_SESSION["cart"][$i]);
            }
        }
        foreach ($_SESSION["cart"] as $cartItem) {
            $totalPerItem=$cartItem['price']*$cartItem['qty'];
            $subtotal+=$totalPerItem;
        }
        if(!empty($_SESSION["cart"]))
        {
            $cartHTML=showCart();
            echo json_encode(array('status'=>1,'msg'=>'Successfully removed product.','content'=>$cartHTML,'subtotal'=>$subtotal));
        }
        else{
            echo json_encode(array('status'=>2,'msg'=>'Cart Empty.'));
        }
    }

    //  Clear whole shopping cart
    public function clearShoppingCart(){
        $address=SITE_URL . "home";
        unset($_SESSION["cart"]);
        echo "<script>";
        echo "window.location.replace(\"$address\");";
        echo "</script>";
    }
}