<?php
error_reporting(0);
class Product extends BaseController {

    /**
     * @author Tatvasoft
     * Default method of Product controller and load header,main content,footer view.
     *   
     */
    public function __construct(){
        $this->load_model('HeaderModel');
        $this->load_model('ProductModel');
    }

    //  Product listing page of selected category or sub-category
    public function listing($parent,$id) {
        unset($_SESSION['category_name']);
        unset($_SESSION['sub_category_name']);
        unset($_SESSION['parent_category']);
        unset($_SESSION['sub_category']);
        $_SESSION['category_name']=$parent;
        $_SESSION['sub_category_name']=$id;
        $_SESSION['search_for']=$parent;
        
        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $this->load_view('header', array('menuList' => $menuItemsList));
        $id=str_replace("_"," ",$id);
        $parent=$this->productmodel->fetchCategoryId($parent);
        foreach ($parent as $value) {}
        $parent=$value['id'];
        $_SESSION['parent_category']=$parent;
        if(!empty($id)){    //  sub-category is selected
            $subCategory=$this->productmodel->fetchSubCategoryId($id,$parent);
            if($subCategory){
                foreach ($subCategory as $sub) {}
                $subCategory=$sub['id'];
                $_SESSION['sub_category']=$subCategory;
                $show_products['sub_category']=$this->productmodel->fetchSubcategory($parent);
            }
            $show_products['color']=$this->productmodel->fetchColor();
            $show_products['size']=$this->productmodel->fetchSize();
            $show_products['price']=$this->productmodel->fetchPrice();
            $show_products['product']=$this->productmodel->fetchProductsById();
            $show_products['result']=1;
            $this->load_view('user/product',$show_products);
        }
        else{
            $str=$_SESSION['category_name'];
            $getCategory=$this->productmodel->getCategory($str);
            if(count($getCategory)==0){ //  if user enter string to search from item name match
                $show_products['product']=$this->productmodel->getMatchProducts($str);
                $show_products['result']=2;
                $this->load_view('user/product',$show_products);
            }
            else{   //  entered of selected text is from category list
                $getSubCategory=$this->productmodel->subCategory($parent); 
                if(count($getSubCategory)==0){  //  no subcategory available
                    $show_products['color']=$this->productmodel->fetchColor();
                    $show_products['size']=$this->productmodel->fetchSize();
                    $show_products['price']=$this->productmodel->fetchPrice();
                    $show_products['product']=$this->productmodel->fetchProductsById();
                    $show_products['result']=1;
                    $this->load_view('user/product',$show_products);
                }   
                else{   //  sub-category available from selected string
                    $show_products['sub_category']=$this->productmodel->fetchSubcategory($parent);
                    $show_products['color']=$this->productmodel->fetchColor($show_products['sub_category']);
                    $show_products['size']=$this->productmodel->fetchSize($show_products['sub_category']);
                    $show_products['price']=$this->productmodel->fetchPrice();
                    $show_products['product']=$this->productmodel->fetchProductsById($show_products['sub_category']); 
                    $show_products['result']=2;
                    $this->load_view('user/product',$show_products);
                }
            }
        }
        $this->load_view('footer');
    }

    //  will select all products if nothing is enter to search
    public function allProducts($parent_id,$sub_category_id){
        if(!empty($sub_category_id)){
            $show_products=$this->productmodel->fetchAllProduct($parent_id,$sub_category_id);
        }
        else{
            $parent=$_SESSION['parent_category'];
            $show_products['sub_category']=$this->productmodel->fetchSubcategory($parent);
            $show_products=$this->productmodel->fetchProducts($show_products['sub_category']);
        }
        $rows=count($show_products);
        $product="";
        $product=$this->productContent($show_products);
        echo json_encode(array('content'=>$product,'rows'=>$rows));  
    }

    //  fetch all product category list
    public function allProductList(){
        $item=$_REQUEST['term'];
        $productName=$this->productmodel->fetchAllProductList($item);
        $categoryName=$this->productmodel->fetchAllCategoryList($item);
        foreach ($productName as $product) {
            $data[]=$product['name'];
        }
        foreach ($categoryName as $category) {
            if(!empty($category['parent'])){
                $data_category[]=$category['parent'] . "/" . $category['sub'];
            }
            else{
                $data_category[]=$category['sub'];
            }
        }
        echo "<div class=\"row\" style=\"text-align:left;\">";
        if(count($data_category)!=0){
            echo "<div class=\"col-sm-4 col-xs-4\"><div>Category</div>";
            for($i=0;$i<count($data_category);$i++){
                unset($_SESSION['category_name']);
                unset($_SESSION['sub_category_name']);
                unset($_SESSION['parent_category']);
                unset($_SESSION['sub_category']);
                $_SESSION['category_name']=$data_category[$i];
                echo "<li><a href=\"" . SITE_URL . "product/listing/" . strtolower(str_replace(" ", "_", $data_category[$i])) . "\">" . ucfirst(strtolower($data_category[$i])) . "</a></li>";
            }
        }
        else{
            echo "<div class=\"col-sm-4 col-xs-4\"><div>Category</div>";
            echo "<div class='last-item'>Not found</div>";
        }
        echo "</div>";
        if(count($data)!=0){
            echo "<div class=\"col-sm-8 col-xs-8\"><div>Products</div>";
            for($i=0;$i<count($data);$i++){
                echo "<li><a href=\"" . SITE_URL . "product/searchdetail/" . $data[$i] . "\">" . ucfirst(strtolower($data[$i])) . "</a></li>";
            }
        }
        else{
            echo "<div class=\"col-sm-8 col-xs-8\"><div>Products</div>";
            echo "<div class='last-item'>Not found</div>";
        }
        echo "</div></div>";
    }

    //  fetch product detail of selected product
    public function searchdetail($itemName) {
        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $this->load_view('header', array('menuList' => $menuItemsList));
        $show_products['id']=$this->productmodel->searchItem($itemName);
        foreach ($show_products as $items) {
        }foreach ($items as $item) {
        }
        $item_id=$item['item_id'];
        $_SESSION['sub_category_name']=$item['sub_category'];
        $_SESSION['category_name']=$item['parent_category'];
        $show_products['size']=$this->productmodel->getSize($item_id);
        $show_products['sliderImages']=$this->productmodel->getImages($item_id);
        $show_products['reviewData']=$this->productmodel->getReviews($item_id);
        $show_products['imageDescription']=$this->productmodel->getImageDescription($show_products['sliderImages'][0]['item_id']);
        $this->load_view('user/productlist',$show_products);
        $this->load_view('footer');
    }   

    //  display data based on selected filters
    public function filterProducts(){
        $sortArray=json_decode($_POST['sortBy'],true);
        $sizeArray=json_decode($_POST['productSize'],true);
        $colorArray=json_decode($_POST['productColor'],true);
        $priceArray=json_decode($_POST['productPrice'],true);
        $product="";
        $show_products=$this->productmodel->fetchFilteredProduct($sortArray,$sizeArray,$colorArray,$priceArray);
        $rows=count($show_products);
        $product=$this->productContent($show_products);  
        echo json_encode(array('content'=>$product,'rows'=>$rows));
    }

    //  iterate through selected products
    public function productContent($show_products){
        $assets_url=ASSETS_URL;
        foreach ($show_products as $row) {
            $product    .=  "<div class=\"col-sm-4 product-block\" title=\"" . $row['item_id'] ."\">
                            <div class=\"background-color\">
                                <img src=\"" . $assets_url . "images/" . $row['item_image_url'] . "\" class=\"img-rounded image\" >
                                <div class=\"middle\">
                                    <div class=\"rollover-btn\">
                                        <a class=\"addToCart1\" title=\"" . $row['id'] . "\">Add to Cart</a>
                                    </div>
                                </div>
                            </div>
                            <div class=\"row\"><div class=\"col-sm-12\"><p>" . $row['name'] . "<sub class=\"sub\"> [Size: " . $row['value'] . "]</sub></p></div></div>
                            <div class=\"row\"><div class=\"col-sm-12 price\"><p><b>$" . $row['price'] . ".00</b></p></div></div>
                        </div>";
        }
        return $product;
    }

    //  product details page for selected product
    public function detail($item_id) {
        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $this->load_view('header', array('menuList' => $menuItemsList));
        $data['size']=$this->productmodel->getSize($item_id);
        $data['sliderImages']=$this->productmodel->getImages($item_id);
        $data['reviewData']=$this->productmodel->getReviews($item_id);
        $data['imageDescription']=$this->productmodel->getImageDescription($data['sliderImages'][0]['item_id']);
        $this->load_view('user/productlist',$data);
        $this->load_view('footer');
    }   

    //  add selected product to wishlist
    public function addToWishList(){
        $item_id=$_POST['id'];
        $user_id=$_SESSION['user_id'];
        $wishList=$this->productmodel->addToWishList($item_id,$user_id);
        if($wishList==true)
        {
            echo json_encode(array('status' => 2, 'msg' => 'Successfully added product to wishlist.'));
        }
        else{
            echo json_encode(array('status' => 1, 'msg' => 'You have already added this item to wishlist.'));
        }
    }

    //  add review for selected item
    public function addReview(){
        $msg=$_POST['msg'];
        $item_id=$_POST['itemId'];
        $ratings=$_POST['ratings'];
        $user_id=$_SESSION['user_id'];
        if(checkIfLogin()){
            $addReview=$this->productmodel->addReview($item_id,$user_id,$msg,$ratings);
            if($addReview==true)
            {
                echo json_encode($addReview);
            }
            else{
                echo json_encode(array('status' => 1, 'msg' => 'Unable to save your review.'));
            }
        }
        else{
                echo json_encode(array('status' => 2, 'msg' => 'Login to review this product.'));
        }
    }
}