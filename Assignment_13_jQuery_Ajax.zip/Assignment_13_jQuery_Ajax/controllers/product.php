<?php
error_reporting(0);
class Product extends BaseController {

    /**
     * @author Tatvasoft
     * Default method of Aboutus controller and load header,main content,footer view.
     *   
     */
    public function __construct(){
        $this->load_model('HeaderModel');
        $this->load_model('ProductModel');
    }
    public function index() {
        // echo $item_id;
        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $this->load_view('header', array('menuList' => $menuItemsList));

        $show_products['sub_category']=$this->productmodel->fetchSubcategory();
        $show_products['color']=$this->productmodel->fetchColor();
        $show_products['price']=$this->productmodel->fetchPrice();
        $show_products['size']=$this->productmodel->fetchSize();
        $show_products['product']=$this->productmodel->fetchProducts();
        // echo "<pre>";print_r($show_products['price']);exit();
        $this->load_view('user/product',$show_products);

        $this->load_view('footer');
    }
    public function allProducts(){
        $show_products=$this->productmodel->fetchProducts();
        $product="";
        $product=$this->productContent($show_products);
        echo json_encode(array('content'=>$product));  
    }/*
    public function filterByColor($id) {
        $show_products=$this->productmodel->fetchProductByColor($id);
        $product="";    
        $product.=$this->productContent($show_products);
        echo json_encode(array('content'=>$product));  
    }*/
    public function filterProducts(){
        // echo json_encode($_POST['productPrice']);
        /*$sizeArray=json_decode($_POST['productSize'],true);
        $product="";
        foreach($sizeArray as $value) {
            $show_products=$this->productmodel->fetchProductBySize($value['id']);
            $product.=$this->productContent($show_products);
        }
        $colorArray=json_decode($_POST['productColor'],true);
        foreach($colorArray as $value) {
            $show_products=$this->productmodel->fetchProductByColor($value['id']);
            $product.=$this->productContent($show_products);
        }*/
        $priceArray=json_decode($_POST['productPrice'],true);
        foreach($priceArray as $value) {
            $show_products=$this->productmodel->fetchProductByPrice($value['startRange'],$value['endRange']);
            $product.=$this->productContent($show_products);
        }
        echo json_encode(array('content'=>$product));  
    }
    public function fetchByPrice() {
        // echo "<pre>";print_r($_POST);exit();
        $startRange=$_POST['startRange'];
        $endRange=$_POST['endRange'];
        $show_products=$this->productmodel->fetchProductByPrice($startRange,$endRange);
        $product="";    
        $product=$this->productContent($show_products);

        echo json_encode(array('content'=>$product));  
    }
    public function filterByColor(){
        $jsonArray=json_decode($_POST['dataString'],true);
        $product="";
        foreach($jsonArray as $value) {
            $show_products=$this->productmodel->fetchProductByColor($value['id']);
            $product.=$this->productContent($show_products);
        }
        echo json_encode(array('content'=>$product));  
    }
    public function filterBySize(){
        $jsonArray=json_decode($_POST['dataString'],true);
        $product="";
        foreach($jsonArray as $value) {
            $show_products=$this->productmodel->fetchProductBySize($value['id']);
            $product.=$this->productContent($show_products);
        }
        echo json_encode(array('content'=>$product));  
    }
    public function productContent($show_products){
        $assets_url=ASSETS_URL;
        foreach ($show_products as $row) {
            $product    .=  "<div class=\"col-sm-4 product-block\" title=\"" . $row['item_id'] ."\">
                            <div class=\"background-color\">
                                <img src=\"" . $assets_url . "images/" . $row['item_image_url'] . "\" class=\"img-rounded image\" >
                                <div class=\"middle\">
                                    <div class=\"rollover-btn\">
                                        <a class=\"addToCart\" title=\"" . $row['id'] . "\">Add to Cart</a>
                                    </div>
                                </div>
                            </div>
                            <div class=\"row\"><div class=\"col-sm-12\"><p>" . $row['name'] . "<sub class=\"sub\"> [Size: " . $row['value'] . "]</sub></p></div></div>
                            <div class=\"row\"><div class=\"col-sm-12 price\"><p><b>$" . $row['price'] . ".00</b></p></div></div>
                        </div>";
        }
        return $product;
    }
    public function detail($item_id) {
        // echo $item_id;
        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $this->load_view('header', array('menuList' => $menuItemsList));
        $data['size']=$this->productmodel->getSize($item_id);
        $data['sliderImages']=$this->productmodel->getImages($item_id);
        $data['reviewData']=$this->productmodel->getReviews($item_id);
        $data['imageDescription']=$this->productmodel->getImageDescription($data['sliderImages'][0]['item_id']);
        $this->load_view('user/productlist',$data);
        $this->load_view('footer');
    }   

    public function addToWishList(){
        $item_id=$_POST['id'];
        $user_id=$_SESSION['user_id'];
        $wishList=$this->productlistmodel->addToWishList($item_id,$user_id);
        if($wishList==true)
        {
            echo json_encode(array('status' => 2, 'msg' => 'Successfully added product to wishlist.'));
        }
        else{
            echo json_encode(array('status' => 1, 'msg' => 'You have already added this item to wishlist.'));
        }
    }
    public function addReview(){
        $msg=$_POST['msg'];
        $item_id=$_POST['itemId'];
        $ratings=$_POST['ratings'];
        $user_id=$_SESSION['user_id'];
        // echo "$msg $item_id $ratings $user_id";
        $addReview=$this->productlistmodel->addReview($item_id,$user_id,$msg,$ratings);
        if($addReview==true)
        {
            echo json_encode($addReview);
        }
        else{
            echo json_encode(array('status' => 1, 'msg' => 'Unable to save your review.'));
        }
    }
}