<?php
error_reporting(0);
class Product extends BaseController {

    /**
     * @author Tatvasoft
     * Default method of Aboutus controller and load header,main content,footer view.
     *   
     */
    public function __construct(){
        $this->load_model('HeaderModel');
        $this->load_model('ProductModel');
    }
    public function index($id) {
        // echo $item_id;
        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $this->load_view('header', array('menuList' => $menuItemsList));

        $show_products['sub_category']=$this->productmodel->fetchSubcategory();
        $show_products['color']=$this->productmodel->fetchColor();
        $show_products['price']=$this->productmodel->fetchPrice();
        $show_products['size']=$this->productmodel->fetchSize();
        $show_products['product']=$this->productmodel->fetchProductsById($id);
        // echo "<pre>";print_r($show_products['product']);exit();
        $this->load_view('user/product',$show_products);

        $this->load_view('footer');
    }
    public function allProducts($id){
        $show_products=$this->productmodel->fetchProducts();
        $product="";
        $product=$this->productContent($show_products);
        echo json_encode(array('content'=>$product));  
    }
    public function filterProducts(){
        $sizeArray=json_decode($_POST['productSize'],true);
        $colorArray=json_decode($_POST['productColor'],true);
        $priceArray=json_decode($_POST['productPrice'],true);
        $product="";
        $show_products=$this->productmodel->fetchFilteredProduct($sizeArray,$colorArray,$priceArray);
        $product=$this->productContent($show_products);  
        echo json_encode(array('content'=>$product));
    }
    public function productContent($show_products){
        $assets_url=ASSETS_URL;
        foreach ($show_products as $row) {
            $product    .=  "<div class=\"col-sm-4 product-block\" title=\"" . $row['item_id'] ."\">
                            <div class=\"background-color\">
                                <img src=\"" . $assets_url . "images/" . $row['item_image_url'] . "\" class=\"img-rounded image\" >
                                <div class=\"middle\">
                                    <div class=\"rollover-btn\">
                                        <a class=\"addToCart\" title=\"" . $row['id'] . "\">Add to Cart</a>
                                    </div>
                                </div>
                            </div>
                            <div class=\"row\"><div class=\"col-sm-12\"><p>" . $row['name'] . "<sub class=\"sub\"> [Size: " . $row['value'] . "]</sub></p></div></div>
                            <div class=\"row\"><div class=\"col-sm-12 price\"><p><b>$" . $row['price'] . ".00</b></p></div></div>
                        </div>";
        }
        return $product;
    }
    public function detail($item_id) {
        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $this->load_view('header', array('menuList' => $menuItemsList));
        $data['size']=$this->productmodel->getSize($item_id);
        $data['sliderImages']=$this->productmodel->getImages($item_id);
        $data['reviewData']=$this->productmodel->getReviews($item_id);
        $data['imageDescription']=$this->productmodel->getImageDescription($data['sliderImages'][0]['item_id']);
        $this->load_view('user/productlist',$data);
        $this->load_view('footer');
    }   

    public function addToWishList(){
        $item_id=$_POST['id'];
        $user_id=$_SESSION['user_id'];
        $wishList=$this->productmodel->addToWishList($item_id,$user_id);
        if($wishList==true)
        {
            echo json_encode(array('status' => 2, 'msg' => 'Successfully added product to wishlist.'));
        }
        else{
            echo json_encode(array('status' => 1, 'msg' => 'You have already added this item to wishlist.'));
        }
    }
    public function addReview(){
        $msg=$_POST['msg'];
        $item_id=$_POST['itemId'];
        $ratings=$_POST['ratings'];
        $user_id=$_SESSION['user_id'];
        if(checkIfLogin()){
            $addReview=$this->productmodel->addReview($item_id,$user_id,$msg,$ratings);
            if($addReview==true)
            {
                echo json_encode($addReview);
            }
            else{
                echo json_encode(array('status' => 1, 'msg' => 'Unable to save your review.'));
            }
        }
        else{
                echo json_encode(array('status' => 2, 'msg' => 'Login to review this product.'));
        }
    }
}