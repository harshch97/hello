<?php
error_reporting(0);
class Profile extends BaseController {

    /**
     * @author Tatvasoft
     * Default method of Profile controller and load header,main content,footer view.
     *   
     */
    public function __construct(){
        $this->load_model('ProfileModel');
        $this->load_model('HeaderModel');
    }
    public function index() {
        if(checkIfLogin()){
            $menuItemsList = array();
            $resultMenu['data']=$this->headermodel->fetchCategory();

            $i = 0;
            foreach ($resultMenu['data'] as $value) {
                $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

                $menuItemsList[$i][] = $value;
                $menuItemsList[$i][] = $resultMenu['subCategory'];
                $i++;
            }
            $this->load_view('header', array('menuList' => $menuItemsList));

            //Profile information
            
            $data['userDetail']=$this->profilemodel->getLoggedUserDetail(getLoginUserId());
            $data['countries']=$this->profilemodel->getAllCountry();
            if(!empty($data['userDetail'][0]['shipping_add_id'])){
                $data['shipping_address']=$this->profilemodel->getAddressDetail($data['userDetail'][0]['shipping_add_id']);
                $data['shipping_states']=$this->profilemodel->getStatesByCountryId($data['shipping_address'][0]['country_id']);
            }
            
            if(!empty($data['userDetail'][0]['billing_add_id'])){
                $data['billing_address']=$this->profilemodel->getAddressDetail($data['userDetail'][0]['billing_add_id']);
                $data['billing_states']=$this->profilemodel->getStatesByCountryId($data['billing_address'][0]['country_id']);
            }
            $this->load_view('user/profile',$data);
            $this->load_view('footer');
        }
        else{
            $this->redirect("home");
        }
    }

    //  fetch state from selected country
    public function fetchState(){
        $this->load_model('ProfileModel');
        $id=$_POST['id'];
        $getState=$this->profilemodel->getStatesByCountryId($id);
        echo json_encode($getState);
    }

    //  update profile information
    public function updateProfile(){
        $address=$_SERVER['HTTP_REFERER'];
        if(empty($_POST['street'])){    //  when billing or shipping address is not updated
            $result=$this->profilemodel->updateUser($_POST);
        }
        else{
            $result=$this->profilemodel->updateUserAddress($_POST);
        }
        if($result==1){
            $username=getLoginUserName();
            echo json_encode(array('status' => 1, 'msg' => 'Successfully updated!','username'=>$username));
        }
        else if($result==2){
            echo json_encode(array('status' => 2, 'msg' => 'Email id should be unique!'));
        }
    }
}