<?php

class ProductModel extends basemodel
{
	//	fetch products
	public function fetchProducts($sub_category=''){
		$parent_id=$_SESSION['parent_category'];
		$subcategory_id=$_SESSION['sub_category'];
		$getProducts="SELECT `item_options`.id,`item`.id as item_id,`item`.name,`item`.price,`item_images`.item_image_url,`attribute_options`.value,`category`.name as 'category'
					FROM `item_options` 
					LEFT JOIN `item` ON `item_options`.item_id=`item`.id 
					LEFT JOIN `category` ON `category`.id=`item`.category_id 
					LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
					LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id 
					WHERE `item_images`.is_primary=1 ";
		if(empty($sub_category)){
			if(empty($subcategory_id)){
				$getProducts .= " AND `category`.id=$parent_id ";
			}
			else{
				$getProducts .= " AND `category`.id=$subcategory_id AND `category`.parent_id=$parent_id ";
			}
		}
		else{
			$getProducts .= " AND (";
			foreach ($sub_category as $k => $value) {
				$getProducts .= " `category`.id=" . $value['id'];
				if($k!=count($sub_category)-1){
					$getProducts .= " OR ";
				}else{
					$getProducts .= ")";
				}
			}
		}
        $getProducts.=" ORDER BY `item`.id ";
		$result=$this->_db->query($getProducts);
		return $this->getResultArray($result);
	}
	public function fetchSearchAllProducts(){
		$getProducts="SELECT `item_options`.id,`item`.id as item_id,`item`.name,`item`.price,`item_images`.item_image_url,`attribute_options`.value,`category`.name as 'category'
					FROM `item_options` 
					LEFT JOIN `item` ON `item_options`.item_id=`item`.id 
					LEFT JOIN `category` ON `category`.id=`item`.category_id 
					LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
					LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id 
					WHERE `item_images`.is_primary=1 ";
		$result=$this->_db->query($getProducts);
		return $this->getResultArray($result);
	}
	public function fetchAllSearchProducts(){
		$getProducts="SELECT `item_options`.id,`item`.id as item_id,`item`.name,`item`.price,`item_images`.item_image_url,`attribute_options`.value,`category`.name as 'category'
					FROM `item_options` 
					LEFT JOIN `item` ON `item_options`.item_id=`item`.id 
					LEFT JOIN `category` ON `category`.id=`item`.category_id 
					LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
					LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id 
					WHERE `item_images`.is_primary=1
                    ORDER BY `item`.id
                    ";
		$result=$this->_db->query($getProducts);
		return $this->getResultArray($result);
	}
	public function fetchProductsById($sub_category=''){
		$parent_id=$_SESSION['parent_category'];
		$subcategory_id=$_SESSION['sub_category'];
		$getProducts="SELECT `item_options`.id,`item`.id as item_id,`item`.name,`item`.price,`item_images`.item_image_url,`attribute_options`.value,`category`.name as 'category'
					FROM `item_options` 
					LEFT JOIN `item` ON `item_options`.item_id=`item`.id 
					LEFT JOIN `category` ON `category`.id=`item`.category_id 
					LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
					LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id 
					WHERE `item_images`.is_primary=1 ";
		if(empty($sub_category)){
			if(empty($subcategory_id)){
			$getProducts.=" AND `category`.id=$parent_id ";
			}
			else{
				$getProducts.=" AND `category`.id=$subcategory_id AND `category`.parent_id=$parent_id ";
			}
		}
		else{
			$getProducts .= " AND (";
			foreach ($sub_category as $k => $value) {
				$getProducts .= " `category`.id=" . $value['id'];
				if($k!=count($sub_category)-1){
					$getProducts .= " OR ";
				}else{
					$getProducts .= ")";
				}
			}
		}
		$result=$this->_db->query($getProducts);
		return $this->getResultArray($result);
	}
	public function getMatchProducts($str){
		$getProducts="SELECT `item_options`.id,`item`.id as item_id,`item`.name,`item`.price,`item_images`.item_image_url,`attribute_options`.value,`category`.name as 'category'
					FROM `item_options` 
					LEFT JOIN `item` ON `item_options`.item_id=`item`.id 
					LEFT JOIN `category` ON `category`.id=`item`.category_id 
					LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
					LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id 
					WHERE `item_images`.is_primary=1 AND `item`.name LIKE '%$str%' ";
		$result=$this->_db->query($getProducts);
		return $this->getResultArray($result);
	}

	public function fetchAllProduct($parent_id,$subcategory_id){

		$getProducts="SELECT `item_options`.id,`item`.id as item_id,`item`.name,`item`.price,`item_images`.item_image_url,`attribute_options`.value,`category`.name as 'category'
					FROM `item_options` 
					LEFT JOIN `item` ON `item_options`.item_id=`item`.id 
					LEFT JOIN `category` ON `category`.id=`item`.category_id 
					LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
					LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id 
					WHERE `item_images`.is_primary=1 ";
		if(empty($subcategory_id)){
			$getProducts .= " AND `category`.id=$parent_id ";
		}
		else{
			$getProducts .= " AND `category`.id=$subcategory_id AND `category`.parent_id=$parent_id ";
		}
		$result=$this->_db->query($getProducts);
		return $this->getResultArray($result);
	}

	//	fetch item detail based on selected filters
	public function fetchFilteredProduct($sortBy,$size,$color,$price){
		$sub_category_id=$_SESSION['sub_category'];
		$parent_id=$_SESSION['parent_category'];
		foreach ($price as $priceValue) {
			$startRange=$priceValue['startRange'];
			$endRange=$priceValue['endRange'];
		}
		$resultData="";
		$getProducts="SELECT `item_options`.id,`item`.price,`item_images`.item_image_url,`item`.id as 'item_id',`item`.name,`item`.price,`ao1`.id as 'ao_id',`ao1`.value AS `value`,`ao2`.id AS `color`
					FROM `item_options` 
					LEFT JOIN `item` ON `item_options`.item_id=`item`.id 
					LEFT JOIN `category` ON `category`.id=`item`.category_id 
					LEFT JOIN `attribute_options` `ao1` ON `item_options`.ao_id=`ao1`.id 
					LEFT JOIN `attribute_options` `ao2` ON `item`.color_id=`ao2`.id
					LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id ";
		if(($startRange != '') && ($endRange != '')){
			$getProducts .= " WHERE `item_images`.is_primary=1 AND (`item`.price >= $startRange AND `item`.price <= $endRange)";
		}
		if(empty($sub_category_id)){
			$getSubCategory=$this->subCategory($parent_id); 
			if(count($getSubCategory)==0){
				$getProducts .= " AND `category`.id=$parent_id ";
			}
			else{
				$getProducts .= " AND (";
				foreach ($getSubCategory as $k => $value) {
					$getProducts .= " `category`.id=" . $value['id'];
					if($k!=count($getSubCategory)-1){
						$getProducts .= " OR ";
					}else{
						$getProducts .= ")";
					}
				}
			}
		}
		else{
			$getProducts .= " AND `category`.id=$sub_category_id AND `category`.parent_id=$parent_id";
		}
		if($size != 0){
			$getProducts .= " AND (";
			foreach ($size as $k => $size_value) {
				$getProducts .= " `ao1`.id=" . $size_value['id'];
				if($k!=count($size)-1){
					$getProducts.=" OR ";
				}else{
					$getProducts.=")";
				}
			}
		}
		if($color != 0){
			$getProducts .= " AND (";
			foreach ($color as $k => $color_value) {
				$getProducts .= " `ao2`.id=" . $color_value['id'];
				if($k!=count($color)-1){
					$getProducts .= " OR ";
				}else{
					$getProducts.=")";
				}
			}
		}
		if($sortBy != 0){
			foreach ($sortBy as $k => $sort) {
				$getProducts .= " ORDER BY `item`." . $sort['field'] . " ";
			}
		}
		$result=$this->_db->query($getProducts);
		return $this->getResultArray($result);
	}
	public function fetchAllProductList($item){
		$getProductCategory="SELECT `item`.name FROM `item` WHERE name LIKE '%$item%'";
		$result=$this->_db->query($getProductCategory);
		return $this->getResultArray($result);
	}
	public function fetchAllCategoryList($item){
		$getProductCategory="SELECT DISTINCT `c1`.name as 'sub',`c2`.name as 'parent'
							FROM `category` `c1`
							LEFT JOIN `category` `c2` ON `c2`.id=`c1`.parent_id 
							WHERE `c1`.name LIKE '%$item%'";
		$result=$this->_db->query($getProductCategory);
		return $this->getResultArray($result);
	}
	public function fetchCategoryId($category){
		$selectCategoryId="SELECT id,parent_id FROM category WHERE name='$category' ";
		$result=$this->_db->query($selectCategoryId);
		return $result;
	}
	public function fetchSubCategoryId($category,$parent){
		$selectCategoryId="SELECT id FROM category WHERE name='$category' AND parent_id=$parent ";
		$result=$this->_db->query($selectCategoryId);
		return $result;
	}
	public function getCategory($str){
		$selectCategory="SELECT name FROM category WHERE name='$str' ";
		$result=$this->_db->query($selectCategory);
		return $this->getResultArray($result);
	}
	public function subCategory($parent){
		$selectCategoryId="SELECT id,name FROM category WHERE parent_id=$parent ";
		$result=$this->_db->query($selectCategoryId);
		return $this->getResultArray($result);
	}
	public function fetchSubcategory($parent){
		$getProductSubcategory="SELECT DISTINCT `category`.`id`,`category`.`name`,COUNT(`item_options`.item_id) as 'count'
								FROM `item_options`
								LEFT JOIN `item` ON `item`.id=`item_options`.item_id
								LEFT JOIN `category` ON `category`.id=`item`.category_id
								WHERE `category`.id=`item`.category_id AND `category`.parent_id=$parent
								GROUP BY `category`.name
								ORDER BY `category`.id";
		$result=$this->_db->query($getProductSubcategory);
		return $this->getResultArray($result);
	}
	public function fetchColor($sub_category=''){
		$parent_id=$_SESSION['parent_category'];
		$subcategory_id=$_SESSION['sub_category'];
		$getProductColor="SELECT `attribute_options`.`id`,`item`.color_id , `attribute_options`.`value`,COUNT(`item_options`.item_id) as 'count'
							FROM `item_options`
							LEFT JOIN `item` ON `item`.id=`item_options`.item_id
							LEFT JOIN `category` ON `category`.id=`item`.category_id
							LEFT JOIN `attribute_options` ON `attribute_options`.id=`item`.color_id
							WHERE `attribute_options`.id=`item`.color_id ";
		if(empty($sub_category)){
			if(empty($subcategory_id)){
				$getProductColor .= " AND `category`.id=$parent_id ";
			}
			else{
				$getProductColor .= " AND `category`.id=$subcategory_id AND `category`.parent_id=$parent_id ";
			}
		}
		else{
			$getProductColor .= " AND (";
			foreach ($sub_category as $k => $value) {
				$getProductColor .= " `category`.id=" . $value['id'];
				if($k!=count($sub_category)-1){
					$getProductColor .= " OR ";
				}else{
					$getProductColor .= ")";
				}
			}
		}

		$getProductColor.=	" GROUP BY `item`.color_id";
		$result=$this->_db->query($getProductColor);
		return $this->getResultArray($result);
	}
	public function fetchSize($sub_category=''){
		$parent_id=$_SESSION['parent_category'];
		$subcategory_id=$_SESSION['sub_category'];
		$getProductSize="SELECT `attribute_options`.`id`, `attribute_options`.`value`,COUNT(`item_options`.ao_id) as 'count'
						FROM `item_options`
						LEFT JOIN `item` ON `item`.id=`item_options`.item_id
						LEFT JOIN `category` ON `category`.id=`item`.category_id
						LEFT JOIN `attribute_options` ON `attribute_options`.id=`item_options`.ao_id";
		if(empty($sub_category)){
			if(empty($subcategory_id)){
				$getProductSize .= " WHERE `category`.id=$parent_id ";
			}
			else{
				$getProductSize .= " WHERE `category`.id=$subcategory_id AND `category`.parent_id=$parent_id ";
			}
		}
		else{
			$getProductSize .= " AND (";
			foreach ($sub_category as $k => $value) {
				$getProductSize .= " `category`.id=" . $value['id'];
				if($k!=count($sub_category)-1){
					$getProductSize .= " OR ";
				}else{
					$getProductSize .= ")";
				}
			}
		}
		$getProductSize .=	" GROUP BY `item_options`.ao_id";
		$result=$this->_db->query($getProductSize);
		return $this->getResultArray($result);
	}

	public function fetchPrice(){
		$getProductPrice="SELECT min(price) as 'minPrice',max(price) as 'maxPrice' FROM `item`";
		$result=$this->_db->query($getProductPrice);
		return $this->getResultArray($result);
	}
	public function getSize($id) 
	{
		$getSize="SELECT `item_options`.id,`attribute_options`.value
				FROM `item_options` 
                LEFT JOIN `item` ON `item`.id=`item_options`.item_id
				LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
				WHERE `item_options`.item_id=$id";
		$result=$this->_db->query($getSize);
		return $this->getResultArray($result);
	}
	public function getImages($item_id) 
	{
		$getImages="SELECT * FROM item_images WHERE item_id=$item_id";
		$result=$this->_db->query($getImages);
		return $this->getResultArray($result);
	}
	public function getReviews($item_id) 
	{
		$getReviews="SELECT `item_review`.review_text,`item_review`.ratings,`item_review`.review_date,`user`.firstname,`item`.name FROM `item_review` LEFT JOIN `item` ON `item`.id=`item_review`.item_id LEFT JOIN `user` ON `item_review`.user_id=`user`.id WHERE `item_review`.item_id=$item_id ORDER BY `item_review`.id DESC";
		$result=$this->_db->query($getReviews);
		return $this->getResultArray($result);
	}
	public function getImageDescription($item_id) 
	{
		$getImageDescription="SELECT `item`.`name`, `item`.`sku`, `category`.`name` as 'category', `item`.`price`, `item`.`color_id`, `item`.`qty`, `item`.`is_trending`, `item`.`short_desc`, `item`.`description`, `item`.`delivery_desc`, `item`.`shipping_desc`, `item`.`sizeguide_desc` FROM item,category WHERE `category`.id=`item`.category_id AND `item`.id=$item_id";
		$result=$this->_db->query($getImageDescription);
		return $this->getResultArray($result);
	}
	public function addToWishList($item_id,$user_id) 
	{
		$uniqWishList="SELECT item_id,user_id FROM wishlist WHERE item_id=$item_id AND user_id=$user_id";
		if($this->_db->query($uniqWishList)->num_rows==0){
			$addToWishList="INSERT INTO `wishlist`(`item_id`, `user_id`) VALUES ($item_id,$user_id)";
			$result=$this->_db->query($addToWishList);
			return $result;
		}
		else{
			return false;
		}
	}
	public function addReview($item_id,$user_id,$msg,$ratings){
		$date=date("Y-m-d H:i:s");
		$uniqReview="SELECT item_id,user_id FROM item_review WHERE item_id=$item_id AND user_id=$user_id";
		if($this->_db->query($uniqReview)->num_rows==0){
			$addReview="INSERT INTO `item_review`(`user_id`, `item_id`, `review_text`, `ratings`, `review_date`) VALUES ($user_id,$item_id,'$msg',$ratings,'$date')";
			if($this->_db->query($addReview)){
				$selectReviews="SELECT `item_review`.review_text,`item_review`.ratings,DATE_FORMAT(`item_review`.review_date, '%d-%m-%Y') as review_date,`user`.firstname,`item`.name FROM `item_review` LEFT JOIN `item` ON `item`.id=`item_review`.item_id LEFT JOIN `user` ON `item_review`.user_id=`user`.id WHERE `item_review`.item_id=$item_id ORDER BY `item_review`.id DESC LIMIT 1";
				$result=$this->_db->query($selectReviews);
				return $this->getResultArray($result);
			}
			else{
				return false;
			}
		}
		else{
			return false;
		}
	}
	public function searchItem($itemName){
		$getSearchResult="SELECT `item`.id as 'item_id',`c1`.name as 'sub_category',`c2`.name as 'parent_category'
					FROM `item` 
					LEFT JOIN `category` `c1` ON `c1`.id=`item`.category_id 
					LEFT JOIN `category` `c2` ON `c2`.id=`c1`.parent_id 
					WHERE `item`.name = '$itemName' ";
		$result=$this->_db->query($getSearchResult);
		return $this->getResultArray($result);
	}
}
?>