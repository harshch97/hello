<?php
    $assets_url = ASSETS_URL;
    foreach ($price as $priceVal) {
    	$minPrice=$priceVal['minPrice'];
    	$maxPrice=$priceVal['maxPrice'];
    }
    $i=0;
    foreach ($product as $row) {
    	$i++;
    }
    foreach ($product as $row) {
    	$categoryName=ucwords(strtolower($row['name']));
    }
    if(empty($categoryName)){
		echo "<script>alert('Product not available in this category!');window.location.replace('" . SITE_URL ."home');</script>";
	}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>eShopper Online Store</title>
		<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/bootstrap.min.css">
  		<script type="text/javascript" src="<?php echo $assets_url; ?>js/bootstrap.min.js"></script>
  		<script type="text/javascript" src="<?php echo $assets_url; ?>js/jquery-ui.js"></script>
  		<script type="text/javascript" src="<?php echo $assets_url; ?>js/priceslider.js"></script>
		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/jquery-ui.css" >
		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/style.css" >
		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/media.css" >
	</head>
	<body>
		<!--	Main content 	-->
		<header class="banner">
			<img src="<?php echo $assets_url; ?>images/inner-banner.jpg">
		</header>
		<a id="topBtn" title="Go to top"><img class="up-arrow" src="<?php echo $assets_url; ?>images/img_transparent.png"></div></a>
		<div class="container">
			<div class="background-content">
				<div class="row">
					<div class="col-sm-12 col-xs-12 padding-breadcrumb">
						<ul class="breadcrumb">
							<li>Home</li>
							<li><?php echo $categoryName; ?></li>
							<li class="last-item"><?php echo $categoryName; ?></li>
						</ul>
					</div>
				</div>
			</div		</div>
		<div class="container">
			<div class="register">
				<h2><?php echo $categoryName; ?></h2>
			</div>
			<div class="row sub-bottom">
				<div class="col-sm-3 col-xs-12" id="filter-panel">
					<div class="row">
						<div class="col-sm-12 col-xs-12">
							<div class="panel panel-default">
							    <div class="panel-heading heading-panel">Filter By</div>
							    <div class="panel-body left-bottom-border">
							    	<div class="row">
							    		<div class="col-sm-10 col-xs-10"><b>CATEGORIES</b></div>
							    		<div class="col-sm-2 col-xs-2"><a data-toggle="collapse" data-target="#categories"><div class="col-minus"></div></a></div>
							    	</div>
							    	<div class="row">
							    		<div class="col-sm-12 col-xs-12">
							    			<div id="categories" class="collapse in">
							    				<?php
							    				foreach ($sub_category as $sub) {
							    				?>
								    				<div class="checkbox">
												  		<label>
												    	<input type="checkbox" value="<?php echo $sub['id']; ?>" <?php echo ($categoryName==$sub['name'])?'checked':''; ?> ><?php echo $sub['name']; ?> <sub>(<?php echo $sub['count']; ?>)</sub>
												  		</label>
													</div>
												<?php 
												}
												?>
		  									</div>
							    		</div>
							    	</div>
							    </div>
							    <div class="panel-body left-bottom-border">
							    	<div class="row">
							    		<div class="col-sm-10 col-xs-10"><b>COLOUR</b></div>
							    		<div class="col-sm-2 col-xs-2"><a data-toggle="collapse" data-target="#color-category"><div class="col-minus"></div></a></div>
							    	</div>
							    	<div class="row">
							    		<div class="col-sm-12 col-xs-12">
							    			<div id="color-category" class="collapse in">
							    				<?php
							    				// echo "<pre>";print_r($color);exit();
							    				foreach ($color as $color_val) {
							    				?>
								    				<div class="row row-height">
								    					<div class="col-sm-2 col-xs-2"><div class="<?php echo strtolower($color_val['value']); ?>"></div></div>
								    					<div class="col-sm-10 col-xs-10 btn-normal btn-margin">
								    						<label>
								    							<input type="checkbox" class="color" value="<?php echo $color_val['color_id']; ?>">
								    							<?php echo $color_val['value']; ?> <sub>(<?php echo $color_val['count'] ?>)</sub>
								    						</label>
								    					</div>
								    				</div>
								    			<?php
								    			}
								    			?>
							    				<div class="row">
							    					<div class="col-sm-offset-2 col-sm-10 col-sm-offset-2 col-xs-10 btn-normal btn-color"><button type="button" id="resetBtn" class="btn-link">Reset</button></div>
							    				</div>
							    			</div>
							    		</div>
							    	</div>
							    </div>
							    <div class="panel-body left-bottom-border">
							    	<div class="row">
							    		<div class="col-sm-10 col-xs-10"><b>PRICE</b></div>
							    		<div class="col-sm-2 col-xs-2"><a data-toggle="collapse" data-target="#price-category"><div class="col-minus"></div></a></div>
							    	</div>
							    	<div id="price-category" class="collapse in" >
								    	<div class="row text-align-modal">
								    		<div class="col-sm-12 col-xs-12">
								    			<div id="items" style="display: inline;"><?php echo $i; ?></div> Items
								    		</div>
								    	</div>
								    	<div class="row">
								    		<div class="col-sm-12 col-xs-12">
												<div id="slider" class="price"></div>
												<input type="hidden" id="minPrice" value="<?php echo $minPrice; ?>">
												<input type="hidden" id="maxPrice" value="<?php echo $maxPrice; ?>">
								    		</div>
								    	</div><br>
								    	<div class="row">
								    		<div class="col-sm-6 col-xs-6">
								    			<div>$<div style="display: inline-block;" id="amount1"><?php echo $minPrice; ?></div>.00</div>
								    		</div>
								    		<div class="col-sm-6 col-xs-6 right-align">
								    			<div>$<div style="display: inline-block;" id="amount2"><?php echo $maxPrice; ?></div>.00</div>
								    		</div>
								    	</div><br>
								    </div>
							    </div>
							    <div class="panel-body">
							    	<div class="row">
							    		<div class="col-sm-10 col-xs-10"><b>SIZE</b></div>
							    		<div class="col-sm-2 col-xs-2"><a data-toggle="collapse" data-target="#size-category"><div class="col-minus"></div></a></div>
							    	</div>
							    	<div class="row">
							    		<div class="col-sm-12 col-xs-12">
							    			<div id="size-category" class="collapse in">
							    				<?php
							    				// echo "<pre>";print_r($size);exit();
							    				foreach ($size as $size_val) {
							    				?>
								    				<div class="checkbox">
												  		<label>
												    	<input type="checkbox" class="size" value="<?php echo $size_val['id']; ?>"><?php echo $size_val['value']; ?> <sub>(<?php echo $size_val['count']; ?>)</sub>
												  		</label>
													</div>
												<?php
												}
												?>
							    			</div>
							    		</div>
							    	</div>
							    </div>
							</div>
						</div>
					</div>
					<div class="col-sm-12 col-xs-12 image image-responsive promo-image">
						<a href="<?php echo SITE_URL; ?>product"><img src="<?php echo $assets_url; ?>images/promo2.jpg" /></a>
					</div>
				</div>
				<div class="col-sm-9 col-xs-12">
					<div class="row men-title">
						<div class="col-sm-12 col-xs-12">
							<p><?php echo $categoryName; ?></p>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12 col-xs-12">
							<div class="pull-right">
							    <label for="size">Size</label>
							    <select name="size">
								  	<option>Position</option>
								  	<option>Name</option>
								  	<option>Price</option>
								</select>
						  	</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12 col-xs-12 collapse" id="insertAlert">
						  	<div class="alert alert-success alert-dismissable">
						    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
						    	<div class="row">
						    		<div class="col-sm-1 col-xs-1 success-icon">
						    		</div>
						    		<div class="col-sm-11 col-xs-11 data-display" id="insertItem">	
						    		</div>
						    	</div>
						  	</div>
						</div>
						<div class="col-sm-12 col-xs-12 collapse" id="loginAlert">
						  	<div class="alert alert-danger alert-dismissable">
						    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
						    	<div class="row">
							    		<div class="col-sm-1 col-xs-1 error-icon">
							    		</div>
							    		<div class="col-sm-11 col-xs-11 data-display" id="loginMsg">
							    		</div>
						    	</div>
						  	</div> 
						</div>
						<div class="col-sm-12 col-xs-12 collapse" id="notAvailableAlert">
						  	<div class="alert alert-danger alert-dismissable">
						    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
						    	<div class="row">
							    		<div class="col-sm-1 col-xs-1 error-icon">
							    		</div>
							    		<div class="col-sm-11 col-xs-11 data-display" id="notAvailableMsg">
							    		</div>
						    	</div>
						  	</div> 
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12">
							<div id="loading-image" style="display: none;text-align: center;"><img src="<?php echo $assets_url; ?>images/loading.gif" alt="Loading..." style="width:300px;"></div>
						</div>
					</div>
					<div class="row description" id="displayProduct">
						<?php 
							// echo "<pre>";print_r($product);exit();
						foreach ($product as $row) {
							?>
							<div class="col-sm-4 col-xs-12 product-block" title="<?php echo $row['item_id']?>">
								<div class="background-color">
									<img src="<?php echo $assets_url; ?>images/<?php echo $row['item_image_url']?>" class="img-rounded image" >
									<div class="middle">
								    	<div class="rollover-btn">
								    		<!-- <a href="<?php echo SITE_URL; ?>product/detail/<?php echo $row['item_id']; ?>">Add to Cart</a> -->
								    		<a class="addToCart" title="<?php echo $row['id']?>">Add to Cart</a>
								    	</div>
								  	</div>
								</div>
								<div class="row"><div class="col-sm-12"><p><?php echo $row['name']; ?><sub class="sub"> [Size:<?php echo $row['value']; ?>]</sub></p></div></div>
								<div class="row"><div class="col-sm-12 price"><p><b>$<?php echo $row['price']; ?>.00</b></p></div></div>
							</div>
						<?php
						}
						?>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>