<?php
$assets_url = ASSETS_URL;
foreach ($shipping_address as $shipping_value) {
	$shippingStreet=$shipping_value['street'];
	$shippingCity=$shipping_value['city'];
	$shippingState=$shipping_value['state_id'];
	$shippingCountry=$shipping_value['country_id'];
}
foreach ($billing_address as $billing_value) {
	$billingStreet=$billing_value['street'];
	$billingCity=$billing_value['city'];
	$billingState=$billing_value['state_id'];
	$billingCountry=$billing_value['country_id'];
}
?>
<head>
	<title>eShopper Online Store - Profile</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="<?php echo $assets_url; ?>css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script type="text/javascript" src="<?php echo $assets_url; ?>js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="<?php echo $assets_url; ?>css/style.css" >
	<link rel="stylesheet" href="<?php echo $assets_url; ?>css/media.css" >
</head>
<body>
	<!--	Main content 	-->
	<header class="header-data">
		<img src="<?php echo $assets_url; ?>images/inner-banner.jpg">
	</header>
	<a id="topBtn" title="Go to top"><img class="up-arrow" src="<?php echo $assets_url; ?>images/img_transparent.png"></div></a>
	<div class="container">
		<div class="background-content">
			<div class="row">
				<div class="col-sm-12 col-xs-12 padding-breadcrumb">
					<ul class="breadcrumb">
						<li>Home</li>
						<li class="last-item">Update Profile</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="update-profile">
			<h2>Update Profile</h2>
		</div>
		<div class="row">
			<div class="col-sm-12 col-xs-12 collapse" id="updateAlert">
				<div class="alert alert-success alert-dismissable">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
					<div class="row">
						<div class="col-sm-1 col-xs-1 success-icon">
						</div>
						<div class="col-sm-11 col-xs-11 data-display" id="updateMsg">	
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-12 col-xs-12 collapse" id="uniqAlert">
				<div class="alert alert-danger alert-dismissable">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
					<div class="row">
						<div class="col-sm-1 col-xs-1 error-icon">
						</div>
						<div class="col-sm-11 col-xs-11 data-display" id="uniqMsg">
						</div>
					</div>
				</div> 
			</div>
		</div>
		<?php
		foreach ($userDetail as $row) {
		?>
		<!--	Start of profile form 	-->
		<form name="updateForm" method="post" id="updateForm">
			<div class="row">
				<div class="col-sm-6 col-xs-12">
					<div class="form-group group-height">
						<label for="username">Username</label>
						<input type="text" class="form-control" value="<?php echo $row['username']; ?>" name="username" readonly>
					</div>
				</div>
				<div class="col-sm-6 col-xs-12">
					<div class="form-group group-height">
						<label for="gender">Gender</label><br>
						<div class="radio-inline radio-margin">
						<input type="radio" name="gender" value="male" <?php echo ($row['gender']=='male')?'checked':'' ?>><label>Male</label></div>
						<div class="radio-inline radio-margin">
						<input type="radio" name="gender" value="female"<?php echo ($row['gender']=='female')?'checked':'' ?>><label>Female</label></div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-6 col-xs-12">
					<div class="form-group group-height">
						<label for="password">Password</label>
						<input type="password" value="<?php echo $row['password']; ?>" class="form-control validate" id="password" name="password" disabled>
					</div>
				</div>
				<div class="col-sm-6 col-xs-12">
					<div class="form-group group-height">
						<label for="email">Email</label>
						<input type="email" class="form-control" id="email" name="email" value="<?php echo $row['email'] ; ?>">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-6 col-xs-12">
					<div class="form-group group-height">
						<label for="firstName">First Name</label>
						<input type="text" name="firstName" id="firstName" class="form-control" value="<?php echo $row['firstname'] ; ?>" >
					</div>
				</div>
				<div class="col-sm-6 col-xs-12">
				  	<div class="form-group group-height">
						<label for="mobile">Mobile No.</label>
						<input type="text" id="mobile" name="mobile" class="form-control" value="<?php echo $row['mobile_number'] ; ?>">
				 	</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-6 col-xs-12">
					<div class="form-group group-height">
						<label for="lastName">Last Name</label>
						<input type="text" id="lastName" name="lastName" class="form-control" value="<?php echo $row['lastname'] ; ?>">
					</div>
				</div>
				<div class="col-sm-6 col-xs-12">
					<div class="form-group group-height">
						<label for="phone">Phone</label>
						<input type="text" id="phone" name="phone" class="form-control" value="<?php echo $row['phone_number'] ; ?>">
					</div> 	
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-xs-12">
					<div class="form-group">
						<label for="interest">Interests</label>
						 <div class="checkbox">
								<label>
							<input type="checkbox" name="interest" id="select" onclick="select_all(this)" id="select" value="">Select All
								</label>
						</div>
						<div class="checkbox">
								<label>
							<input type="checkbox" name="interest" id="opt1" value="">Option 1
								</label>
						</div>
						<div class="checkbox">
								<label>
							<input type="checkbox" name="interest" id="opt2" value="">Option 2
								</label>
						</div>
						<div class="checkbox">
								<label>
							<input type="checkbox" name="interest" id="opt3" value="">Option 3
								</label>
						</div>							
						<div class="checkbox">
							<div class="row">
								<div class="col-sm-1 col-xs-3">
								<label>
								<input type="checkbox" name="interest_other" id="other" value="other" onchange="showInputBox()">Other
								</label>		
								</div>
								<div class="col-sm-2 col-xs-4">
										<input type="text" name="other" id="other_tb" class="form-control other-tb">
								</div>
								<div class="col-sm-9 col-xs-5"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-6 col-xs-12">
					<div class="row">
						<div class="col-sm-12">
							<input type="button" value="Edit Shipping Address" class="btn shipping-btn-style" data-toggle="collapse" data-target="#shipping-address">	
						</div>
						<div class="col-sm-12">
							<div id="shipping-address" class="<?php echo ($shipping_address==NULL)?'collapse':'collapse in' ?>">
								<div class="form-group group-height">
									<div class="row">
										<div class="col-sm-12">
											<label for="street">Street</label>
											<input type="text" class="form-control" name="street" id="street" placeholder="Please enter your Street" value="<?php echo $shippingStreet; ?>">
										</div>
										<div class="col-sm-12 error">
											<div id="street_error"></div>
										</div>
									</div>
								</div>
								<div class="form-group group-height">
									<div class="row">
										<div class="col-sm-12">
											<label for="city">City</label>
											<input type="text" name="city" class="form-control" id="city" placeholder="Please enter your City" value="<?php echo $shippingCity; ?>">
									</div>
										<div class="col-sm-12 error">
											<div id="city_error"></div>
										</div>
									</div>
									</div>
									<div class="form-group group-height">
										<div class="row">
										<div class="col-sm-12">
											<label for="country">Country</label>
											<select class="form-control country" id="country_ship" name="country">
												<option value="" disabled="" selected="">Select Country</option>
												<?php
												foreach ($countries as $country) {
												?>
													<option value="<?php echo $country['id']; ?>" <?php echo ($shippingCountry==$country['id'])?'selected':'' ?> >
														<?php echo $country['name']?>
													</option>
												<?php
											}
											?>
											</select>
										</div>
										<div class="col-sm-12 error">
											<div id="country_error"></div>
										</div>
									</div>
								</div>
								<div class="form-group group-height">
									<div class="row">
										<div class="col-sm-12">
											<label for="state">State</label>
											<select class="form-control state" id="state" name="state">
												<option value="" disabled="" selected="">Select State</option>
												<?php
												foreach ($shipping_states as $state) {
												?>
													<option value="<?php echo $state['id']; ?>" <?php echo ($shippingState==$state['id'])?'selected':'' ?> >
														<?php echo $state['name']?>
													</option>
												<?php
												}
												?>
											</select>
										</div>
										<div class="col-sm-12 error">
											<div id="state_error"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-6 col-xs-12">
					<div class="row">
						<div class="col-sm-4 col-xs-12">
							<input type="button" value="Edit Billing Address" class="btn shipping-btn-style" data-toggle="collapse" data-target="#billing-address">
						</div>
						<div class="col-sm-8 col-xs-12">
							<div class="checkbox">
								<label>
								<input type="checkbox" id="billing_address" name="billing_address" onclick="return fill_address()" <?php echo ($row['flag']==1)?'checked':'' ?>/>Same as Billing Address
								</label>
							</div>
						</div>
						<div class="col-sm-12">
							<div id="billing-address" class="<?php echo ($billing_address==NULL)?'collapse':'collapse in' ?>">

								<div class="form-group group-height">
									<div class="row">
										<div class="col-sm-12 col-xs-12">
											<label for="street">Street</label>
											<input type="text" class="form-control" id="street_bill" name="street_bill" placeholder="Please enter your Street" value="<?php echo $billingStreet; ?>" <?php echo ($row['flag']==1)?'readonly':'' ?>/>
										</div>
									</div>
								</div>
								<div class="form-group group-height">
									<div class="row">
										<div class="col-sm-12 col-xs-12">
											<label for="city">City</label>
											<input type="text" class="form-control" id="city_bill" name="city_bill" placeholder="Please enter your City" value="<?php echo $billingCity; ?>" <?php echo ($row['flag']==1)?'readonly':'' ?>>
										</div>
									</div>
								</div>
								<div class="form-group group-height">
									<div class="row">
										<div class="col-sm-12 col-xs-12">
											<label for="country">Country</label>
											<select class="form-control country" id="country_bill" name="country_bill" <?php echo ($row['flag']==1)?'readonly':'' ?>>
												<option value="" disabled="" selected="">Select Country</option>
												<?php
												foreach ($countries as $country) {
												?>
													<option value="<?php echo $country['id']; ?>" <?php echo ($billingCountry==$country['id'])?'selected':'' ?>><?php echo $country['name']?></option>
													<?php
												}
												?>
											</select>
										</div>
									</div>
								</div>
								<div class="form-group group-height">
									<div class="row">
										<div class="col-sm-12 col-xs-12">
											<label for="state">State</label>
											<select class="form-control state" id="state_bill" name="state_bill" <?php echo ($row['flag']==1)?'readonly':'' ?>>
												<option value="" disabled="" selected="">Select State</option>
												<?php
												foreach ($billing_states as $state) {
												?>
												<option value="<?php echo $state['id']; ?>" <?php echo ($billingState==$state['id'])?'selected':'' ?> >
														<?php echo $state['name']?>
													</option>
												<?php
												}
												?>
											</select>
										</div>
									</div>
							  	</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-xs-12">
					<input type="submit" value="Update" id="updateUser" class="btn update-btn pull-right">
				</div>
			</div>
		</form><!--	End of profile form 	-->
		<?php
		}
		?>
	</div>