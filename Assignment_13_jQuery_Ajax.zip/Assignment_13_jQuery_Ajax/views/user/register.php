<?php
$assets_url = ASSETS_URL;
error_reporting(0);
?>
<head>
	<title>eShopper Online Store - Register</title>
	<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="icon" href="<?php echo $assets_url; ?>images/favicon.ico">
		<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
		<script type="text/javascript" src="<?php echo $assets_url; ?>js/bootstrap.min.js"></script>
		<!-- <script type="text/javascript" src="<?php echo $assets_url; ?>js/script.js"></script> -->
	<link rel="stylesheet" href="<?php echo $assets_url; ?>css/style.css" >
	<link rel="stylesheet" href="<?php echo $assets_url; ?>css/media.css" >
</head>
<body>
	<!--	Main content 	-->
	<header>
		<img src="<?php echo $assets_url; ?>images/inner-banner.jpg">
	</header>
	<a id="topBtn" title="Go to top"><img class="up-arrow" src="<?php echo $assets_url; ?>images/img_transparent.png"></div></a>
	<div class="container">
		<div class="background-content">
			<div class="row">
				<div class="col-sm-12 col-xs-12 padding-breadcrumb">
					<ul class="breadcrumb">
						<li>Home</li>
						<li class="last-item">Register</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="register">
			<h2>Register</h2>
		</div>
		<div class="row">
			<div class="col-sm-12 col-xs-12 register-customer">
				<h2>New Customers</h2>
			</div>
			<div class="col-sm-12 col-xs-12 font-p">
				<p>By creating an account with our store, you will be able to move to the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12 col-xs-12 collapse" id="successAlert">
				<div class="alert alert-success alert-dismissable">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
					<div class="row">
						<div class="col-sm-1 col-xs-1 success-icon">
						</div>
						<div class="col-sm-11 col-xs-11 modal-data-display" id="successMsg">	
						</div>
					</div>
				</div>
			</div>
        	<div class="col-sm-12 col-xs-12 collapse" id="repeatAlert">
				<div class="alert alert-danger alert-dismissable">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
					<div class="row">
						<div class="col-sm-1 col-xs-1 error-icon">
						</div>
						<div class="col-sm-11 col-xs-11 data-display" id="repeatMsg">
						</div>
					</div>
				</div> 
			</div>
		</div>
		<!--	Start of Registration form 	-->
		<form name="registrationForm" id="registrationForm" method="post">
			<div class="row">
				<div class="col-sm-6 col-xs-12">
					<div class="form-group group-height">
						<div class="row">
							<div class="col-sm-12">
								<label for="username">Username</label>
								<input type="text" class="form-control" id="username" placeholder="Please enter your username" name="register[username]" value="<?php if(isset($uname)){echo $uname;} ?>">
							</div>
							<div class="col-sm-12 error">
								<div id="username_error"></div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-6 col-xs-12">
					<div class="form-group group-height">
						<div class="row">
							<div class="col-sm-12">
								<label for="gender">Gender</label><br>
								<div class="radio-inline radio-margin">
								<input type="radio" name="register[gender]" value="male" <?php if(isset($gender)){echo ($gender=='male')?'checked':'';} ?>><label>Male</label></div>
								<div class="radio-inline radio-margin">
								<input type="radio" name="register[gender]" value="female" <?php if(isset($gender)){echo ($gender=='female')?'checked':'';} ?>><label>Female</label></div>
							</div>
							<div class="col-sm-12 error">
								<label for="register[gender]" class="error" style="display: none;">Please select gender!</label>
								<div id="gender_error"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-6 col-xs-12">
					<div class="form-group group-height">
						<div class="row">
							<div class=	"col-sm-6 col-xs-12">
								<label for="password">Password</label>
								<input type="password" class="form-control password" id="password_value" 
title="Password must contain 
1.	TWO Capital letter
2.	At least one digit and 
3.	At least one special character(!,@,#,$)" 
							placeholder="Enter password" name="register[password]" value="<?php if(isset($password)){echo $password;} ?>">
							</div>
							<div class="col-sm-6 col-xs-12">
								<div class="form-group modal-group-height">
									<label for="password">Confirm Password</label>
									<input type="password" class="form-control" id="confirm_password" name="register[confirm_password]" placeholder="Enter password again">
								</div>
							</div>
							<div class="col-sm-12 error error-msg">
								<div id="password_error"></div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-6 col-xs-12">
					<div class="form-group group-height">
						<div class="row">
							<div class="col-sm-12">
								<label for="email">Email</label>
								<input type="email" class="form-control" id="email" placeholder="Please enter valid email" name="register[email]" value="<?php if(isset($email)){echo $email;} ?>">
							</div>
							<div class="col-sm-12 error">
								<div id="email_error"></div>
								</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-6 col-xs-12">
					<div class="form-group group-height">
						<div class="row">
							<div class="col-sm-12">
					    		<label for="firstName">First Name</label>
								<input type="text" id="firstName" class="form-control" placeholder="Please enter your first name" name="register[firstName]" value="<?php if(isset($fname)){echo $fname;} ?>" >
							</div>
								<div class="col-sm-12 error">
									<div id="firstName_error"></div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-6 col-xs-12">
					<div class="form-group group-height">
						<div class="row">
							<div class="col-sm-12">
								<label for="mobile">Mobile No.</label>
								<input type="text" id="mobile" class="form-control" name="register[mobile]" placeholder="Please enter your mobile number" value="<?php if(isset($mobile)){echo $mobile;} ?>" >
							</div>
							<div class="col-sm-12 error">
									<div id="mobile_error"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-6 col-xs-12">
					<div class="form-group group-height">
						<div class="row">
							<div class="col-sm-12">
								<label for="lastName">Last Name</label>
								<input type="text" id="lastName" class="form-control" placeholder="Please enter your last name" name="register[lastName]" value="<?php if(isset($lname)){echo $lname;} ?>" >
							</div>
								<div class="col-sm-12 error">
									<div id="lastName_error"></div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-6 col-xs-12">
					<div class="form-group group-height">
						<div class="row">
							<div class="col-sm-12">
								<label for="phone">Phone</label>
								<input type="text" id="phone" class="form-control" name="register[phone]" placeholder="Please enter your phone" >
							</div>
							<div class="col-sm-12 error">
								<div id="phone_error"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-xs-12">
					<div class="form-group">
						<label for="interest">Interests</label>
						<div class="checkbox">
							<label>
							<input type="checkbox" name="interest" id="select" onclick="select_all(this)" id="select" value="">Select All
							</label>
						</div>
						<div class="checkbox">
							<label>
							<input type="checkbox" name="interest" id="opt1" value="">Option 1
							</label>
						</div>
						<div class="checkbox">
							<label>
							<input type="checkbox" name="interest" id="opt2" value="">Option 2
							</label>
						</div>
						<div class="checkbox">
							<label>
							<input type="checkbox" name="interest" id="opt3" value="">Option 3
							</label>
						</div>						
						<div class="checkbox">
							<div class="row">
								<div class="col-sm-1 col-xs-3">
									<label>
									<input type="checkbox" name="interest_other" id="other" value="other" onclick="showInputBox()">Other
									</label>		
								</div>
								<div class="col-sm-2 col-xs-4">
									<input type="text" name="other_tb" id="other_tb" class="form-control other-tb">
								</div>
							<div class="col-sm-9 col-xs-5"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-xs-12 hr-color">
					<hr>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-6 col-xs-12">
					<div class="checkbox">
						<label>
						<input type="checkbox" id="mandatory" name="mandatory" value="">I agree with Terms and Conditions.
						</label>
						<div class="error">
							<label for="mandatory" class="error errorMsg"></label>
						</div>
					</div>
				</div>
				<div class="col-sm-offset-3 col-sm-3 col-xs-12 btn-padding">
					<input type="submit" class="btn submit-btn-style" value="Submit" id="registerUser" name="registerUser">
					<input type="reset" onclick="return clearAllValue()" class="btn clear-btn-style pull-right" value="Clear">
				</div>
			</div>
			</form>
		</div>
	</div>