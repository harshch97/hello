<?php
    $assets_url = ASSETS_URL;
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<link rel="icon" href="<?php echo $assets_url; ?>images/favicon.ico">
		<script>
			var assets_url = '<?php echo $assets_url; ?>';
			var site_url = '<?php echo SITE_URL; ?>';
			var user_id = '<?php echo getUserId(); ?>';
		</script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
		<script type="text/javascript" src="<?php echo $assets_url; ?>js/infinite-rotator.js"></script>
		<script type="text/javascript" src="<?php echo $assets_url; ?>js/script.js"></script>
		<script type="text/javascript" src="<?php echo $assets_url; ?>js/sweet-alert.min.js"></script>
		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/bootstrap.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/0.4.2/sweet-alert.min.css" />
		<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/style.css" >
		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/media.css" >
	</head>
	<body>
		<nav class="navbar navbar-fixed-top navbar-modify">
			<div class="container-width">
				<div class="row">
					<div class="col-sm-1 col-xs-12">
						<div class="navbar-brand logo"></div>
					</div>
					<div class="col-sm-6 col-xs-12">
						<div class="menu-color">
							<div class="navbar-header">
								<button type="button" id="responsiveMenu" class="navbar-toggle navbar-responsive responsiveMenu" data-toggle="collapse" data-target="#myNavbar">
									<span class="icon-bar icon-color"></span>
									<span class="icon-bar icon-color"></span>
									<span class="icon-bar icon-color"></span>   
								</button>
							</div>
							<div class="collapse navbar-collapse navbar-color" id="myNavbar">
								<ul class="nav navbar-nav" id="menu">
									<li class="active"><a href="<?php echo SITE_URL; ?>home" title="Home" class="a">HOME</a></li>
									<?php
									foreach ($menuList as $row) {
									for($i=0;$i<=0;$i++){
										if(!empty($row[1])){
											?>
											<li value="<?php echo $row[$i]['id']; ?>" class="dropdown dropdown-li">
												<a title="<?php echo $row[$i]['name']; ?>" class="dropdown-toggle a" data-toggle="dropdown" ><?php echo $row[$i]['name']; ?></a>
												<ul class="dropdown-menu navbar-submenu" id="submenu">
												<?php
												for($j=0;$j<count($row[1]);$j++){
													?>
													<li value="<?php echo $row[$i]['id']; ?>">
														<a class="submenu" href="<?php echo SITE_URL; ?>product/listing/<?php echo strtolower($row[$i]['name']); ?>/<?php echo str_replace(" ","_",strtolower($row[1][$j]['name'])); ?>"><?php echo $row[1][$j]['name']?></a>
													</li>
													<?php
												}
												?>
												</ul> 
											</li>
											<?php
								    	}
								    	else{
								    		// echo $row[$i]['name'] . "empty";
								    		?>
								    		<li value="<?php echo $row[$i]['id']; ?>">
								    			<a href="<?php echo SITE_URL; ?>product/listing/<?php echo strtolower($row[$i]['name']); ?>" class="a" title="<?php echo $row[$i]['name']; ?>"><?php echo $row[$i]['name']; ?></a>
								    		</li>
								    		<?php
								    	}
								    }
									?>
									<?php
								}
								?>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-sm-5 col-xs-12 small-device">
						<ul class="nav navbar-nav navbar-right">
							<?php if(!checkIfLogin()) { ?>
					      	<li class="login-logout"><a href="#" type="button" data-toggle="modal" data-target="#loginModal" data-backdrop="static" data-keyboard="false" title="Login">Login</a></li>
					      	<?php } else { ?>
							<li><div class="welcome-message">Welcome, <div id="welcome-message" style="display: inline-block;"><?php echo ucfirst(getLoginUserName()); ?></div></div></li>
					      	<li><div class="vl small"></div></li>
					      	<li class="responsive"><a title="Profile" href="<?php echo SITE_URL; ?>profile" >Profile</a></li>
					      	<li><div class="vl"></div></li>
					      	<li class="responsive login-logout">
					      		<!-- <a title="Logout" href="<?php echo SITE_URL; ?>logout" onclick="return confirm('Are you sure?');" >Logout</a> -->
					      		<a title="Logout" id="logout">Logout</a>
					      	</li>
							<?php
							}
							?>
					      	<li><div class="vl"></div></li>
					      	<li><a data-placement="bottom" class="cart-a" id="cart" data-toggle="popover" data-trigger="focus" data-title="Recently added item(s)" data-container="body" type="button" data-html="true" ><div class="cart" title="cart"></div></a>
						    <div id="popover-content" class="dropdown-menu popover-data" style="display: none;">
					      		<?php
						    	if(empty($_SESSION["cart"])){
						    		?>
						    		<h3 class="popover-title" id="popover-title">No item(s) in cart</h3>
						    		<?php
						    	}
						    	else{
						    	?>
						      		<h3 class="popover-title">Recently added item(s)</h3>
							    	<table class="table table-responsive table-border">
							    		<tbody class="scrollContent">
							    			<?php
							    			// foreach (array_slice($_SESSION["cart"],count($_SESSION["cart"])-2,2) as $cartItem) {
							    			foreach ($_SESSION["cart"] as $cartItem) {
							    				// print_r($cartItem);
							    				$totalPerItem=$cartItem['price']*$cartItem['qty'];
							    				$subtotal+=$totalPerItem;
							    			?>
										    <tr>
										        <td class="cart-img"><img src="<?php echo $assets_url; ?>images/<?php echo $cartItem['item_image_url']; ?>"></td>
										        <td class="font-size-td"><?php echo $cartItem['name']; ?><div class="last-item">$<?php echo $cartItem['price']; ?>.00</div><div class="detail">Qty : <?php echo $cartItem['qty']; ?><br>Size : <?php echo $cartItem['value']; ?></div></td>
										        <td class="td-width"><div class="edit-popup"></div></td>
										        <td class="td-width"><a><div class="cancel-popup" title="<?php echo $cartItem['id']; ?>"></div></a></td>
									      	</tr>
									      	<?php
									      	}
									      	?>
								      	</tbody>
								      	<tbody>
										    <tr>
										        <td colspan="2" class="font-cart">Cart Subtotal : </td><td colspan="2"><div class="total last-item position-td">$<?php echo $subtotal; ?>.00</div></td>
									      	</tr>
								      	</tbody>
							    	</table>
							    	<div class="row btn-align">
							    		<div class="col-sm-12 col-xs-12">
							    			<a href="<?php echo SITE_URL; ?>cart" class="btn update-btn">View Cart</a>
							    		</div>
							    	</div>
						    	<?php
						    	}
						    	?>
						    </div></li>
					      	<li><div class="vl small"></div></li>
					      	<li class="search-a">
					      		<div class="box">
									<input class="search-box" type="search" placeholder="Search" id="search"  />
									<ul id="searchText"></ul>
								</div>
					      		<a id="search-btn" class="border-a" title="Search"><div class="search1" id="search1"></div></a>
					      	</li>
			    		</ul>
					</div>
				</div>
			</div>
		</nav>
		<!-- Modal -->
		<div class="modal fade" id="loginModal" role="dialog">
			<div class="modal-dialog">
		  	<!-- Modal content-->
		      	<div class="modal-content modal-width">
			        <div class="modal-header">
			          <button type="button" class="close" data-dismiss="modal">&times;</button>
			          <h4 class="modal-title text-align-modal">eShopper Login</h4>
			        </div>
			        <div class="modal-body body-padding">
			          	<form name="loginForm" id="loginForm" action="" method="post">
							<div class="row">
					        	<div class="col-sm-12 col-xs-12 collapse" id="invalidAlert">
								  	<div class="alert alert-danger alert-dismissable">
								    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
								    	<div class="row">
								    		<div class="col-sm-1 col-xs-1 error-icon">
								    		</div>
								    		<div class="col-sm-11 col-xs-11 modal-data-display" id="invalidMsg">
								    		</div>
								    	</div>
								  	</div> 
								</div>
								<div class="col-sm-12 col-xs-12 collapse" id="successAlert">
								  	<div class="alert alert-success alert-dismissable">
								    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
								    	<div class="row">
								    		<div class="col-sm-1 col-xs-1 success-icon">
								    		</div>
								    		<div class="col-sm-11 col-xs-11 modal-data-display" id="successMsg">	
								    		</div>
								    	</div>
								  	</div>
								</div>
								<div class="col-sm-12 col-xs-12">
								  	<div class="form-group modal-group-height">
									    <label for="username">Username</label>
									    <input type="text" class="form-control" id="username" placeholder="Enter your username" name="username">
								  	</div>
								</div>
								<div class="col-sm-12 col-xs-12">
								  	<div class="form-group modal-group-height">
									    <label for="password">Password</label>
									    <input type="password" class="form-control" id="password" placeholder="Enter your password" name="password">
								  	</div>
								</div>
					      	</div>
					      	<div class="row">
								<div class="col-sm-3 col-xs-5">
									<input type="button" value="Login" id="login_btn" class="btn login-btn">
								</div>
								<div class="col-sm-9 col-xs-7">
									<p class="pull-right content-top">Not a Member?&nbsp;<a href="<?php echo SITE_URL; ?>register">Register</a></p>
								</div>
							</div>
					    </form>
					</div>
				</div>
			</div>
		</div>
