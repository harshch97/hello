<?php
error_reporting(0);
?>

<div class="footer">
	<div class="container">
		<div class="form-container">
			<form class="form-inline" method="post">
				<div class="row">
				<div class="form-group col-sm-4 col-lg-4">
					<div class="col-sm-12">&nbsp;</div>
					<div class="col-sm-12">
						<p>Subscribe for Newsletter</p>
					</div>
				</div>
				<div class="form-group col-sm-6 col-lg-6">
					<div class="col-sm-12 success-message" id="success_msg">&nbsp;</div>
					<input type="email" required class="form-control input-box" name="email" id="email" placeholder="Enter your email address">
				</div>
				<div class="form-group col-sm-2 col-lg-2">
					<div class="col-sm-12">&nbsp;</div>
					<div class="col-sm-12">
						<input type="button" class="btn footer-btn-style center-block" id="subscriber-btn" value="SIGN IN">
					</div>
				</div>
				</div>
			</form>
		</div>
		<div class="footer-menu">
			<div class="container-fluid">
				<ul class="nav navbar-nav navbar-xs">
					<li class="active menu"><a href="<?php echo SITE_URL; ?>">Home</a></li>
					<li><a href="<?php echo SITE_URL; ?>aboutus">About us</a></li>
					<?php
						if(!isset($_SESSION['name']) || $_SESSION['name']==''){
							?>
						<li><a href="<?php echo SITE_URL; ?>register">Register</a></li>
						<?php
						}
						else
						{
						?>
							<li><a href="<?php echo SITE_URL; ?>profile">Profile</a></li>
						<?php
						}
						?>
					<li><a href="<?php echo SITE_URL; ?>contact">Contact us</a></li>
				</ul>
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="col-sm-12 footer-data">
				<p>&copy; 2017 eShopper online store. All rights reserved.</p>
			</div>
		</div>
	</div>
</div>