<?php
    $assets_url = ASSETS_URL;
    error_reporting(0);
?>
	<head>
		<title>eShopper Online Store</title>
		
  		<meta name="viewport" content="width=device-width, initial-scale=1">  
		<script type="text/javascript" src="<?php echo $assets_url; ?>js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?php echo $assets_url; ?>js/product.js"></script>
  		<!-- <script type="text/javascript" src="<?php echo $assets_url; ?>js/script.js"></script> -->
  		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/style.css" >
		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/media.css" >
	</head>
	<body>
		<!--	Main content 	-->
 		<div class="banner image image-reponsive parent">
			<div id="rotating-item-wrapper">
				<img src="<?php echo $assets_url; ?>images/banner.jpg" alt="banner" class="rotating-item banner-img" />
				<img src="<?php echo $assets_url; ?>images/banner1.jpg" alt="banner1" class="rotating-item banner-img"/>
				<img src="<?php echo $assets_url; ?>images/banner2.jpg" alt="banner2" class="rotating-item banner-img"/>
			</div>
			<a class="prev-arrow" onclick="next(-1)">
				<div id="pre-arrow"></div>
			</a>
			<a class="next-arrow" onclick="next(1)">
				<div id="next-arrow"></div>
			</a>
		</div>
		<div class="container">
			<div class="background-content">
				<div class="row">
					<div class="col-sm-4">
						<div class="row">
							<div class="col-sm-2 col-xs-2">
								<a><img id="icon1" src="<?php echo $assets_url; ?>images/img_transparent.png" /></a>
							</div>
							<div class="col-sm-10 col-xs-10 data">
								<p>Free Delivery Worldwide</p>
								At vero eos et accusamus et iusto odio 
							</div>
						</div>
					</div>
					<div class="col-sm-4">
						<div class="row">
							<div class="col-sm-2 col-xs-2">
								<a><img id="icon2" src="<?php echo $assets_url; ?>images/img_transparent.png" /></a>
							</div>
							<div class="col-sm-10 col-xs-10 data">
								<p>Free Return For 90 Days</p>
								At vero eos et accusamus et iusto odio 
							</div>
						</div>
					</div>
					<div class="col-sm-4">
						<div class="row">
							<div class="col-sm-2 col-xs-2">
								<a><img id="icon3" src="<?php echo $assets_url; ?>images/img_transparent.png" /></a>
							</div>
							<div class="col-sm-10 col-xs-10 data">
								<p>Discount on Order Gift</p>
								At vero eos et accusamus et iusto odio 
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="title">
				<p>Trending Products</p>
			</div>
			<div class="row">
				<div class="col-sm-12 col-xs-12 collapse" id="insertAlert">
				  	<div class="alert alert-success alert-dismissable">
				    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
				    	<div class="row">
				    		<div class="col-sm-1 col-xs-1 success-icon">
				    		</div>
				    		<div class="col-sm-11 col-xs-11 data-display" id="insertItem">	
				    		</div>
				    	</div>
				  	</div>
				</div>
				<div class="col-sm-12 col-xs-12 collapse" id="loginAlert">
				  	<div class="alert alert-danger alert-dismissable">
				    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
				    	<div class="row">
				    		<div class="col-sm-1 col-xs-1 error-icon">
				    		</div>
				    		<div class="col-sm-11 col-xs-11 data-display" id="loginMsg">
				    		</div>
				    	</div>
				  	</div> 
				</div>
			</div>
			<section>
				<div class="row description">
					<ul id="products">
						<?php 
						foreach ($product as $row) {
							// echo "<pre>";print_r($product);exit();
							?>
							<li>
								<div class="col-sm-3 product-block" title="<?php echo $row['item_id']?>">
									<div class="background-color">
										<img src="<?php echo $assets_url; ?>images/<?php echo $row['item_image_url']?>" class="img-rounded image" >
										<div class="middle">
									    	<div class="rollover-btn">
									    		<a class="addToCart" title="<?php echo $row['id']?>">Add to Cart</a>
									    	</div>
									  	</div>
									</div>
									<div class="row">
										<div class="col-sm-12"><p><?php echo $row['name']; ?><sub class="sub"> [Size:<?php echo $row['value']; ?>]</sub></p>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-12 price">
											<p><b>$<?php echo $row['price']; ?>.00</b></p>
										</div>
									</div>
								</div>
							</li>
						<?php
						}
						?>
					</ul>
				</div>
				<div class="row">
					<div class="col-sm-12 col-xs-12">
						<div class="more-product-btn">
							<input class="btn center-block btn-style" type="button" value="More Products" id="more-product-btn" >
						</div>
					</div>
				</div>
		</section>
		<a id="topBtn" title="Go to top"><img class="up-arrow" src="<?php echo $assets_url; ?>images/img_transparent.png"></div></a>
		<div class="bottom-banner image-banner image-reponsive">
			<img src="<?php echo $assets_url; ?>images/px.jpg">
			<div class="banner-content">
				<div class="row">
					<div class="col-sm-12">
						<b>Get the</b> latest 
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12 padding-xs">
						<b>womens</b> fashion
					</div>
				</div>				
				<div class="row">
					<div class="col-sm-12">
						<button class="btn banner-btn-style" type="button">Get Exclusive Collection For Women</button>	
					</div>
				</div>
			</div>
		</div>
		<!--	Testimonial		-->
		<div class="title">
			<p>Testimonial</p>
		</div>
		<div class="container">
			<div class="row">
	    		<div class="col-sm-2 col-xs-0"></div>
	    		<div class="col-sm-8 col-xs-12">
					<div class="carousel slide" data-ride="carousel" id="testimonial-carousel">
						
						<ul class="carousel-indicators">
						  	<li data-target="#testimonial-carousel" data-slide-to="0" class="active"></li>
						  	<li data-target="#testimonial-carousel" data-slide-to="1"></li>
						  	<li data-target="#testimonial-carousel" data-slide-to="2"></li>
						  	<li data-target="#testimonial-carousel" data-slide-to="3"></li>
						</ul>
						
						<div class="carousel-inner">
							<div class="item active">
								<div class="row">
	    							<div class="col-sm-12 col-xs-12">
	    								<div class="top-border"></div>
    									<div class="row testimonial">
    										<div class="col-sm-3 col-xs-12 right-line">
    											<div class="media">
												    <div class="media-left">
												      	<img src="<?php echo $assets_url; ?>images/testimonial_3.jpg" class="media-object" style="width:60px">
												    </div>
												    <div class="media-body">
												      	<div  class="font-size-p"><p>John Clay</p></div>
												      	<div  class="font-size-caption"><p>Cyclist</p></div>
												    </div>
												</div>
    										</div>
    										<div class="col-sm-9 col-xs-12">
    											<p>You can use box-shadow to make a border effect, by making theshadow offset and have 0 blur.You can use box-shadow<br>You can use box-shadow to make a border effect, by making the<br>shadow offset and have 0 blur.You can use box-shadow<br>You can use box-shadow</p>
    										</div>
    									</div>
	    								<div class="bottom-border"></div>
	    							</div>
	    						</div>
	    					</div>
	    					<div class="item">
								<div class="row">
	    							<div class="col-sm-12 col-xs-12">
	    								<div class="top-border"></div>
    									<div class="row testimonial">
    										<div class="col-sm-3 col-xs-12 right-line">
    											<div class="media">
												    <div class="media-left">
												      	<img src="<?php echo $assets_url; ?>images/testimonial_3.jpg" class="media-object" style="width:60px">
												    </div>
												    <div class="media-body">
												      	<div  class="font-size-p"><p>John Clay</p></div>
												      	<div  class="font-size-caption"><p>Cyclist</p></div>
												    </div>
												</div>
    										</div>
    										<div class="col-sm-9 col-xs-12">
    											<p>You can use box-shadow to make a border effect, by making theshadow offset and have 0 blur.You can use box-shadow<br>You can use box-shadow to make a border effect, by making the<br>shadow offset and have 0 blur.You can use box-shadow<br>You can use box-shadow</p>
    										</div>
    									</div>
	    								<div class="bottom-border"></div>
	    							</div>
	    						</div>
	    					</div>
	    					<div class="item">
								<div class="row">
	    							<div class="col-sm-12 col-xs-12">
	    								<div class="top-border"></div>
	    								<div class="row testimonial">
    										<div class="col-sm-3 col-xs-12 right-line">
    											<div class="media">
												    <div class="media-left">
												      	<img src="<?php echo $assets_url; ?>images/testimonial_3.jpg" class="media-object" style="width:60px">
												    </div>
												    <div class="media-body">
												      	<div  class="font-size-p"><p>John Clay</p></div>
												      	<div  class="font-size-caption"><p>Cyclist</p></div>
												    </div>
												</div>
    										</div>
    										<div class="col-sm-9 col-xs-12">
    											<p>You can use box-shadow to make a border effect, by making theshadow offset and have 0 blur.You can use box-shadow<br>You can use box-shadow to make a border effect, by making the<br>shadow offset and have 0 blur.You can use box-shadow<br>You can use box-shadow</p>
    										</div>
    									</div>
	    								<div class="bottom-border"></div>
	    							</div>
	    						</div>
	    					</div>
	    					<div class="item">
								<div class="row">
	    							<div class="col-sm-12 col-xs-12">
	    								<div class="top-border"></div>
	    								<div class="row testimonial">
    										<div class="col-sm-3 col-xs-12 right-line">
    											<div class="media">
												    <div class="media-left">
												      	<img src="<?php echo $assets_url; ?>images/testimonial_3.jpg" class="media-object" style="width:60px">
												    </div>
												    <div class="media-body">
												      	<div  class="font-size-p"><p>John Clay</p></div>
												      	<div  class="font-size-caption"><p>Cyclist</p></div>
												    </div>
												</div>
    										</div>
    										<div class="col-sm-9 col-xs-12">
    											<p>You can use box-shadow to make a border effect, by making theshadow offset and have 0 blur.You can use box-shadow<br>You can use box-shadow to make a border effect, by making the<br>shadow offset and have 0 blur.You can use box-shadow<br>You can use box-shadow</p>
    										</div>
	    								</div>
	    								<div class="bottom-border"></div>
	    							</div>
	    						</div>
	    					</div>
	    				</div>
	    			</div>
	    		</div>
	    		<div class="col-sm-2 col-xs-0"></div>
			</div>
		</div>
		<script src="<?php echo $assets_url; ?>js/carousel.js"></script>