$(document).ready(function(){
 jQuery('.skdslider').skdslider({delay:5000, animationSpeed: 2000,showNextPrev:true,showPlayButton:false,autoSlide:true,animationType:'fading'});
});