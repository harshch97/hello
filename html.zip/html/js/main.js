

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("#myBtn").style.display = "block";
    } else {
        document.getElementById("#myBtn").style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
    // scroll body to 0px on click
    $('#myBtn').click(function () {
        $('body,html').animate({
            scrollTop: 0
        }, 1600);
        return false;
    });

  $(function(){
 $("[data-toggle=popover]").popover({
     html: true, 
     toggle: true,
  content: function() {

           return $('#content-pop').html();


         }
 });
});

$('.icon').click(function () {
    $('.searchtext').toggleClass('expanded');
});

function validateForm() {
    var username = document.forms["myForm"]["username"];
    var password = document.forms["myForm"]["pwd"];
    if (username.value == "") {
        alert("username must be filled out");
       
        username.focus();
         return false;
    }
   
    else if (password.value == "") {
        alert("password must be filled out");
        return false;
    }
    else{
    	return true;
    }
}
var total;
function qtychangeprice() {
    var qty = document.getElementById("qty").value;
    
    total=qty*120.00;


    document.getElementById("price").innerHTML = "$" + total;
} 

function addtocart(){

	var result=confirm("Are you sure want to purchase this product"+"\n"+"Your total bill amount is"+total);
  if (result)
  {
   window.location.href = 'cart.html'; 
  }
}




function validateregisterform()
{
    var regexuser = /^[a-zA-Z]{8,30}$/;
    var ctrluser = document.forms["register"]["username"];
    var regexpwd = /^[a-zA-Z0-9!@#$%^&*]{6,16}$/;
    var ctrlpwd = document.forms["register"]["pwd"];
    var regexemail=/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
    var ctrlemail=document.forms["register"]["email"];
    var regexmno=/^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;
    var ctrlmno=document.forms["register"]["mno"];
    var regexpno=/^\d{10}$/;
    var ctrlpno=document.forms["register"]["pno"];
    var regexfname=/^[a-zA-Z ]{2,30}$/;
    var ctrlfname=document.forms["register"]["fname"];
     var regexlname=/^[a-zA-Z ]{2,30}$/;
    var ctrllname=document.forms["register"]["lname"];
    /*/^(?=.*[a-z])(?=(?:[:[^A-Z]*[A-Z]){2})(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%]/*/


  if (ctrluser.value == "") {
        document.getElementById("usrwrong").innerHTML="username required";
        ctrluser.focus();
        return false;
        }

      else
  {
       document.getElementById("usrwrong").innerHTML="";
  }
  if (regexuser.test(ctrluser.value)==false) {

        document.getElementById("usrwrong").innerHTML="usrname should contain 8 character";
        ctrluser.focus();
        return false;
      }
  else
  {
       document.getElementById("usrwrong").innerHTML="";
  }
     
     if (ctrlpwd.value=="") {
        document.getElementById("password").innerHTML="password required";
        ctrlpwd.focus();
        return false;
    }
    else
    {
      document.getElementById("password").innerHTML="";
    }
  if (regexpwd.test(ctrlpwd.value)==false) {
        document.getElementById("password").innerHTML="password contain special symbol and character";
        ctrlpwd.focus();
        return false;
    }
     else
    {
      document.getElementById("password").innerHTML="";
    }
    
    if (ctrlemail.value=="") {
         document.getElementById("emailwrong").innerHTML="email required";
        ctrlemail.focus();
        return false;
    }
    else
     {
      document.getElementById("emailwrong").innerHTML="";
    }
   if (regexemail.test(ctrlemail.value)==false) {
         document.getElementById("emailwrong").innerHTML="please enter valid email";
        ctrlemail.focus();
        return false;
    }
    else
     {
      document.getElementById("password").innerHTML="";
    }

    
    if (ctrlfname.value=="") {
         document.getElementById("fnamewrong").innerHTML="first name required";
        ctrlfname.focus();
        return false;
    }
    else
     {
      document.getElementById("fnamewrong").innerHTML="";
    }
     if (regexfname.test(ctrlfname.value)==false) {
         document.getElementById("fnamewrong").innerHTML="please enter first name in alphabet";
        ctrlfname.focus();
        return false;
    }
    else
     {
      document.getElementById("fnamewrong").innerHTML="";
    }
    
    if (ctrlmno.value=="") {
         document.getElementById("mnowrong").innerHTML="mobile number required";
        ctrlmno.focus();
        return false;
    }
     else
     {
      document.getElementById("mnowrong").innerHTML="";
    }
    if (regexmno.test(ctrlmno.value)==false) {
         document.getElementById("mnowrong").innerHTML="please enter valid mobile number";
        ctrlmno.focus();
        return false;
    }
      else
     {
      document.getElementById("mnowrong").innerHTML="";
    }
    
    if (ctrllname.value=="") {
         document.getElementById("lanmewrong").innerHTML="last name required";
        ctrllname.focus();
        return false;
    }
     else
     {
      document.getElementById("lanmewrong").innerHTML="";
    }
     if (regexlname.test(ctrllname.value)==false) {
         document.getElementById("lanmewrong").innerHTML="please enter first name in alphabet";
        ctrllname.focus();
        return false;
    }
     else
     {
      document.getElementById("lanmewrong").innerHTML="";
    }

    
    
    if(document.getElementById('Term').checked){
      document.getElementById("terms").innerHTML="";
     
    } 
    
    else { 
        document.getElementById("terms").innerHTML="please accept terms and condition";
        return false; 
    }
   
}

function reset(){
    confirm("clear all the data in form");
     document.getElementById("register").reset();
}

function toggle(source) {
  checkboxes = document.getElementsByName('chk');
  for(var i=0, n=checkboxes.length;i<n;i++) {
    checkboxes[i].checked = source.checked;
  }
}

function enable(){
    if(document.getElementById("Other").checked){
    document.getElementById("others").style.display="inline-block";
}
else{
    document.getElementById("others").style.display="none";

}
}


function same(){
    var check=document.getElementById("billch").checked;
    if(check==true){
    var street = document.getElementById("street").value;
    var city = document.getElementById("city").value;
    var country = document.getElementById("country").value;
    
    document.getElementById("street1").value=street;
    document.getElementById("city1").value=city;
    document.getElementById("country1").value=country;
    document.getElementById("street1").disabled = true;
    document.getElementById("city1").disabled = true;
    document.getElementById("country1").disabled = true;
  }
  else{
    document.getElementById("street1").disabled = false;
    document.getElementById("city1").disabled = false;
    document.getElementById("country1").disabled = false;
    document.getElementById("street1").value="";
    document.getElementById("city1").value="";
    document.getElementById("country1").value="";
  }
    
  
  
}

  $("#billch").click(function(){
    var check1=document.getElementById("billch").checked;
    if(check1==true){
 var $options = $("#state > option").clone();
  $('#state1').empty();
  $('#state1').append($options);
  $('#state1').val($('#state').val());
  $('#state1').attr("disabled", true);
}
else{
  $('#state1').empty();
  $('#state1').val("");
  $('#state1').attr("disabled", false);
}

})

$(".cart").click(function(){
    $(".popcart").slideToggle(1000);
});

$(".rate").mouseover(function(){
  $(".rate").css('background-image','../images/star-h.svg');
})

// $(document).ready(function(){
 // jQuery('.skdslider').skdslider({delay:5000, animationSpeed: 2000,showNextPrev:true,showPlayButton:false,autoSlide:true,animationType:'fading'});
// });

var index = 1;
   show(index);

   function plus(n) {
     show(index += n);
   }

   function show(n) {
     var i;
     var x = $(".topbanpad");
     if (n > x.length) {index = 1}    
     if (n < 1) {index = x.length}
     for (i = 0; i < x.length; i++) {
        $(x[i]).hide();  
     }
     $(x[index-1]).fadeIn();  
   }

   // $(document).ready(function() {
  //carousel options
  // $('#quote-carousel').carousel({
    // pause: true, interval: 1000,
  // });
// });



     $('#myCarousel').carousel({
  interval: 4000
})

$('.detail .item').each(function(){
  var next = $(this).next();
  if (!next.length) {
    next = $(this).siblings(':first');
  }
  next.children(':first-child').clone().appendTo($(this));
  
  for (var i=0;i<2;i++) {
    next=next.next();
    if (!next.length) {
      next = $(this).siblings(':first');
    }
    
    next.children(':first-child').clone().appendTo($(this));
  }
});

$('#thumbs img').click(function(){
    $('#largeImage').attr('src',$(this).attr('src'));
    $('#description').html($(this).attr('alt'));
});
