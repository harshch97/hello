
var country_arr = new Array("Afghanistan", "Indai");
var country_arr = new Array("Afghanistan", "Indai");

// States
var s_a = new Array();
s_a[0]="";
s_a[1]="Badakhshan|Badghis";
s_a[2]="Gujarat|Maharastra|Bihar";


function populateStates( countryElementId, stateElementId ){
	
	var selectedCountryIndex = document.getElementById("country").selectedIndex;

	var stateElement = document.getElementById("state");
	
	stateElement.length=0;	// Fixed by Julian Woods
	stateElement.options[0] = new Option('Select State','');
	stateElement.selectedIndex = 0;
	
	var state_arr = s_a[selectedCountryIndex].split("|");
	
	for (var i=0; i<state_arr.length; i++) {
		stateElement.options[stateElement.length] = new Option(state_arr[i],state_arr[i]);
	}
}

function populateCountries(countryElementId, stateElementId){
	// given the id of the <select> tag as function argument, it inserts <option> tags
	var countryElement = document.getElementById("country");
	countryElement.length=0;
	countryElement.options[0] = new Option('Select Country','-1');
	countryElement.selectedIndex = 0;
	for (var i=0; i<country_arr.length; i++) {
		countryElement.options[countryElement.length] = new Option(country_arr[i],country_arr[i]);
	}

	// Assigned all countries. Now assign event listener for the states.

	if( stateElementId ){
		countryElement.onchange = function(){
			populateStates( countryElementId, stateElementId );
		};
	}
}

function populateStates1( countryElementId1, stateElementId1 ){
	
	var selectedCountryIndex = document.getElementById("country1").selectedIndex;

	var stateElement = document.getElementById("state1");
	
	stateElement.length=0;	// Fixed by Julian Woods
	stateElement.options[0] = new Option('Select State','');
	stateElement.selectedIndex = 0;
	
	var state_arr = s_a[selectedCountryIndex].split("|");
	
	for (var i=0; i<state_arr.length; i++) {
		stateElement.options[stateElement.length] = new Option(state_arr[i],state_arr[i]);
	}
}

function populateCountries1(countryElementId1, stateElementId1){
	// given the id of the <select> tag as function argument, it inserts <option> tags
	var countryElement = document.getElementById("country1");
	countryElement.length=0;
	countryElement.options[0] = new Option('Select Country','-1');
	countryElement.selectedIndex = 0;
	for (var i=0; i<country_arr.length; i++) {
		countryElement.options[countryElement.length] = new Option(country_arr[i],country_arr[i]);
	}

	// Assigned all countries. Now assign event listener for the states.

	if( stateElementId1 ){
		countryElement.onchange = function(){
			populateStates1( countryElementId1, stateElementId1 );
		};
	}
}