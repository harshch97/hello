function registerValidate(){

    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    var firstname = document.getElementById('firstname').value;
    var lastname = document.getElementById('lastname').value;
    var email= document.getElementById('email').value;
    var phone = document.getElementById('phone').value;
    var mobile = document.getElementById('mobile').value;
    var gender=document.getElementById('gender');
    var street=document.getElementById('street');
     var city=document.getElementById('city');
    if (username===""){
        document.getElementById("username_error").innerHTML = "Please enter username";
        document.getElementById("username").focus();
        return false;
    }
    else{document.getElementById("username_error").innerHTML = "";}
    
    if (username.length <= 8){
        document.getElementById("username_error").innerHTML = "The lenght of username must be atleast eight digits";
        document.getElementById("username").focus();
        return false;
    }
    else{document.getElementById("username_error").innerHTML = "";}
    
    if (( document.register.gender[0].checked ===false ) && ( document.register.gender[1].checked === false)) 
    {
        document.getElementById("gender_error").innerHTML = "Please Select your gender";
        document.getElementById("gender").focus();
        return false;
    }
    else{document.getElementById("gender_error").innerHTML = "";}
   
    if (password===""){
        document.getElementById("password_error").innerHTML = "Please enter password";
        document.getElementById("password").focus();
        return false;
    }
    else{document.getElementById("password_error").innerHTML = "";}
//    ^(?=(.*[A-Z]){2})(?=.*?[0-9])(?=.*?[!@#$%^&*])[a-zA-Z0-9!@#$%\^&\*]{4,}$
//    if(/^(?=.*[a-z])(?=(?:[:[^A-Z]*[A-Z]){2})(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]/.test(password)=== false)
//    {
//        document.getElementById("password_error").innerHTML = "Please enter at least one Number , one symbol , '2' Capital Letter";
//        document.getElementById("password").focus();
//        return false;
//    }
    
    if(/\d{1}/.test(password)===false){
        document.getElementById("password_error").innerHTML = "password has atleast one number";
        document.getElementById("password").focus();
        return false;
    }
    else{document.getElementById("password_error").innerHTML = "";}
    
    if(/[A-Z]{2}/.test(password)===false){
        document.getElementById("password_error").innerHTML = "password has atleast two capital letter";
        document.getElementById("password").focus();
        return false;
    }
    else{document.getElementById("password_error").innerHTML = "";}
    
    if(/[!@#$%^&*(){}[\]<>?/|.:;_-]/.test(password)===false){
        document.getElementById("password_error").innerHTML = "password has atleast one symbol";
        document.getElementById("password").focus();
        return false;
    }
    else{document.getElementById("password_error").innerHTML = "";}
    
    if (email===""){
        document.getElementById("email_error").innerHTML = "Please enter email";
        document.getElementById("email").focus();
        return false;
    }  
    else{document.getElementById("email_error").innerHTML = "";}
    
    if (/^[a-z0-9._-]+@[a-z0-9.-]+\.[a-z]{2,3}$/.test(email)=== false)
    {
        document.getElementById('email_error').innerHTML="please enter valid email-id";  
        document.getElementById("email").focus();
        return false;
    }
    else{document.getElementById("email_error").innerHTML = "";}
    
    if (firstname===""){
        document.getElementById("firstname_error").innerHTML = "Please enter firstname";
        document.getElementById("firstname").focus();
        return false;
    }
    else{document.getElementById("firstname_error").innerHTML = "";}
    
    if(/^[A-z]+$/.test(firstname)===false){
        document.getElementById("firstname_error").innerHTML = "In firstname only allow alphabetic";
        document.getElementById("firstname").focus();
        return false;
    }
    else{document.getElementById("firstname_error").innerHTML = "";}
    
    if (lastname===""){
        document.getElementById("lastname_error").innerHTML = "Please enter lastname";
        document.getElementById("lastname").focus();
        return false;
    } 
    else{document.getElementById("lastname_error").innerHTML = "";}
    
    if (mobile===""){
        document.getElementById("mobile_error").innerHTML = "Please enter mobile";
        document.getElementById("mobile").focus();
        return false;
    }
    else{document.getElementById("mobile_error").innerHTML = "";}
    
    if (/^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/.test(mobile)===false){
        document.getElementById("mobile_error").innerHTML = "you have to enter valid numbers";
        document.getElementById("mobile").focus();
        return false;
    }
    else{document.getElementById("mobile_error").innerHTML = "";}
    
    if (phone!==""){
        if(/^[0-9]*$/.test(phone)===false){
        document.getElementById("phone_error").innerHTML = "Please enter only numbers";
        document.getElementById("phone").focus();
        return false;
        }
        else{document.getElementById("phone_error").innerHTML = "";}
    }
    
    if (document.getElementById('all').checked === false && document.getElementById('option1').checked === false && document.getElementById('option2').checked === false && document.getElementById('option2').checked === false && document.getElementById('other').checked === false) 
    {
        document.getElementById("checkbox_error").innerHTML = "Please select your interests";
        document.getElementById("all").focus();
        return false;
    }else{document.getElementById("checkbox_error").innerHTML = "";}
    
    if (document.register.term.checked === false){
        document.getElementById("term_error").innerHTML = "Please select Terms & Conditions.";
        document.getElementById("terms").focus();
        return false;
    }else{document.getElementById("term_error").innerHTML = "";}
    var add=document.getElementById("add").value;
    
    if (street===""){
        document.getElementById("street_error").innerHTML = "Please enter your street";
        document.getElementById("street").focus();
        return false;
    }else{document.getElementById("street_error").innerHTML = "";}
    
    if (city===""){
        document.getElementById("city_error").innerHTML = "Please enter your city";
        document.getElementById("city").focus();
        return false;
    }else{document.getElementById("city_error").innerHTML = "";}
    
    if (document.getElementById("country").selectedIndex == 0) {
    document.getElementById("country").focus();  
    document.getElementById("country_error").innerHTML = "Please select country";
    valid = false;
    } else {
    document.getElementById("country_error").innerHTML = "";
    }
    
    if (document.getElementById("state").selectedIndex == 0) {
    document.getElementById("state").focus();  
    document.getElementById("state_error").innerHTML = "Please select state";
    valid = false;
    } else {
    document.getElementById("state_error").innerHTML = "";
    }
    
    if (b_street===""){
        document.getElementById("b_street_error").innerHTML = "Please enter your street";
        document.getElementById("street").focus();
        return false;
    }else{document.getElementById("street_error").innerHTML = "";}
    
    if (b_city===""){
        document.getElementById("city_error").innerHTML = "Please enter your city";
        document.getElementById("city").focus();
        return false;
    }else{document.getElementById("city_error").innerHTML = "";}
    
    if (document.getElementById("b_country").selectedIndex == 0) {
    document.getElementById("country").focus();  
    document.getElementById("country_error").innerHTML = "Please select country";
    valid = false;
    } else {
    document.getElementById("country_error").innerHTML = "";
    }
    
    if (document.getElementById("state").selectedIndex == 0) {
    document.getElementById("state").focus();  
    document.getElementById("state_error").innerHTML = "Please select state";
    valid = false;
    } else {
    document.getElementById("state_error").innerHTML = "";
    }
}

    


function selectAll() {
    if(document.getElementById('all').checked === true){
        var items = document.getElementsByName('c');
        for (var i = 0; i < items.length-1; i++) {
            if (items[i].type === 'checkbox')
                items[i].checked = true;
        }
        
    }
    if(document.getElementById('all').checked === false){
        var items = document.getElementsByName('c');
        for (var i = 0; i < items.length-1; i++) {
            if (items[i].type === 'checkbox')
                items[i].checked = false;
        }
        
    }
}
    
function textBoxhide(){
    if(document.getElementById('other').checked === true){
        document.getElementById('togglee').style.visibility = 'visible';
    }
    if(document.getElementById('other').checked === false){
            document.getElementById('togglee').style.visibility = 'hidden';
    }
}



function loginValidate() {
    var username = document.getElementById('username').value ;
    var password = document.getElementById('password').value ;
    if (username==="") {
        document.getElementById('username_error').innerHTML="Please enter username";
        document.getElementById('username').focus();
        return false;
    }
    if (password==="") {
        document.getElementById('password_error').innerHTML="Please enter password";
        document.getElementById('password').focus();
        return false;
    }
}

function clear(){
    document.getElementById("register").reset();
}

var total;
function total_dropdown(){
    var qty=document.getElementById('qty').value;
    var price=document.getElementById('price').innerHTML;
    total=qty*120;
    document.getElementById('price').innerHTML = total ;
}

function addcart(){
    var price=document.getElementById('price').innerHTML;
    confirm("Are you sure you want to purchase this product?\n Your total bill amount is $ " +  price + ".00");
}

function same_address(){
    var street=document.getElementById('street').value;
    var city=document.getElementById('city').value; 
    var country=document.getElementById('country').value;
    var state=document.getElementById('state').value;
    document.getElementById('b_street').value = street;
    document.getElementById('b_city').value = city;
    document.getElementById('country2').value = country;
    var selectedCountryIndex = document.getElementById( "country2" ).selectedIndex;
    populateStates("country2", "state2" , selectedCountryIndex);
    document.getElementById('state2').value=state;
}

var products = [
    ['image/cart-img01.jpg', 'US Polo Assn FullSleeve Plain T-Shirts for Men','Blue','M','image/edit-dark.svg','$222','1','$222','image/cross-dark.svg'],
    ['image/cart-img01.jpg', 'US Polo Assn FullSleeve Plain T-Shirts for Men','Blue','M','image/edit-dark.svg','$222','1','$222','image/cross-dark.svg'],
    ['image/cart-img01.jpg', 'US Polo Assn FullSleeve Plain T-Shirts for Men','Blue','M','image/edit-dark.svg','$222','1','$222','image/cross-dark.svg'],
    ['image/cart-img01.jpg', 'US Polo Assn FullSleeve Plain T-Shirts for Men','Blue','M','image/edit-dark.svg','$222','1','$222','image/cross-dark.svg']
];
 
function updatesubtotal(){
    for(var i=0;i<products.length;i++){ 
        row="<tr>";
        row+="<td><img src='"+products[i][0]+"'></td>";
        row+="<td>"+products[i][1]+"<br/><b>Color</b><br/>"+products[i][2]+"<br/><b>Size</b><br/>"+products[i][3]+"</td>";
        row+="<td><object type='image/svg+xml' class='size_icon' data='"+ products[i][4]+"'></object></td>" ;
        row+="<td class='Cart_price_color'>"+products[i][5] +"</td>";
        row+="<td class='cart_table_border1'><input type='number' value='"+products[i][6] +"'</td>";
        row+="<td class='Cart_price_color'>"+products[i][7]+"</td>";
        row+="<td onclick=''><object type='image/svg+xml' class='size_icon' data='"+ products[i][8]+"'></object></td>";
        row+="</tr>";
        $("#product").append(row);
    }
    row="<tr class='cart_table_header'>";
    row+="<td colspan='3'><button type='button' class='btn btn-default reg_clear cart_update_button'>Continue Shopping</button></td>";
    row+="<td colspan='5'><button type='button' class='btn btn-default reg_clear1 cart_update_button'>Clear Shopping Cart</button><button type='button' class='btn btn-default reg_clear1 cart_update_button'>Update Shopping Cart</button></td>";
    
    row+="</tr>";
    $("#product").append(row);
}

$(window).scroll(function(){
    var scrol=$(window).scrollTop();
		if (scrol > 0) {
			$('#top').show();
		} else {
			$('#top').hide();
		}
	});
function gototop(){
	$('#top').click(function(){
		$('html, body').animate({scrollTop : 0},800);
		return false;
	});
}

$('.search').click(function () {
    $('.searchtext').toggleClass('expanded');
});

$( ".cart" ).click(function() {
  $( "#cart" ).slideToggle( "3000", function() {
    // Animation complete.
  });
});

