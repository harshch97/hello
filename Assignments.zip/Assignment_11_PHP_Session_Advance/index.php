<!DOCTYPE html>
<html lang="en">
	<head>
		<title>eShopper Online Store</title>
		<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="icon" href="images/favicon.ico">
  		<link rel="stylesheet" href="css/bootstrap.min.css">
  		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  		<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
  		<script type="text/javascript" src="js/bootstrap.min.js"></script>
  		<script type="text/javascript" src="js/script.js"></script>
  		<script type="text/javascript" src="js/infinite-rotator.js"></script>
		<link rel="stylesheet" href="css/style.css" >
		<link rel="stylesheet" href="css/media.css" >
	</head>
	<body>
		<!--	Header 		-->
		<?php include 'header.php'; ?>
		<!--	Main content 	-->
 		<div class="banner image image-reponsive parent">
			<div id="rotating-item-wrapper">
				<img src="images/banner.jpg" alt="banner" class="rotating-item banner-img" />
				<img src="images/banner1.jpg" alt="banner1" class="rotating-item banner-img"/>
				<img src="images/banner2.jpg" alt="banner2" class="rotating-item banner-img"/>
			</div>
			<a class="prev-arrow" onclick="next(-1)">
				<div id="pre-arrow"></div>
			</a>
			<a class="next-arrow" onclick="next(1)">
				<div id="next-arrow"></div>
			</a>
		</div>
		<div class="container">
			<div class="background-content">
				<div class="row">
					<div class="col-sm-4">
						<div class="row">
							<div class="col-sm-2 col-xs-2">
								<a><img id="icon1" src="images/img_transparent.png" /></a>
							</div>
							<div class="col-sm-10 col-xs-10 data">
								<p>Free Delivery Worldwide</p>
								At vero eos et accusamus et iusto odio 
							</div>
						</div>
					</div>
					<div class="col-sm-4">
						<div class="row">
							<div class="col-sm-2 col-xs-2">
								<a><img id="icon2" src="images/img_transparent.png" /></a>
							</div>
							<div class="col-sm-10 col-xs-10 data">
								<p>Free Return For 90 Days</p>
								At vero eos et accusamus et iusto odio 
							</div>
						</div>
					</div>
					<div class="col-sm-4">
						<div class="row">
							<div class="col-sm-2 col-xs-2">
								<a><img id="icon3" src="images/img_transparent.png" /></a>
							</div>
							<div class="col-sm-10 col-xs-10 data">
								<p>Discount on Order Gift</p>
								At vero eos et accusamus et iusto odio 
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="title">
				<p>Trending Products</p>
			</div>
			<section>
				<?php require 'product_function.php'; product();?>
				<div class="row">
					<div class="col-sm-12 col-xs-12">
						<div id="more-products" class="collapse">
							<?php require 'more_product_function.php'; more_product(); ?>
						</div>
					</div>
					<div class="col-sm-12 col-xs-12">
						<div class="more-product-btn">
							<input class="btn center-block btn-style" type="button" data-toggle="collapse" data-target="#more-products" value="More Products" id="more-product-btn">
						</div>
					</div>
				</div>
		</section>
		<a id="topBtn" title="Go to top"><img class="up-arrow" src="images/img_transparent.png"></div></a>
		<div class="bottom-banner image-banner image-reponsive">
			<img src="images/px.jpg">
			<div class="banner-content">
				<div class="row">
					<div class="col-sm-12">
						<b>Get the</b> latest 
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12 padding-xs">
						<b>womens</b> fashion
					</div>
				</div>				
				<div class="row">
					<div class="col-sm-12">
						<button class="btn banner-btn-style" type="button">Get Exclusive Collection For Women</button>	
					</div>
				</div>
			</div>
		</div>
		<!--	Testimonial		-->
		<div class="title">
			<p>Testimonial</p>
		</div>
		<div class="container">
			<div class="row">
	    		<div class="col-sm-2 col-xs-0"></div>
	    		<div class="col-sm-8 col-xs-12">
					<div class="carousel slide" data-ride="carousel" id="testimonial-carousel">
						
						<ul class="carousel-indicators">
						  	<li data-target="#testimonial-carousel" data-slide-to="0" class="active"></li>
						  	<li data-target="#testimonial-carousel" data-slide-to="1"></li>
						  	<li data-target="#testimonial-carousel" data-slide-to="2"></li>
						  	<li data-target="#testimonial-carousel" data-slide-to="3"></li>
						</ul>
						
						<div class="carousel-inner">
							<div class="item active">
								<div class="row">
	    							<div class="col-sm-12 col-xs-12">
	    								<div class="top-border"></div>
    									<div class="row testimonial">
    										<div class="col-sm-3 col-xs-12 right-line">
    											<div class="media">
												    <div class="media-left">
												      	<img src="images/testimonial_3.jpg" class="media-object" style="width:60px">
												    </div>
												    <div class="media-body">
												      	<div  class="font-size-p"><p>John Clay</p></div>
												      	<div  class="font-size-caption"><p>Cyclist</p></div>
												    </div>
												</div>
    										</div>
    										<div class="col-sm-9 col-xs-12">
    											<p>You can use box-shadow to make a border effect, by making theshadow offset and have 0 blur.You can use box-shadow<br>You can use box-shadow to make a border effect, by making the<br>shadow offset and have 0 blur.You can use box-shadow<br>You can use box-shadow</p>
    										</div>
    									</div>
	    								<div class="bottom-border"></div>
	    							</div>
	    						</div>
	    					</div>
	    					<div class="item">
								<div class="row">
	    							<div class="col-sm-12 col-xs-12">
	    								<div class="top-border"></div>
    									<div class="row testimonial">
    										<div class="col-sm-3 col-xs-12 right-line">
    											<div class="media">
												    <div class="media-left">
												      	<img src="images/testimonial_3.jpg" class="media-object" style="width:60px">
												    </div>
												    <div class="media-body">
												      	<div  class="font-size-p"><p>John Clay</p></div>
												      	<div  class="font-size-caption"><p>Cyclist</p></div>
												    </div>
												</div>
    										</div>
    										<div class="col-sm-9 col-xs-12">
    											<p>You can use box-shadow to make a border effect, by making theshadow offset and have 0 blur.You can use box-shadow<br>You can use box-shadow to make a border effect, by making the<br>shadow offset and have 0 blur.You can use box-shadow<br>You can use box-shadow</p>
    										</div>
    									</div>
	    								<div class="bottom-border"></div>
	    							</div>
	    						</div>
	    					</div>
	    					<div class="item">
								<div class="row">
	    							<div class="col-sm-12 col-xs-12">
	    								<div class="top-border"></div>
	    								<div class="row testimonial">
    										<div class="col-sm-3 col-xs-12 right-line">
    											<div class="media">
												    <div class="media-left">
												      	<img src="images/testimonial_3.jpg" class="media-object" style="width:60px">
												    </div>
												    <div class="media-body">
												      	<div  class="font-size-p"><p>John Clay</p></div>
												      	<div  class="font-size-caption"><p>Cyclist</p></div>
												    </div>
												</div>
    										</div>
    										<div class="col-sm-9 col-xs-12">
    											<p>You can use box-shadow to make a border effect, by making theshadow offset and have 0 blur.You can use box-shadow<br>You can use box-shadow to make a border effect, by making the<br>shadow offset and have 0 blur.You can use box-shadow<br>You can use box-shadow</p>
    										</div>
    									</div>
	    								<div class="bottom-border"></div>
	    							</div>
	    						</div>
	    					</div>
	    					<div class="item">
								<div class="row">
	    							<div class="col-sm-12 col-xs-12">
	    								<div class="top-border"></div>
	    								<div class="row testimonial">
    										<div class="col-sm-3 col-xs-12 right-line">
    											<div class="media">
												    <div class="media-left">
												      	<img src="images/testimonial_3.jpg" class="media-object" style="width:60px">
												    </div>
												    <div class="media-body">
												      	<div  class="font-size-p"><p>John Clay</p></div>
												      	<div  class="font-size-caption"><p>Cyclist</p></div>
												    </div>
												</div>
    										</div>
    										<div class="col-sm-9 col-xs-12">
    											<p>You can use box-shadow to make a border effect, by making theshadow offset and have 0 blur.You can use box-shadow<br>You can use box-shadow to make a border effect, by making the<br>shadow offset and have 0 blur.You can use box-shadow<br>You can use box-shadow</p>
    										</div>
	    								</div>
	    								<div class="bottom-border"></div>
	    							</div>
	    						</div>
	    					</div>
	    				</div>
	    			</div>
	    		</div>
	    		<div class="col-sm-2 col-xs-0"></div>
			</div>
		</div>
		<!--	Footer 		-->
		<?php include 'footer.php'; ?>
		<script src="js/carousel.js"></script>
	</body>
</html>