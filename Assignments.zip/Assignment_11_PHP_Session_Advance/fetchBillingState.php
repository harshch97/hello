<?php
include 'dbConnection.php';
session_start();
$sessionUserName=$_SESSION['username'];
$selectProfileInfo="SELECT billing_add_id FROM `user` WHERE `username`='$sessionUserName'";
$data=mysqli_query($con,$selectProfileInfo);
while($row=mysqli_fetch_assoc($data)){
	$billing_id=$row['billing_add_id'];
}
if($billing_id!=NULL)
{
	$billingQuery="SELECT  `address`.street,`address`.city,`address`.state_id,`state`.id,`state`.country_id,`country`.id FROM `address` LEFT JOIN `state` ON `address`.state_id=`state`.id LEFT JOIN `country` ON `state`.country_id=`country`.id WHERE `address`.id=$billing_id";
	$selectBillingAddress=mysqli_query($con,$billingQuery);
	if($selectBillingAddress){
		while($row=mysqli_fetch_assoc($selectBillingAddress)){
			$billingState=$row['state_id'];
		}
	}
}
$id=$_POST['id'];
$selectState="SELECT * FROM `state` WHERE country_id=$id";
$result=mysqli_query($con,$selectState);
?>
<option value="" disabled="" selected="">Select State</option>
<?php
while($row=mysqli_fetch_assoc($result)) {
	if(isset($billingState)){
	?>
		<option value="<?php echo $row['id']; ?>" <?php echo ($billingState==$row['id'])?'selected':'' ?> ><?php echo $row['name']; ?></option>
	<?php
	}
	else{
	?>
		<option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
	<?php
	}
}
?>