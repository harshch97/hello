<?php
ini_set("SMTP", "192.168.0.6");
$con=mysqli_connect('localhost','root','','eshop');
if(!$con)
	die('Unable to connect');
else{
	return $con;
}
?>