<?php
session_start();
include 'dbConnection.php';
error_reporting(0);
?>
<body>
	<nav class="navbar navbar-fixed-top navbar-modify">
		<div class="container-width">
			<div class="row">
				<div class="col-sm-1 col-xs-12">
					<div class="navbar-brand logo"></div>
				</div>
				<div class="col-sm-6 col-xs-12">
					<div class="menu-color">
					    <div class="navbar-header">
					    	<button type="button" class="navbar-toggle navbar-responsive" data-toggle="collapse" data-target="#myNavbar">
						        <span class="icon-bar icon-color"></span>
						        <span class="icon-bar icon-color"></span>
						        <span class="icon-bar icon-color"></span>   
						    </button>
					    </div>
					    <div class="collapse navbar-collapse navbar-color" id="myNavbar">
						    <ul class="nav navbar-nav">
							    <li class="active"><a href="/" class="a">HOME</a></li>
							    <?php
							    $selectMenuItems="SELECT * FROM `category` WHERE parent_id=0";
								$resultMenu=mysqli_query($con,$selectMenuItems);
								while($row=mysqli_fetch_assoc($resultMenu)) {
									$id=$row['id'];
									$selectSubMenu="SELECT * FROM `category` WHERE parent_id=$id";
									$resultSubMenu=mysqli_query($con,$selectSubMenu);
							    	?>
									<?php    			
				        			if(mysqli_num_rows($resultSubMenu)>0){
					        			?>
					        			<li class="dropdown">
					        			<a class="dropdown-toggle a" data-toggle="dropdown" href="#"><?php echo $row['name']; ?></a>
										<ul class="dropdown-menu navbar-submenu">
										<?php
										while($sub=mysqli_fetch_assoc($resultSubMenu)) {
											?>
											<li><a href="#"><?php echo $sub['name']?></a></li>
											<?php
										}
										?>
										</ul>
										<?php
									}
									else{
										?>
										<li><a href="#" class="a"><?php echo $row['name']; ?></a></li>
										<?php
									}	
									?>
									<?php
								}
							?>
						    </ul>
				    	</div>
					</div>
				</div>
				<div class="col-sm-5 col-xs-12 small-device">
					<ul class="nav navbar-nav navbar-right">
						<?php
						$username=$_SESSION['username']; 
						$selectProfileInfo="SELECT * FROM `user` WHERE `username`='$username'";
						$data=mysqli_query($con,$selectProfileInfo);
						while($row=mysqli_fetch_assoc($data)){
							$welcome_user_name=$row['firstname'];
						}
						if(empty($username)){
						?>
				      	<li><a href="#" type="button" data-toggle="modal" data-target="#loginModal" data-backdrop="static" data-keyboard="false">Login</a></li>
				      	<?php
						}
						else
						{
						?>
						<li><div class="welcome-message">Welcome, <?php echo $welcome_user_name; ?></div></li>
				      	<li><div class="vl small"></div></li>
				      	<li class="responsive"><a href="profile">Profile</a></li>
				      	<li><div class="vl"></div></li>
				      	<li class="responsive"><a href="logout" onclick="return confirm('Are you sure?');">Logout</a></li>
						<?php
						}
						?>
				      	<li><div class="vl"></div></li>
				      	<li><a data-placement="bottom" id="cart" data-toggle="popover" data-trigger="focus" data-title="Recently added item(s)" data-container="body" type="button" data-html="true"><div class="cart"></div></a>
					    <div id="popover-content" class="dropdown-menu popover-data" style="display: none;">
				      		<h3 class="popover-title">Recently added item(s)</h3>
					    	<table class="table table-border">
					    		<tbody>
								    <tr>
								        <td class="cart-img"><img src="images/new-thumb-01-big.jpg"></td>
								        <td class="font-size-td">U.S. Polo Assn. Full Sleeve Plain T-Shirts...<div class="last-item">$120.00</div><div class="detail">Qty : 1<br>Size : Medium/Large</div>
								        <td class="td-width"><div class="edit-popup"></div></td>
								        <td class="td-width"><div class="cancel-popup"></div></td>
							      	</tr>
								    <tr>
								        <td class="cart-img"><img src="images/new-thumb-02-big.jpg"></td>
								        <td class="font-size-td">U.S. Polo Assn. Full Sleeve Plain T-Shirts...<div class="last-item">$120.00</div><div class="detail">Qty : 1<br>Size : Medium/Large</div>
								        <td class="td-width"><div class="edit-popup"></div></td>
								        <td class="td-width"><div class="cancel-popup"></div></td>
							      	</tr>
								    <tr>
								        <td colspan="4" class="font-cart">Cart Subtotal : <div class="total last-item position-td">$168.00</div></td>
							      	</tr>
						      	</tbody>
					    	</table>
					    	<div class="row btn-align">
					    		<div class="col-sm-12 col-xs-12">
					    			<a href="cart" class="btn update-btn">View Cart</a>
					    		</div>
					    	</div>
					    </div></li>
				      	<li><div class="vl small"></div></li>
				      	<li class="search-a">
				      		<div class="box">
								<input class="search-box" type="search" placeholder="Search" />
							</div>
				      		<a class="border-a"><div class="search1"></div></a>
				      	</li>
		    		</ul>
				</div>
			</div>
		</div>
	</nav>
	<!-- Modal -->
  	<div class="modal fade" id="loginModal" role="dialog">
    	<div class="modal-dialog modal-width">
    
      	<!-- Modal content-->
	      	<div class="modal-content">
		        <div class="modal-header">
		          <button type="button" class="close" data-dismiss="modal">&times;</button>
		          <h4 class="modal-title text-align-modal">eShopper Login</h4>
		        </div>
		        <div class="modal-body">
		          	<form name="loginForm" action="loginUser.php" method="post">
						<div class="row">
							<div class="col-sm-12 col-xs-12">
							  	<div class="form-group modal-group-height">
								    <label for="username">Username</label>
								    <input type="text" class="form-control" id="username" placeholder="Enter your username" name="username">
							  	</div>
							</div>
							<div class="col-sm-12 col-xs-12">
							  	<div class="form-group modal-group-height">
								    <label for="password">Password</label>
								    <input type="password" class="form-control" id="password" placeholder="Enter your password" name="password">
							  	</div>
							</div>
							<!-- <div class="col-sm-12 col-xs-12">
							  	<div class="form-group modal-group-height">
								    <label for="password">Password</label>
								    <input type="password" class="form-control validate" id="confirm_password" name="confirm_password" placeholder="Incorrect password">
							  	</div>
							</div> -->
				      	</div>
				      	<div class="row">
							<div class="col-sm-3 col-xs-5">
								<input type="submit" value="Login" class="btn update-btn">
							</div>
							<div class="col-sm-9 col-xs-7">
								<p class="pull-right content-top">Not a Member?&nbsp;<a href="register">Register</a></p>
							</div>
						</div>
				    </form>
				</div>
			</div>
    	</div>
  	</div>
</body>