<?php
session_start();
error_reporting(0);	
if(!isset($_SESSION['username']) || $_SESSION['username']==''){
	echo "<script>" ;
	echo "alert('Login to access cart or profile!');" ;
	echo "</script>" ;
	header("location:/");
}
?>