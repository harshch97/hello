<?php
include 'dbConnection.php';
session_start();
$sessionUserName=$_SESSION['username'];
$selectProfileInfo="SELECT shipping_add_id FROM `user` WHERE `username`='$sessionUserName'";
$data=mysqli_query($con,$selectProfileInfo);
while($row=mysqli_fetch_assoc($data)){
	$shipping_id=$row['shipping_add_id'];
}
if($shipping_id!=NULL)
{
	$shippingQuery="SELECT  `address`.street,`address`.city,`address`.state_id,`state`.id,`state`.country_id,`country`.id FROM `address` LEFT JOIN `state` ON `address`.state_id=`state`.id LEFT JOIN `country` ON `state`.country_id=`country`.id WHERE `address`.id=$shipping_id";
	$selectShippingAddress=mysqli_query($con,$shippingQuery);
	if($selectShippingAddress){
		while($row=mysqli_fetch_assoc($selectShippingAddress)){
			$shippingState=$row['state_id'];
		}
	}
}
$id=$_POST['id'];
$selectState="SELECT * FROM `state` WHERE country_id=$id";
$result=mysqli_query($con,$selectState);
?>
<option value="" disabled="" selected="">Select State</option>
<?php
while($row=mysqli_fetch_assoc($result)) {
	if(isset($shippingState)){
	?>
		<option value="<?php echo $row['id']; ?>" <?php echo ($shippingState==$row['id'])?'selected':'' ?> ><?php echo $row['name']; ?></option>
	<?php
	}
	else{
	?>
		<option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
	<?php
	}
}
?>