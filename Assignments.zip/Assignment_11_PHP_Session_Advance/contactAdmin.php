<?php
require 'dbConnection.php';
$admin="krushiva.patel@internal.mail";
$name=$_POST['name'];
$email=$_POST['email'];
$subject=$_POST['subject'];
$message=$_POST['message'];
$headers = "From: " . $email . "\r\n";
mail($admin,$subject,$message,$headers);
header('Location: ' . $_SERVER['HTTP_REFERER']);
?>