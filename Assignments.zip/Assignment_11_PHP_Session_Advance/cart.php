<?php
include 'redirect.php';
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>eShopper Online Store</title>
		<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="css/bootstrap.min.css">
  		<link rel="icon" href="images/favicon.ico">
  		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  		<script type="text/javascript" src="js/bootstrap.min.js"></script>
  		<script type="text/javascript" src="js/script.js"></script>
		<link rel="stylesheet" href="css/style.css" >
		<link rel="stylesheet" href="css/media.css" >
	</head>
	<body>
		<!--	Header 		-->
		<?php include 'header.php'; ?>
		<!--	Main content 	-->
		<header class="header-data-banner">
			<img src="images/inner-banner.jpg">
		</header>
		<a id="topBtn" title="Go to top"><img class="up-arrow" src="images/img_transparent.png"></div></a>
		<div class="container">
			<div class="background-content">
				<div class="row">
					<div class="col-sm-12 col-xs-12 padding-breadcrumb">
						<ul class="breadcrumb">
							<li>Home</li>
							<li class="last-item">Shopping Cart</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="shopping-cart">
				<h2>Shopping Cart</h2>
			</div>
			<div class="alert alert-success alert-dismissable">
		    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
		    	<div class="row">
		    		<div class="col-sm-1 col-xs-1 success-icon">
		    		</div>
		    		<div class="col-sm-11 col-xs-11 data-display">
		    			U.S. Polo Assn. Full Sleeve Plain T-Shirts for Men was added to your shopping cart.	
		    		</div>
		    	</div>
		  	</div>
		  	<div class="alert alert-info alert-dismissable">
		    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
		    	<div class="row">
		    		<div class="col-sm-1 col-xs-1 info-icon">
		    		</div>
		    		<div class="col-sm-11 col-xs-11 data-display">
		    			U.S. Polo Assn. Full Sleeve Plain T-Shirts for Men was added to your shopping cart.	
		    		</div>
		    	</div>
		  	</div>
		  	<div class="alert alert-warning alert-dismissable">
		    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
		    	<div class="row">
		    		<div class="col-sm-1 col-xs-1 warning-icon">
		    		</div>
		    		<div class="col-sm-11 col-xs-11 data-display">
		    			U.S. Polo Assn. Full Sleeve Plain T-Shirts for Men was added to your shopping cart.	
		    		</div>
		    	</div>
		  	</div>
		  	<div class="alert alert-danger alert-dismissable">
		    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
		    	<div class="row">
		    		<div class="col-sm-1 col-xs-1 error-icon">
		    		</div>
		    		<div class="col-sm-11 col-xs-11 data-display">
		    			U.S. Polo Assn. Full Sleeve Plain T-Shirts for Men was added to your shopping cart.	
		    		</div>
		    	</div>
		  	</div>
		  	<div class="table-responsive" id="cart-table">
			</div>
			<div class="row">
				<div class="col-sm-5 col-xs-12">
					<div class="panel panel-default">
					    <div class="panel-body">
							<h4>Estimate Shipping and Tax</h4>
							<p>Enter your destination to get a shipping estimate.</p>
							<form>
								<div class="form-group group-height">
								    <label for="country">Country</label>
								    <select class="form-control">
									  	<option>Option1</option>
									  	<option>Option2</option>
									</select>
							  	</div>
							  	<div class="form-group group-height">
								    <label for="state">State/Province</label>
								    <input type="text" class="form-control" id="state" placeholder="State/Province">
							  	</div>
							  	<div class="form-group group-height">
								    <label for="zipcode">Zip/Postal Code</label>
								    <input type="text" class="form-control" id="zipcode" placeholder="Zip/Postal Code">
							  	</div>
							</form>
						</div>
					</div>
				</div>
				<div class="col-sm-offset-3 col-sm-4 col-xs-12">
					<div class="panel panel-default">
					    <div class="panel-body">
					    	<div class="row">
					    		<div class="col-sm-offset-6 col-sm-3 col-xs-offset-4 col-xs-4">Subtotal</div>
					    		<div class="col-sm-3 col-xs-4" id="subtotal"></div>
					    	</div>
					    	<div class="row">
					    		<div class="col-sm-offset-6 col-sm-3 col-xs-offset-4 col-xs-4 total">Total</div>
					    		<div class="col-sm-3 col-xs-4 last-item total data-margin" id="total"></div>
					    	</div>
					    	<div class="row">
					    		<div class="col-sm-12 col-xs-12"><input type="submit" value="Update Shopping Cart" class="btn submit-btn"></div>
					    	</div>
					    </div>
					    <div class="panel-footer footer-center">Checkout with multiple addresses</div>
					</div>
				</div>
			</div>
		</div>
		<!--	Footer 		-->
		<?php include 'footer.php'; ?>
		<script type="text/javascript" src="js/data.js"></script>
	</body>
</html>