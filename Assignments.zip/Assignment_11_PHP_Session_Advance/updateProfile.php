<?php
include 'dbConnection.php';
// echo "$street $city $country $state";
$username=$_POST['username'];
$gender=$_POST['gender'];
$email=$_POST['email'];
$fname=$_POST['firstName'];
$mobile=$_POST['mobile'];
$lname=$_POST['lastName'];
$phone=$_POST['phone'];	
$address=$_SERVER['HTTP_REFERER'];
if(isset($_POST['billing_address'])){
	$flag=1;
}
else{
	$flag=0;
}

$uniqEmail="SELECT `email` FROM `user` WHERE `email`='$email' AND `username`!='$username'";
$result=mysqli_query($con,$uniqEmail);
$rows=mysqli_num_rows($result);

if($rows==0){
	if(isset($_POST['street']) AND isset($_POST['city']) AND isset($_POST['country']) AND isset($_POST['state'])){
		$street=$_POST['street'];
		$city=$_POST['city'];
		$country=$_POST['country'];
		$state=$_POST['state'];
		$getData="SELECT * FROM `user` WHERE `username` = '$username' ";
		$resultData=mysqli_query($con,$getData);
		while($row=mysqli_fetch_assoc($resultData)){
			$shipping_id=$row['shipping_add_id'];
			$billing_id=$row['billing_add_id'];
			// echo "$shipping_id";
			if($shipping_id==NULL){
				$insertAddress="INSERT INTO `address`(`street`, `city`, `state_id`) VALUES ('$street','$city',$state)";
				$rsAddress=mysqli_query($con,$insertAddress);	
				if($rsAddress){
					$last_id = mysqli_insert_id($con);
					// echo $last_id;
					$updateShippingAddress="UPDATE user SET `shipping_add_id`=$last_id WHERE `username`='$username'";
					mysqli_query($con,$updateShippingAddress);
					header("location:profile");
				}
			}
			else{
				$updateAddress="UPDATE `address` SET `street`='$street',`city`='$city',`state_id`=$state WHERE id=$shipping_id";
				mysqli_query($con,$updateAddress);
			}
			if(isset($_POST['street_bill']) AND isset($_POST['city_bill']) AND isset($_POST['country_bill']) AND isset($_POST['state_bill']))
			{
				$street_bill=$_POST['street_bill'];
				$city_bill=$_POST['city_bill'];
				$country_bill=$_POST['country_bill'];
				$state_bill=$_POST['state_bill'];
				if($billing_id==NULL){
					$insertBillingAddress="INSERT INTO `address`(`street`, `city`, `state_id`) VALUES ('$street_bill','$city_bill',$state_bill)";
					$rsBillingAddress=mysqli_query($con,$insertBillingAddress);	
					if($rsBillingAddress){
						$last_id = mysqli_insert_id($con);
						// echo $last_id;
						$updateShippingAddress="UPDATE user SET `billing_add_id`=$last_id,`flag`=$flag WHERE `username`='$username'";
						mysqli_query($con,$updateShippingAddress);
						header("location:profile");
					}
				}
				else{
					// echo $billing_id;
					$updateAddress="UPDATE `address` SET `street`='$street_bill',`city`='$city_bill',`state_id`=$state_bill WHERE id=$billing_id";
					mysqli_query($con,$updateAddress);
					$updateShippingAddress="UPDATE user SET `flag`=$flag WHERE `username`='$username'";
					mysqli_query($con,$updateShippingAddress);
					// echo $flag;
					header("location:profile");
				}
			}
			else{
				header("location:profile");
			}
		}
	}
	else{
		$query="UPDATE `user` SET `firstname`='$fname',`lastname`='$lname',`gender`='$gender',`email`='$email',`mobile_number`='$mobile',`phone_number`='$phone' WHERE `username`='$username'";
		$result=mysqli_query($con,$query);
		if($result){
			echo "<script>";
			echo "alert('Updated Successfully');";
			echo "window.location.replace(\"$address\");";
			echo "</script>";
		}
		else{
			// header("location:profile");
			echo "<script>";
			echo "alert('Unable to update profile!');";
			echo "window.location.replace(\"$address\");";
			echo "</script>";
		}
	}
}
else{
	echo "<script>";
	echo "alert('Username and Email id should be unique');";
	echo "window.location.replace(\"$address\");";
	echo "</script>";
}
?>