<?php
include 'dbConnection.php';
$username=$_POST['username'];
$password=md5($_POST['password']);
$address=$_SERVER['HTTP_REFERER'];

$loginData="SELECT `username`,`password`,`firstname` FROM `user` WHERE `username`='$username' AND `password`='$password'";
$result=mysqli_query($con,$loginData);
$rows=mysqli_num_rows($result);

if($rows==1){
	session_start();
	while($row=mysqli_fetch_assoc($result))
	{
		$_SESSION['username']=$row['username'];
		header("location:profile");
	}
	// echo $_SESSION['name'];
}
else{
	echo "<script>";
	echo "alert('Enter Valid Username or Password!');";
	echo "window.location.replace(\"$address\");";
	echo "</script>";
}
?>