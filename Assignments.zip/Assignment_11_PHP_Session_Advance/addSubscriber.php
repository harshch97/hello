<?php
include 'dbConnection.php';
$email=$_POST['email'];
$uniqEmail="SELECT `email` FROM `newsletter_subscriber` WHERE `email`='$email'";
$result=mysqli_query($con,$uniqEmail);
$rows=mysqli_num_rows($result);
$address=$_SERVER['HTTP_REFERER'];
// echo $address;
if($rows==0){
	$insertSubscriber="INSERT INTO `newsletter_subscriber`(`email`) VALUES ('$email')";
	$insertSubscriberDb=mysqli_query($con,$insertSubscriber);
	if($insertSubscriberDb)
	{
		$subject = "Newsletter Subscription";
		$txt = "Thank you for your Subscription!";
		$headers = 'From: krushiva.patel@internal.mail' . "\r\n";
		$headers .= 'Cc: krushiva.patel@internal.mail' . "\r\n";
		if(mail($email,$subject,$txt,$headers)){
			echo "<script>";
			echo "window.location.replace(\"$address?success=1\");";
			echo "</script>";
		}
		// header('Location: ' . $_SERVER['HTTP_REFERER']);
	}
	else{
		echo "<script>";
		echo "alert('Unable to subscribe now. Please try again later.');";
		echo "window.location.replace(\"$address\");";
		echo "</script>";
	}
}
else{
	echo "<script>";
	echo "alert('You are already subscribed!');";
	echo "window.location.replace(\"$address\");";
	echo "</script>";
}
?>