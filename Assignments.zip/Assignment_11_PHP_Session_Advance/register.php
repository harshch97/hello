<?php
session_start();
error_reporting(0);
require 'ValidationException.php';
if (isset($_SESSION['username'])){
	$address=$_SERVER['HTTP_REFERER'];
    // header("Location: profile");
    echo "<script>";
	echo "alert('You are already registered!');";
	echo "window.location.replace(\"$address\");";
	echo "</script>";
}
if(isset($_POST['registerUser'])){
	$uname=$_POST['username'];
	$password=$_POST['password'];
	$cpassword=$_POST['confirm_password'];
	$gender=$_POST['gender'];
	$email=$_POST['email'];
	$fname=$_POST['firstName'];
	$mobile=$_POST['mobile'];
	$lname=$_POST['lastName'];
	$phone=$_POST['phone'];	
	try{
		if(empty($uname)){
			throw new ValidationException($uname, "Username is required.");
	    }
	    elseif(empty($gender)){
			throw new ValidationException($gender, "Select gender.");
	 	}
		elseif(empty($password)){
			throw new ValidationException($password, "Enter Password.");
	 	}
	 	elseif(empty($email)){
			throw new ValidationException($email, "Enter Email.");
	 	}
	 		
	 	elseif(!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $email)){
			throw new ValidationException($email, "You did not enter a valid email.");
		}
	 	elseif(empty($fname)){
			throw new ValidationException($fname, "Enter First Name.");
	 	}
	 	elseif(empty($mobile)){
			throw new ValidationException($mobile, "Enter Mobile number.");
	 	}
	 	elseif(empty($lname)){
			throw new ValidationException($lname, "Enter Last Name.");
	 	}
	 	elseif(isset($password)){
	 		$capital  = preg_match_all('/[A-Z]/',$password,$matches);
			$num  = preg_match_all('/[0-9]/',$password,$matches);
			$char  = preg_match_all('/[!@#$]/',$password,$matches);
			if($capital=2){
				if($num>0){
					if($char==0)
					{
						throw new ValidationException('', "Password should be valid.");
					}
					else{
						if($password==$cpassword){
	 						include 'registerNewUser.php';
	 					}
	 					else{
	 						throw new ValidationException('', "Confirm password should be same as password.");
	 					}
					}
				}
				else{
					throw new ValidationException('', "Password should be valid.");
				}
			}
			else{
				throw new ValidationException('', "Password should be valid.");
			}
	 	}
	}
	catch(Exception $e){
		if(empty($uname)){
			$error_uname = $e->getMessage();
		  	$code = 1;
		}
		elseif(!isset($gender)){
	 		$error_gender = $e->getMessage();
	 		$code = 3;
	 	}
		elseif(empty($password)){
	 		$error_passwd = $e->getMessage();
	 		$code = 2;
	 	}
	 	elseif(empty($email)){
	 		$error_email = $e->getMessage();
	 		$code = 4;
	 	} 	
	 	elseif(!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $email)){
			$error_email= $e->getMessage();
			$code= 4;
		}
	 	elseif(empty($fname)){
	 		$error_fname = $e->getMessage();
	 		$code = 5;
	 	}
	 	elseif(empty($mobile)){
	 		$error_mobile = $e->getMessage();
	 		$code = 6;
	 	} 	
	 	elseif(empty($lname)){
	 		$error_lname = $e->getMessage();
	 		$code = 7;
	 	}
	 	elseif(isset($password)){
	 		$capital  = preg_match_all('/[A-Z]/',$password,$matches);
			$num  = preg_match_all('/[0-9]/',$password,$matches);
			$char  = preg_match_all('/[!@#$]/',$password,$matches);
			if($capital=2){
				if($num>0){
					if($char==0)
					{
						$error_passwd = $e->getMessage();
	 					$code = 2;
					}
					else{
						if($password==$cpassword){
	 						include 'registerNewUser.php';
	 					}
	 					else{
	 						$error_passwd = $e->getMessage();
	 						$code = 2;
	 					}
					}
				}
				else{
					$error_passwd =  $e->getMessage();
	 				$code = 2;
				}
			}
			else{
				$error_passwd =  $e->getMessage();
	 			$code = 2;
			}
	 	}
	}
}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>eShopper Online Store</title>
		<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="css/bootstrap.min.css">
  		<link rel="icon" href="images/favicon.ico">
  		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  		<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
  		<script type="text/javascript" src="js/bootstrap.min.js"></script>
  		<script type="text/javascript" src="js/script.js"></script>
		<link rel="stylesheet" href="css/style.css" >
		<link rel="stylesheet" href="css/media.css" >
	</head>
	<body>
		<!--	Header 		-->
		<?php include 'header.php'; ?>
		<!--	Main content 	-->
		<header>
			<img src="images/inner-banner.jpg">
		</header>
		<a id="topBtn" title="Go to top"><img class="up-arrow" src="images/img_transparent.png"></div></a>
		<div class="container">
			<div class="background-content">
				<div class="row">
					<div class="col-sm-12 col-xs-12 padding-breadcrumb">
						<ul class="breadcrumb">
							<li>Home</li>
							<li class="last-item">Register</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="register">
				<h2>Register</h2>
			</div>
			<div class="row">
				<div class="col-sm-12 col-xs-12 register-customer">
					<h2>New Customers</h2>
				</div>
				<div class="col-sm-12 col-xs-12 font-p">
					<p>By creating an account with our store, you will be able to move to the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>
				</div>
			</div>
			<form name="registrationForm" id="registrationForm" method="post">
				<div class="row">
					<div class="col-sm-6 col-xs-12">
					  	<div class="form-group group-height">
					  		<div class="row">
					  			<div class="col-sm-12">
						    		<label for="username">Username</label>
						    		<input type="text" class="form-control" id="username" placeholder="Please enter your username" name="username" <?php if(isset($code) && $code == 1){ echo "autofocus"; }  ?> value="<?php if(isset($uname)){echo $uname;} ?>">
						    	</div>
						    	<div class="col-sm-12 error">
						    		<div id="username_error"><?php if($code==1){echo $error_uname;}?></div>
						    	</div>
						    </div>
					  	</div>
					</div>
					<div class="col-sm-6 col-xs-12">
						<div class="form-group group-height">
							<div class="row">
					  			<div class="col-sm-12">
								    <label for="gender">Gender</label><br>
								    <div class="radio-inline radio-margin">
								  	<input type="radio" name="gender" value="male" <?php if(isset($gender)){echo ($gender=='male')?'checked':'';} ?>><label>Male</label></div>
									<div class="radio-inline radio-margin">
								  	<input type="radio" name="gender" value="female" <?php if(isset($gender)){echo ($gender=='female')?'checked':'';} ?>><label>Female</label></div>
								</div>
								<div class="col-sm-12 error">
						    		<div id="gender_error"><?php if($code==3){echo $error_gender;}?></div>
						    	</div>
							</div>
					  	</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-6 col-xs-12">
					  	<div class="form-group group-height">
					  		<div class="row">
					  			<div class="col-sm-6 col-xs-12">
								    <label for="password">Password</label>
								    <input type="password" class="form-control password" id="password" 
title="Password must contain 
1.	TWO Capital letter
2.	At least one digit and 
3.	At least one special character(!,@,#,$)" 
								placeholder="Enter password" name="password" <?php if(isset($code) && $code == 2){ echo "autofocus"; }  ?> value="<?php if(isset($password)){echo $password;} ?>">
								</div>
								<div class="col-sm-6 col-xs-12">
								  	<div class="form-group modal-group-height">
									    <label for="password">Confirm Password</label>
									    <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Enter password again">
								  	</div>
								</div>
					  			<div class="col-sm-12 error">
						    		<div id="password_error"><?php if($code==2){echo $error_passwd;}?></div>
						    	</div>
					  		</div>
					  	</div>
					</div>
					<div class="col-sm-6 col-xs-12">
					  	<div class="form-group group-height">
					  		<div class="row">
					  			<div class="col-sm-12">
								    <label for="email">Email</label>
								    <input type="email" name="email" class="form-control" id="email" placeholder="Please enter valid email" name="email" <?php if(isset($code) && $code == 4){ echo "autofocus"; }  ?> value="<?php if(isset($email)){echo $email;} ?>">
								</div>
								<div class="col-sm-12 error">
						    		<div id="email_error"><?php if($code==4){echo $error_email;}?></div>
					  			</div>
							</div>
					  	</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-6 col-xs-12">
					  	<div class="form-group group-height">
					  		<div class="row">
					  			<div class="col-sm-12">
						    		<label for="firstName">First Name</label>
						    		<input type="text" id="firstName" class="form-control" placeholder="Please enter your first name" name="firstName" <?php if(isset($code) && $code == 5){ echo "autofocus"; }  ?> value="<?php if(isset($fname)){echo $fname;} ?>" >
						    	</div>
					  			<div class="col-sm-12 error">
					  				<div id="fname_error"><?php if($code==5){echo $error_fname;}?></div>
						    	</div>
						    </div>
					 	</div>
					</div>
					<div class="col-sm-6 col-xs-12">
					  	<div class="form-group group-height">
					  		<div class="row">
					  			<div class="col-sm-12">
								    <label for="mobile">Mobile No.</label>
								    <input type="text" id="mobile" class="form-control" name="mobile" placeholder="Please enter your mobile number" value="<?php if(isset($mobile)){echo $mobile;} ?>" <?php if(isset($code) && $code == 6){ echo "autofocus"; }  ?>>
								</div>
								<div class="col-sm-12 error">
					  				<div id="mobile_error"><?php if($code==6){echo $error_mobile;}?></div>
						    	</div>
							</div>
					 	</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-6 col-xs-12">
					 	<div class="form-group group-height">
					 		<div class="row">
					  			<div class="col-sm-12">
								    <label for="lastName">Last Name</label>
								    <input type="text" id="lastName" class="form-control" placeholder="Please enter your last name" name="lastName" value="<?php if(isset($lname)){echo $lname;} ?>" <?php if(isset($code) && $code == 7){ echo "autofocus"; }  ?>>
								</div>
					  			<div class="col-sm-12 error">
					  				<div id="lname_error"><?php if($code==7){echo $error_lname;}?></div>
								</div>
							</div>
					 	</div>
					</div>
					<div class="col-sm-6 col-xs-12">
					 	<div class="form-group group-height">
					 		<div class="row">
					  			<div class="col-sm-12">
								    <label for="phone">Phone</label>
								    <input type="text" id="phone" class="form-control" name="phone" placeholder="Please enter your phone" >
								</div>
					  			<div class="col-sm-12 error">
					  				<div id="phone_error"></div>
								</div>
							</div>
					 	</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12 col-xs-12">
						<div class="form-group">
						    <label for="interest">Interests</label>
						    <div class="checkbox">
						  		<label>
						    	<input type="checkbox" name="interest" id="select" onclick="select_all(this)" id="select" value="">Select All
						  		</label>
							</div>
						    <div class="checkbox">
						  		<label>
						    	<input type="checkbox" name="interest" id="opt1" value="">Option 1
						  		</label>
							</div>
							<div class="checkbox">
						  		<label>
						    	<input type="checkbox" name="interest" id="opt2" value="">Option 2
						  		</label>
							</div>
							<div class="checkbox">
						  		<label>
						    	<input type="checkbox" name="interest" id="opt3" value="">Option 3
						  		</label>
							</div>						
							<div class="checkbox">
								<div class="row">
									<div class="col-sm-1 col-xs-3">
								  		<label>
								    	<input type="checkbox" name="interest_other" id="other" value="other" onclick="showInputBox()">Other
								  		</label>		
									</div>
									<div class="col-sm-2 col-xs-4">
						  				<input type="text" name="other_tb" id="other_tb" class="form-control other-tb">
									</div>
									<div class="col-sm-9 col-xs-5"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12 col-xs-12 hr-color">
						<hr>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-6 col-xs-12">
						<div class="checkbox">
					  		<label>
					    	<input type="checkbox" id="mandatory" name="mandatory" value="">I agree with Terms and Conditions.
					  		</label>
					  		<div class="error">
					    		<label for="mandatory" class="error errorMsg"></label>
					    	</div>
						</div>
					</div>
					<div class="col-sm-offset-3 col-sm-3 col-xs-12 btn-padding">
						<input type="submit" class="btn submit-btn-style" value="Submit" name="registerUser">
						<input type="reset" onclick="return clearAllValue()" class="btn clear-btn-style pull-right" value="Clear">
					</div>
				</div>
				</form>
			</div>
		</div>
		<!--	Footer 		-->
		<?php include_once 'footer.php' ?>
	</body>
</html>