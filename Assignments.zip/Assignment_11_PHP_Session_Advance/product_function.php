<?php
function product(){
	include 'dbConnection.php';
	echo "<div class=\"row description\">";
	$selectProduct="SELECT * FROM `item` LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id LIMIT 8";
	$resultItem=mysqli_query($con,$selectProduct);
	while($row=mysqli_fetch_assoc($resultItem)){
		?>
		<div class="col-sm-3 product-block">
			<div class="background-color">
				<img src="images/<?php echo $row['item_image_url']?>" class="img-rounded image" >
				<div class="middle">
			    	<div class="rollover-btn"><a href="product">Add to Cart</a></div>
			  	</div>
			</div>
			<div class="row"><div class="col-sm-12"><p><?php echo $row['name']; ?></p></div></div>
			<div class="row"><div class="col-sm-12 price"><p><b>$<?php echo $row['price']; ?>.00</b></p></div></div>
		</div>
	<?php
	}
	?>
	</div>
	<?php
}
// product();
?>