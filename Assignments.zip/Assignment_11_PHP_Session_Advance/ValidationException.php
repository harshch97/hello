<?php
class ValidationException extends Exception {
 
    public function __construct($field, $error) {
        $message = sprintf(
            '%s %s',
            $field, $error
        );
        parent::__construct($message, 13, null);
    }
}
?>