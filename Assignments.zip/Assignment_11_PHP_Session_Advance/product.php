<!DOCTYPE html>
<html lang="en">
	<head>
		<title>eShopper Online Store</title>
		<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="css/bootstrap.min.css">
  		<link rel="icon" href="images/favicon.ico">
  		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  		<script type="text/javascript" src="js/bootstrap.min.js"></script>
  		<script type="text/javascript" src="js/script.js"></script>
		<link rel="stylesheet" href="css/style.css" >
		<link rel="stylesheet" href="css/media.css" >
	</head>
	<body>
		<!--	Header 		-->
		<?php include 'header.php';?>
		<!--	Main content 	-->
		<header class="banner">
			<img src="images/inner-banner.jpg">
		</header>
		<a id="topBtn" title="Go to top"><img class="up-arrow" src="images/img_transparent.png"></div></a>
		<div class="container">
			<div class="background-content">
				<div class="row">
					<div class="col-sm-12 col-xs-12 padding-breadcrumb">
						<ul class="breadcrumb">
							<li>Home</li>
							<li>Men</li>
							<li class="last-item">T-shirts</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="register">
				<h2>Men</h2>
			</div>
			<div class="row sub-bottom">
				<div class="col-sm-3 col-xs-12">
					<div class="row">
						<div class="col-sm-12 col-xs-12">
							<div class="panel panel-default">
							    <div class="panel-heading heading-panel">Filter By</div>
							    <div class="panel-body left-bottom-border">
							    	<div class="row">
							    		<div class="col-sm-10 col-xs-10">CATEGORIES</div>
							    		<div class="col-sm-2 col-xs-2"><a data-toggle="collapse" data-target="#categories"><div class="col-minus"></div></a></div>
							    	</div>
							    	<div class="row">
							    		<div class="col-sm-12 col-xs-12">
							    			<div id="categories" class="collapse in">
							    				<div class="checkbox">
											  		<label>
											    	<input type="checkbox" value="">T-shirts <sub>(25275)</sub>
											  		</label>
												</div>
											    <div class="checkbox">
											  		<label>
											    	<input type="checkbox" value="">Shirts <sub>(24866)</sub>
											  		</label>
												</div>
												<div class="checkbox">
											  		<label>
											    	<input type="checkbox" value="">Jackets <sub>(5326)</sub>
											  		</label>
												</div>
												<div class="checkbox">
											  		<label>
											    	<input type="checkbox" value="">Sweaters <sub>(4871)</sub>
											  		</label>
												</div>
												<div class="checkbox">
											  		<label>
											    	<input type="checkbox" value="">Sweatshirts <sub>(4533)</sub>
											  		</label>
												</div>
												<div class="checkbox">
											  		<label>
											    	<input type="checkbox" value="">Kurtas <sub>(1566)</sub>
											  		</label>
												</div>
		  									</div>
							    		</div>
							    	</div>
							    </div>
							    <div class="panel-body left-bottom-border">
							    	<div class="row">
							    		<div class="col-sm-10 col-xs-10">COLOUR</div>
							    		<div class="col-sm-2 col-xs-2"><a data-toggle="collapse" data-target="#color-category"><div class="col-minus"></div></a></div>
							    	</div>
							    	<div class="row">
							    		<div class="col-sm-12 col-xs-12">
							    			<div id="color-category" class="collapse in">
							    				<div class="row row-height">
							    					<div class="col-sm-2 col-xs-1"><div class="magenta"></div></div>
							    					<div class="col-sm-10 col-xs-11 btn-normal btn-margin"><button type="submit" class="btn-default">Magenta <sub>(1250)</sub></button></div>
							    				</div>
							    				<div class="row row-height">
							    					<div class="col-sm-2 col-xs-1"><div class="pink"></div></div>
							    					<div class="col-sm-10 col-xs-11 btn-normal btn-margin"><button type="submit" class="btn-default disable" disabled="">Pink <sub>(150)</sub></button></div>
							    				</div>
							    				<div class="row row-height">
							    					<div class="col-sm-2 col-xs-1"><div class="red"></div></div>
							    					<div class="col-sm-10 col-xs-11 btn-normal btn-margin"><button type="submit" class="btn-default">Red <sub>(100)</sub></button></div>
							    				</div>
							    				<div class="row row-height">
							    					<div class="col-sm-2 col-xs-1"><div class="lavender"></div></div>
							    					<div class="col-sm-10 col-xs-11 btn-normal btn-margin"><button type="submit" class="btn-default">Lavender <sub>(250)</sub></button></div>
							    				</div>
							    				<div class="row row-height">
							    					<div class="col-sm-2 col-xs-1"><div class="navy"></div></div>
							    					<div class="col-sm-10 col-xs-11 btn-normal btn-margin"><button type="submit" class="btn-default">Navy <sub>(50)</sub></button></div>
							    				</div>
							    				<div class="row row-height">
							    					<div class="col-sm-2 col-xs-1"><div class="blue"></div></div>
							    					<div class="col-sm-10 col-xs-11 btn-normal btn-margin"><button type="submit" class="btn-default">Blue <sub>(1220)</sub></button></div>
							    				</div>
							    				<div class="row row-height">
							    					<div class="col-sm-2 col-xs-1"><div class="grey"></div></div>
							    					<div class="col-sm-10 col-xs-11 btn-normal btn-margin"><button type="submit" class="btn-default">Grey <sub>(2250)</sub></button></div>
							    				</div>
							    				<div class="row row-height">
							    					<div class="col-sm-2 col-xs-1"><div class="teal"></div></div>
							    					<div class="col-sm-10 col-xs-11 btn-normal btn-margin"><button type="submit" class="btn-default">Teal <sub>(1350)</sub></button></div>
							    				</div>
							    				<div class="row row-height">
							    					<div class="col-sm-2 col-xs-1"><div class="peach"></div></div>
							    					<div class="col-sm-10 col-xs-11 btn-normal btn-margin"><button type="submit" class="btn-default">Peach <sub>(1550)</sub></button></div>
							    				</div>
							    				<div class="row row-height">
							    					<div class="col-sm-2 col-xs-1"><div class="orange"></div></div>
							    					<div class="col-sm-10 col-xs-11 btn-normal btn-margin"><button type="submit" class="btn-default">Orange <sub>(10)</sub></button></div>
							    				</div>
							    				<div class="row">
							    					<div class="col-sm-offset-2 col-sm-10 col-sm-offset-2 col-xs-10 btn-normal btn-color"><button type="submit" class="btn-link">Reset</button></div>
							    				</div>
							    			</div>
							    		</div>
							    	</div>
							    </div>
							    <div class="panel-body left-bottom-border">
							    	<div class="row">
							    		<div class="col-sm-10 col-xs-10">PRICE</div>
							    		<div class="col-sm-2 col-xs-2"><a data-toggle="collapse" data-target="#price-category"><div class="col-minus"></div></a></div>
							    	</div>
							    	<div id="price-category" class="collapse in" >
								    	<div class="row text-align-modal">
								    		<div class="col-sm-12 col-xs-12">
								    			31 items
								    		</div>
								    	</div>
								    	<div class="row">
								    		<div class="col-sm-12 col-xs-12">
												<img src="images/price.jpg" />	
								    		</div>
								    	</div>
								    	<div class="row">
								    		<div class="col-sm-6 col-xs-6">
								    			<p>Rs. 174</p>
								    		</div>
								    		<div class="col-sm-6 col-xs-6 right-align">
								    			<p>Rs. 8,999</p>
								    		</div>
								    	</div>
								    </div>
							    </div>
							    <div class="panel-body">
							    	<div class="row">
							    		<div class="col-sm-10 col-xs-10">SIZE</div>
							    		<div class="col-sm-2 col-xs-2"><a data-toggle="collapse" data-target="#size-category"><div class="col-minus"></div></a></div>
							    	</div>
							    	<div class="row">
							    		<div class="col-sm-12 col-xs-12">
							    			<div id="size-category" class="collapse in">
							    				<div class="checkbox">
											  		<label>
											    	<input type="checkbox" value="">XXS <sub>(81)</sub>
											  		</label>
												</div>
											    <div class="checkbox">
											  		<label>
											    	<input type="checkbox" value="">XS <sub>(1446)</sub>
											  		</label>
												</div>
												<div class="checkbox">
											  		<label>
											    	<input type="checkbox" value="">S <sub>(24706)</sub>
											  		</label>
												</div>
												<div class="checkbox">
											  		<label>
											    	<input type="checkbox" value="">M <sub>(29467)</sub>
											  		</label>
												</div>
												<div class="checkbox">
											  		<label>
											    	<input type="checkbox" value="">L <sub>(29516)</sub>
											  		</label>
												</div>
												<div class="checkbox">
											  		<label>
											    	<input type="checkbox" value="">XL <sub>(27823)</sub>
											  		</label>
												</div>
												<div class="checkbox">
											  		<label>
											    	<input type="checkbox" value="">XXL <sub>(16841)</sub>
											  		</label>
												</div>
												<div class="checkbox">
											  		<label>
											    	<input type="checkbox" value="">XXXL <sub>(43)</sub>
											  		</label>
												</div>
							    			</div>
							    		</div>
							    	</div>
							    </div>
							</div>
						</div>
					</div>
					<div class="col-sm-12 col-xs-12 image image-responsive promo-image">
						<a href="product_list"><img src="images/promo2.jpg" /></a>
					</div>
				</div>
				<div class="col-sm-9 col-xs-12">
					<div class="row men-title">
						<div class="col-sm-12 col-xs-12">
							<p>Men T-shirts</p>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12 col-xs-12">
							<div class="pull-right">
							    <label for="size">Size</label>
							    <select name="size">
								  	<option>Position</option>
								  	<option>Name</option>
								  	<option>Price</option>
								</select>
						  	</div>
						</div>
					</div>
					<div class="row description">
						<div class="col-sm-4">
							<img src="images/new-thumb-01.jpg" class="img-rounded image" >
							<div class="row"><div class="col-sm-12"><p>US Polo Assn. Full Sleeve Plain T-shirt for Men</p></div></div>
							<div class="row"><div class="col-sm-12 price"><p><b>$120.00</b></p></div></div>
						</div>
						<div class="col-sm-4">
							<img src="images/new-thumb-02.jpg" class="img-rounded image" >
							<div class="row"><div class="col-sm-12"><p>US Polo Assn. Full Sleeve Plain T-shirt for Men</p></div></div>
							<div class="row"><div class="col-sm-12 price"><p><b>$120.00</b></p></div></div>
						</div>
						<div class="col-sm-4">
							<img src="images/new-thumb-01.jpg" class="img-rounded image" >
							<div class="row"><div class="col-sm-12"><p>US Polo Assn. Full Sleeve Plain T-shirt for Men</p></div></div>
							<div class="row"><div class="col-sm-12 price"><p><b>$120.00</b></p></div></div>
						</div>
					</div>
					<div class="row description">
						<div class="col-sm-4">
							<img src="images/new-thumb-04.jpg" class="img-rounded image" >
							<div class="row"><div class="col-sm-12"><p>US Polo Assn. Full Sleeve Plain T-shirt for Men</p></div></div>
							<div class="row"><div class="col-sm-12 price"><p><b>$120.00</b></p></div></div>
						</div>
						<div class="col-sm-4">
							<img src="images/new-thumb-05.jpg" class="img-rounded image" >
							<div class="row"><div class="col-sm-12"><p>US Polo Assn. Full Sleeve Plain T-shirt for Men</p></div></div>
							<div class="row"><div class="col-sm-12 price"><p><b>$120.00</b></p></div></div>
						</div>
						<div class="col-sm-4">
							<img src="images/new-thumb-06.jpg" class="img-rounded image" >
							<div class="row"><div class="col-sm-12"><p>US Polo Assn. Full Sleeve Plain T-shirt for Men</p></div></div>
							<div class="row"><div class="col-sm-12 price"><p><b>$120.00</b></p></div></div>
						</div>
					</div>
					<div class="row description">
						<div class="col-sm-4">
							<img src="images/new-thumb-07.jpg" class="img-rounded image" >
							<div class="row"><div class="col-sm-12"><p>US Polo Assn. Full Sleeve Plain T-shirt for Men</p></div></div>
							<div class="row"><div class="col-sm-12 price"><p><b>$120.00</b></p></div></div>
						</div>
						<div class="col-sm-4">
							<img src="images/new-thumb-01.jpg" class="img-rounded image" >
							<div class="row"><div class="col-sm-12"><p>US Polo Assn. Full Sleeve Plain T-shirt for Men</p></div></div>
							<div class="row"><div class="col-sm-12 price"><p><b>$120.00</b></p></div></div>
						</div>
						<div class="col-sm-4">
							<img src="images/new-thumb-01.jpg" class="img-rounded image" >
							<div class="row"><div class="col-sm-12"><p>US Polo Assn. Full Sleeve Plain T-shirt for Men</p></div></div>
							<div class="row"><div class="col-sm-12 price"><p><b>$120.00</b></p></div></div>
						</div>
					</div>
					<div class="row description">
						<div class="col-sm-4">
							<img src="images/new-thumb-02.jpg" class="img-rounded image" >
							<div class="row"><div class="col-sm-12"><p>US Polo Assn. Full Sleeve Plain T-shirt for Men</p></div></div>
							<div class="row"><div class="col-sm-12 price"><p><b>$120.00</b></p></div></div>
						</div>
						<div class="col-sm-4">
							<img src="images/new-thumb-01.jpg" class="img-rounded image" >
							<div class="row"><div class="col-sm-12"><p>US Polo Assn. Full Sleeve Plain T-shirt for Men</p></div></div>
							<div class="row"><div class="col-sm-12 price"><p><b>$120.00</b></p></div></div>
						</div>
						<div class="col-sm-4">
							<img src="images/new-thumb-04.jpg" class="img-rounded image" >
							<div class="row"><div class="col-sm-12"><p>US Polo Assn. Full Sleeve Plain T-shirt for Men</p></div></div>
							<div class="row"><div class="col-sm-12 price"><p><b>$120.00</b></p></div></div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12 col-xs-12">
							<div class="more-product-btn more-product-margin">
								<button class="btn center-block btn-style" type="button">More Products</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--	Footer 		-->
		<?php include 'footer.php'; ?>
	</body>
</html>