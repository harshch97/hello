<!DOCTYPE html>
<html lang="en">
	<head>
		<title>eShopper Online Store</title>
		<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<meta http-equiv="Cache-Control" content="no-cache"> 
  		<link rel="stylesheet" href="css/bootstrap.min.css">
  		<link rel="icon" href="images/favicon.ico">
  		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  		<script type="text/javascript" src="js/bootstrap.min.js"></script>
  		<script type="text/javascript" src="js/script.js"></script>
		<link rel="stylesheet" href="css/style.css" >
		<link rel="stylesheet" href="css/media.css" >
	</head>
	<body onload="displayPrice()">
		<!--	Header 		-->
		<?php include 'header.php';?>
		<!--	Main content 	-->
		<header class="banner">
			<img src="images/inner-banner.jpg">
		</header>
		<a id="topBtn" title="Go to top"><img class="up-arrow" src="images/img_transparent.png"></div></a>
		<div class="container">
			<div class="background-content">
				<div class="row">
					<div class="col-sm-12 col-xs-12 padding-breadcrumb">
						<ul class="breadcrumb">
							<li>Home</li>
							<li>Men</li>
							<li>T-shirts</li>
							<li class="last-item">U.S. Polo Assn. Full Sleeve Plain T-Shirts for Men</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="t-shirts">
				<h2>T-shirts</h2>
			</div>
			<div class="row">
				<div class="col-sm-12 col-xs-12 collapse" id="wishList">
					<div class="alert alert-success alert-dismissable">
				    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
				    	<div class="row">
				    		<div class="col-sm-1 col-xs-1 success-icon"></div>
				    		<div class="col-sm-11 col-xs-11 data-display">
				    			U.S. Polo Assn. Full Sleeve Plain T-Shirts for Men was added to your shopping cart.	
				    		</div>
				    	</div>
				  	</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-5">
					<div class="row">
						<div class="col-sm-12 col-xs-12">
							<img id="largeImage" src="images/new-thumb-01-big.jpg"/>
						</div>
						<div class="col-sm-12 col-xs-12">
						<br>
							<div class="row">
								<div class="col-sm-1 col-xs-1 prev-arrow-left">
									<a class="left slider-margin" href="#myCarousel" data-slide="prev"><div class="prev-arrow-slider"></div></a>
								</div>
								<div class="col-sm-10 col-xs-10" id="thumbs">
									<div class="carousel img-carousel slide" id="myCarousel">
									  	<div class="carousel-inner">
										    <div class="item active">
										      	<div class="col-sm-3 col-xs-4">
										      		<a><img src="images/new-thumb-01-big.jpg" class="img-responsive" alt="1st image description"></a>
										      	</div>
										    </div>
										    <div class="item">
										      	<div class="col-sm-3 col-xs-4">
										      		<a><img src="images/new-thumb-02-big.jpg" class="img-responsive" alt="2nd image description"></a>
										      	</div>
										    </div>
										    <div class="item">
										      	<div class="col-sm-3 col-xs-4">
										      		<a><img src="images/new-thumb-03-big.jpg" class="img-responsive" alt="3rd image description"></a>
										      	</div>
										    </div>
										    <div class="item">
										      	<div class="col-sm-3 col-xs-4">
										      		<a><img src="images/new-thumb-04-big.jpg" class="img-responsive" alt="4th image description"></a>
										      	</div>
										    </div>
										    <div class="item">
										      	<div class="col-sm-3 col-xs-4">
										      		<a><img src="images/new-thumb-05-big.jpg" class="img-responsive" alt="5th image description"></a>
										      	</div>
										    </div>
										    <div class="item">
										      	<div class="col-sm-3 col-xs-4">
										      		<a><img src="images/new-thumb-06-big.jpg" class="img-responsive" alt="6th image description"></a>
										      	</div>
										    </div>
										    <div class="item">
										      	<div class="col-sm-3 col-xs-4">
										      		<a><img src="images/new-thumb-07-big.jpg" class="img-responsive" alt="7th image description"></a>
										      	</div>
										    </div>
										    <div class="item">
										      	<div class="col-sm-3 col-xs-4">
										      		<a><img src="images/new-thumb-08-big.jpg" class="img-responsive" alt="8th image description"></a>
										      	</div>
										    </div>
									  	</div>
									</div>
								</div>
								<div class="col-sm-1 col-xs-1 next-arrow-right">
							  		<a class="right slider-margin" href="#myCarousel" data-slide="next"><div class="next-arrow-slider"></div></a>
							  	</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-7">
					<h1>U.S. Polo Assn. Full Sleeve Plain T-Shirts for Men</h1>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus imperdiet, nulla et dictum interdum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus imperdiet, nulla et dictum interdum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus imperdiet, nulla et dictum interdum</p>
					<div class="parent">SKU : <div class="bold-font">mag209_prod1</div></div>
					<div class="parent">Availability : <div class="stock-label">In Stock</div><div class="not-avail-label">Not Available</div></div>
					<div class="price-font" id="price"></div>
					<div class="row parent">
						<div class="col-xs-6 col-xs-6"><div class="start-color">*</div><div class="data-content">Size</div></div>
						<div class="col-xs-6 col-xs-6">
							<div class="pull-right start-color">* Required fields</div>
						</div>
					</div>
					<div class="row margin-top">
						<div class="col-xs-12 col-xs-12">
							<select class="form-control">
							  	<option>--Please Select--</option>
							  	<option>Option1</option>
							  	<option>Option2</option>
							</select>
						</div>
					</div>
					<div class="row margin-top height parent">
						<div class="col-xs-12 col-xs-12">
							<label for="qty">Qty : </label>
							<select id="qty" onchange="displayPrice()">
							  	<option>1</option>
							  	<option>2</option>
							  	<option>3</option>
							  	<option>4</option>
							  	<option>5</option>
							</select>
							<button type="button" class="btn cart-btn-style" onclick="addToCart()"><div class="cart"></div><div class="btn-data">ADD TO CART</div></button>
						</div>	
					</div>
					<div class="row">
						<div class="col-sm-12 col-xs-12 wish-list btn-normal btn-color btn-bg">
							<button id="wishListBtn" data-toggle="collapse" class="btn btn-color">Add to Wishlist</button>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12 col-xs-12">
							<ul class="nav nav-tabs nav-border">
							    <li class="active"><a data-toggle="tab" href="#delivery">Delivery</a></li>
							    <li><a data-toggle="tab" href="#shipping">Shipping</a></li>
							    <li><a data-toggle="tab" href="#sizeguide">Sizeguide</a></li>
							</ul>
							<div class="tab-content tab-border">
							    <div id="delivery" class="tab-pane fade in active">
							      	<p class="table-margin">We offer following delivery options for 24 hours over the world. Deliveries are not made on Saturdays, Sundays and public holidays. A specific time slot can not be specified with any of the delivery options. Please refer to the Terms and Conditions of Sale.</p>
							    </div>
							    <div id="shipping" class="tab-pane fade">	
							      	<p class="table-margin">We offer following delivery options for 24 hours over the world. Deliveries are not made on Saturdays, Sundays and public holidays. A specific time slot can not be specified with any of the delivery options. Please refer to the Terms and Conditions of Sale.</p>
							    </div>
							    <div id="sizeguide" class="tab-pane fade">	
							      	<div class="table-responsive table-margin">
						  				<table class="table tbl-border">
						  					<thead>
										      	<tr class="row-background">
											        <th>Size</th>
											        <th>S</th>
											        <th>M</th>
											        <th>L</th>
											        <th>XL</th>
										      	</tr>
										    </thead>
										    <tbody>
											    <tr>
											        <td>Men</td>
											        <td>7-10</td>
											        <td>10-13</td>
											        <td>13-15</td>
											        <td>15-17</td>
										      	</tr>
									      	</tbody>
										    <tbody>
											    <tr>
											        <td>Women</td>
											        <td>7-9</td>
											        <td>10-12</td>
											        <td>13-14</td>
											        <td>15-16</td>
										      	</tr>
									      	</tbody>
									    </table>
									</div>
							    </div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row row-margin">
				<div class="col-sm-12 col-xs-12">
					<ul class="nav nav-tabs nav-border">
					    <li class="active"><a data-toggle="tab" href="#product_description">Product Description</a></li>
					    <li><a data-toggle="tab" href="#product_review">Product's Review</a></li>
					    <li><a data-toggle="tab" href="#cms_tab">CMS Tab</a></li>
					</ul>
					<div class="tab-content tab-border">
					    <div id="product_description" class="tab-pane fade in active table-margin ">
					      	<h5>Simple Lorem ipsum Text.</h5>
					      	<div class="margin-p">
					      		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it?</p>
					      		<p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.</p>
					      	</div>
					    </div>
					    <div id="product_review" class="tab-pane fade table-margin ">
					    	<div class="row">
					    		<div class="col-sm-12 col-xs-12 btn-color btn-decorate">
					      			<button type="button" class="btn btn-link"  data-toggle="collapse" data-target="#product_review_link">Write a review</button>
					      		</div>
					      	</div>
					      	<div class="row hr">
					    		<div class="col-sm-12 col-xs-12 btn-color btn-decorate">
					      			<hr>
					      		</div>
					      	</div>
					      	<div class="row">
					    		<div class="col-sm-12 col-xs-12 collapse" id="product_review_link">
									<div class="row row-margin-top">
										<div class="col-sm-12 col-xs-12">
											<!-- <div id="star"></div>
											<div id="star"></div>
											<div id="star"></div>
											<div id="star"></div>
											<div id="star"></div> -->
											<!-- <span class="starRating">
											  	<input id="rating5" type="radio" name="rating" value="5">
											  	<label for="rating5">5</label>
											  	<input id="rating4" type="radio" name="rating" value="4">
											  	<label for="rating4">4</label>
											  	<input id="rating3" type="radio" name="rating" value="3">
											  	<label for="rating3">3</label>
											  	<input id="rating2" type="radio" name="rating" value="2">
											  	<label for="rating2">2</label>
											  	<input id="rating1" type="radio" name="rating" value="1">
											  	<label for="rating1">1</label>
											</span> -->
											 <!-- Rating Stars Box -->
										  	<div class='rating-stars text-center'>
										    	<ul id='stars'>
											      	<li class='star' title='Poor' data-value='1'>
											        	<i class='fa'></i>
											      	</li>
											      	<li class='star' title='Fair' data-value='2'>
											        	<i class='fa'></i>
											      	</li>
											      	<li class='star' title='Good' data-value='3'>
											        	<i class='fa'></i>
											      	</li>
											      	<li class='star' title='Excellent' data-value='4'>
											        	<i class='fa'></i>
											      	</li>
											      	<li class='star' title='WOW!!!' data-value='5'>
											        	<i class='fa'></i>
											      	</li>
										    	</ul>
										  	</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-12 col-xs-12">
											<div class="form-group">
											   	<textarea id="message" class="form-control review-size" placeholder="Write a review"></textarea>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-12 col-xs-12">
											<div class="form-group">
											   	<button style="button" class="btn submit-btn-style">Submit</button>
											</div>
										</div>
									</div>
								</div>
					      	</div>
					      	<div class="row">
					      		<div class="col-sm-12 col-xs-12 margin-left-p">
					      			<p class="total">Vishuddhi, 26-12-2016 writes:</p>
					      		</div>
					      	</div>
					      	<div class="row">
					      		<div class="col-sm-12 col-xs-12">
					      			<p class="table-margin">We offer following delivery options for 24 hours over the world. Deliveries are not made on Saturdays, Sundays and public holidays. A specific time slot can not be specified with any of the delivery options. Please refer to the Terms and Conditions of Sale.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
					      		</div>
					      	</div>
					    </div>
					    <div id="cms_tab" class="tab-pane fade table-margin ">
					      	<h5>Simple Lorem ipsum Text.</h5>
					      	<div class="margin-p">
					      		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it?</p>
					      		<p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.</p>
					      	</div>
					    </div>
					</div>
				</div>
			</div>
		</div>
		<!--	Footer 		-->
		<?php include 'footer.php'; ?>
	</body>
</html>