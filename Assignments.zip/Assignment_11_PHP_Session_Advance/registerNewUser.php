<?php
include 'dbConnection.php';
$username=$_POST['username'];
$password=md5($_POST['password']);
$gender=$_POST['gender'];
$email=$_POST['email'];
$fname=$_POST['firstName'];
$mobile=$_POST['mobile'];
$lname=$_POST['lastName'];
$phone=$_POST['phone'];	
$address=$_SERVER['HTTP_REFERER'];
$uniqEmail="SELECT `username`,`email` FROM `user` WHERE `username`='$username' OR `email`='$email'";
$result=mysqli_query($con,$uniqEmail);
$rows=mysqli_num_rows($result);

if($rows==0){
	$query="INSERT INTO `user`(`username`, `password`, `firstname`, `lastname`, `gender`, `email`, `mobile_number`, `phone_number`) VALUES ('$username','$password','$fname','$lname','$gender','$email','$mobile','$phone')";
	$result=mysqli_query($con,$query);
	if($result){
		$subject = "eShopping Registration";
		$txt = "Welcome, " . $fname . " " . $lname . "\r\n";
		$txt .= "\t" . "You are successfully registered!";
		$headers = 'From: krushiva.patel@internal.mail' . "\r\n";
		$headers .= 'Cc: krushiva.patel@internal.mail' . "\r\n";
		mail($email,$subject,$txt,$headers);
		echo "<script>";
		echo "alert('You are successfully registered!');";
		echo "window.location.replace(\"$address\");";
		echo "</script>";
	}
	else
		echo "Unable to register!";
}
else{
	echo "<script>";
	echo "alert('Username and Email id should be unique');";
	echo "window.location.replace(\"$address\");";
	echo "</script>";
}
?>