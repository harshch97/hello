<?php

class ProductModel extends basemodel
{
	public function fetchProducts(){
		$getProducts="SELECT `item_options`.id,`item`.id as item_id,`item`.name,`item`.price,`item_images`.item_image_url,`attribute_options`.value
					FROM `item_options` 
					LEFT JOIN `item` ON `item_options`.item_id=`item`.id 
					LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
					LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id 
					WHERE `item_images`.is_primary=1";
		$result=$this->_db->query($getProducts);
		return $this->getResultArray($result);
	}
	public function fetchSubcategory(){
		$getProductSubcategory="SELECT `id`, `name` FROM `category` WHERE `parent_id`=1";
		$result=$this->_db->query($getProductSubcategory);
		return $this->getResultArray($result);
	}
	public function fetchColor(){
		$getProductColor="SELECT `id`,  `value` FROM `attribute_options` WHERE `attribute_id`=2";
		$result=$this->_db->query($getProductColor);
		return $this->getResultArray($result);
	}
	public function fetchSize(){
		$getProductSize="SELECT `id`,  `value` FROM `attribute_options` WHERE `attribute_id`=1";
		$result=$this->_db->query($getProductSize);
		return $this->getResultArray($result);
	}
}
?>