document.write(
	'<script type="text/javascript" src="'+assets_url+'js/jquery.min.js"></script>' +	
	'<script type="text/javascript" src="'+assets_url+'js/bootstrap.min.js"></script>' +
	'<script type="text/javascript" src="'+assets_url+'js/modernizr.js"></script>' +	
	'<script type="text/javascript" src="'+assets_url+'js/owl.carousel.js"></script>' +	
	'<script type="text/javascript" src="'+assets_url+'js/placeholders.min.js"></script>' +	
	'<script type="text/javascript" src="'+assets_url+'js/fastclick.js"></script>' +		
	'<script type="text/javascript" src="'+assets_url+'js/html5shiv.min.js"></script>' +
	'<script type="text/javascript" src="'+assets_url+'js/jquery.fancybox.js"></script>' +
	'<script type="text/javascript" src="'+assets_url+'js/respond.min.js"></script>'
	);

