<?php
    $assets_url = ASSETS_URL;
    foreach ($imageDescription as $imgDesc) {
    	$itemName=$imgDesc['name'];
    	$sku=$imgDesc['sku'];
    	$price=$imgDesc['price'];
    	$qty=$imgDesc['qty'];
    	$shortDesc=$imgDesc['short_desc'];
    	$desc=$imgDesc['description'];
    	$deliveryDesc=$imgDesc['delivery_desc'];
    	$shippingDesc=$imgDesc['shipping_desc'];
 		// echo "<pre>";print_r($imageDescription[0]['sizeguide_desc']);exit(); 
    }
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>eShopper Online Store</title>
		<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<meta http-equiv="Cache-Control" content="no-cache"> 
  		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/bootstrap.min.css">
  		<link rel="icon" href="<?php echo $assets_url; ?>images/favicon.ico">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  		<script type="text/javascript" src="<?php echo $assets_url; ?>js/bootstrap.min.js"></script>
  		<script src='<?php echo $assets_url; ?>js/jquery.elevatezoom.js'></script>
  		
  		<!-- <script type="text/javascript" src="<?php echo $assets_url; ?>js/script.js"></script> -->
		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/style.css" >
		<link rel="stylesheet" href="<?php echo $assets_url; ?>css/media.css" >
	</head>
	<body>
		<!--	Main content 	-->
		<header class="banner">
			<img src="<?php echo $assets_url; ?>images/inner-banner.jpg">
		</header>
		<a id="topBtn" title="Go to top"><img class="up-arrow" src="<?php echo $assets_url; ?>images/img_transparent.png"></div></a>
		<div class="container">
			<div class="background-content">
				<div class="row">
					<div class="col-sm-12 col-xs-12 padding-breadcrumb">
						<ul class="breadcrumb">
							<li>Home</li>
							<li>Men</li>
							<li>T-shirts</li>
							<li class="last-item">U.S. Polo Assn. Full Sleeve Plain T-Shirts for Men</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="t-shirts">
				<h2>T-shirts</h2>
			</div>
			<div class="row">
				<div class="col-sm-12 col-xs-12 collapse" id="insertAlert">
				  	<div class="alert alert-success alert-dismissable">
				    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
				    	<div class="row">
				    		<div class="col-sm-1 col-xs-1 success-icon">
				    		</div>
				    		<div class="col-sm-11 col-xs-11 data-display" id="insertItem">	
				    		</div>
				    	</div>
				  	</div>
				</div>
				<div class="col-sm-12 col-xs-12 collapse" id="warningAlert">
					<div class="alert alert-info alert-dismissable">
				    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
				    	<div class="row">
				    		<div class="col-sm-1 col-xs-1 info-icon">
				    		</div>
				    		<div class="col-sm-11 col-xs-11 data-display" id="warningMsg">
				    		</div>
				    	</div>
				  	</div>
				</div>
				<div class="col-sm-12 col-xs-12 collapse" id="loginAlert">
				  	<div class="alert alert-danger alert-dismissable">
				    	<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
				    	<div class="row">
				    		<div class="col-sm-1 col-xs-1 error-icon">
				    		</div>
				    		<div class="col-sm-11 col-xs-11 data-display" id="loginMsg">
				    		</div>
				    	</div>
				  	</div> 
				</div>
			</div>
			<div class="row">
				<div class="col-sm-5">
					<div class="row">
						<div class="col-sm-12 col-xs-12">
							<?php 
							$largeimg=trim($sliderImages[0]['item_image_url'],".jpg") . "-big.jpg";
							// echo $largeimg; 
							?>
							<img id="largeImage" src="<?php echo $assets_url; ?>images/<?php echo $sliderImages[0]['item_image_url']?>" data-zoom-image="<?php echo $assets_url;?>images/<?php echo $largeimg; ?>" >
						</div>
						<div class="col-sm-12 col-xs-12">
						<br>
							<div class="row">
								<div class="col-sm-1 col-xs-1 prev-arrow-left">
									<a class="left slider-margin" href="#myCarousel" data-slide="prev"><div class="prev-arrow-slider"></div></a>
								</div>
								<div class="col-sm-10 col-xs-10" id="thumbs">
									<div class="carousel img-carousel slide" id="myCarousel">
									  	<div class="carousel-inner">
									  		<?php 
											foreach ($sliderImages as $image) {
												$img=trim($image['item_image_url'],".jpg") . "-big.jpg";
												// echo $img;
											?>
										    <div class="item <?php echo ($image['is_primary']==1)?'active':''; ?>">
										      	<div class="col-sm-3 col-xs-4">
										      		<a><img src="<?php echo $assets_url; ?>images/<?php echo $image['item_image_url']; ?>" class="img-responsive" data-zoom-image="<?php echo $assets_url;?>images/<?php echo $img; ?>" ></a>
										      	</div>
										    </div>
										    <?php
											}
											?>
									  	</div>
									</div>
								</div>
								<div class="col-sm-1 col-xs-1 next-arrow-right">
							  		<a class="right slider-margin" href="#myCarousel" data-slide="next"><div class="next-arrow-slider"></div></a>
							  	</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-7">
					<h1 id="itemname"><?php echo $itemName; ?></h1>
					<p id="shortDesc"><?php echo $shortDesc; ?></p>
					<div class="parent" id="sku">SKU : <div class="bold-font"><?php echo $sku; ?></div></div>
					<div class="parent">Availability : 
						<?php
						if($qty>0){
						?>
							<div class="stock-label">In Stock</div>
						<?php 
						} 
						else{
						?>
							<div class="not-avail-label">Not Available</div>
						<?php 
						}
						?>
					</div>
					<input type="hidden" id="priceText" value="<?php echo $price; ?>">
					<div class="price-font" id="full-price">$<div id="price" class="display-price"><?php echo $price; ?></div>.00</div>
					<div class="row parent">
						<div class="col-xs-6 col-xs-6"><div class="start-color">*</div><div class="data-content">Size</div></div>
						<div class="col-xs-6 col-xs-6">
							<div class="pull-right start-color">* Required fields</div>
						</div>
					</div>
					<div class="row margin-top">
						<div class="col-xs-12 col-xs-12">
							<select class="form-control" id="size">
							  	<option selected="" disabled="">--Please Select--</option>
							  	<?php
							  	// echo "<pre>";print_r($size);exit();
							  	foreach ($size as $row) {
							  	?>
							  	<option value="<?php echo $row['id']; ?>"><?php echo $row['value']; ?></option>
							  	<?php
							  	}
							  	?>
							</select>
						</div>
					</div>
					<div class="row margin-top height parent">
						<div class="col-xs-12 col-xs-12">
							<label for="qty">Qty : </label>
							<select id="qty" onchange="displayPrice()">
							  	<option selected="" disabled="">--Select--</option>
							  	<?php
							  	for($i=1;$i<=$qty;$i++){
							  		?>
							  		<option value="<?php echo $i; ?>"><?php echo $i; ?></option>
							  		<?php
							  	}
							  	?>
							</select>
							<button type="button" class="btn cart-btn-style" onclick="return addToCart();"><div class="cart"></div><div class="btn-data">ADD TO CART</div></button>
						</div>	
					</div>
					<div class="row">
						<div class="col-sm-12 col-xs-12 wish-list btn-normal btn-color btn-bg">
							<input type="hidden" id="itemId" value="<?php echo $sliderImages[0]['item_id']; ?>">
							<button id="wishListBtn" data-toggle="collapse" class="btn btn-color" type="button">Add to Wishlist</button>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12 col-xs-12">
							<ul class="nav nav-tabs nav-border">
							    <li class="active"><a data-toggle="tab" href="#delivery">Delivery</a></li>
							    <li><a data-toggle="tab" href="#shipping">Shipping</a></li>
							    <li><a data-toggle="tab" href="#sizeguide">Sizeguide</a></li>
							</ul>
							<div class="tab-content tab-border">
							    <div id="delivery" class="tab-pane fade in active">
							      	<p class="table-margin" id="deliveryDesc"><?php echo $deliveryDesc; ?></p>
							    </div>
							    <div id="shipping" class="tab-pane fade">	
							      	<p class="table-margin" id="shippingDesc"><?php echo $shippingDesc; ?></p>
							    </div>

							    <div id="sizeguide" class="tab-pane fade">	
							      	<div class="table-responsive table-margin" id="sizeGuideDesc">
						  				<?php echo $imageDescription[0]['sizeguide_desc']; ?>
									</div>
							    </div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row row-margin">
				<div class="col-sm-12 col-xs-12">
					<ul class="nav nav-tabs nav-border">
					    <li class="active"><a data-toggle="tab" href="#product_description">Product Description</a></li>
					    <li><a data-toggle="tab" href="#product_review">Product's Review</a></li>
					    <li><a data-toggle="tab" href="#cms_tab">CMS Tab</a></li>
					</ul>
					<div class="tab-content tab-border">
					    <div id="product_description" class="tab-pane fade in active table-margin ">
					      	<div class="margin-p">
					      		<p id="productDesc"><?php echo $desc; ?></p>
					      	</div>
					    </div>
					    <div id="product_review" class="tab-pane fade table-margin ">
					    	<div class="row">
					    		<div class="col-sm-12 col-xs-12 btn-color btn-decorate">
					      			<button type="button" class="btn btn-link"  data-toggle="collapse" data-target="#product_review_link">Write a review</button>
					      		</div>
					      	</div>
					      	<div class="row hr">
					    		<div class="col-sm-12 col-xs-12 btn-color btn-decorate">
					      			<hr>
					      		</div>
					      	</div>
					      	<div class="row">
					    		<div class="col-sm-12 col-xs-12 collapse" id="product_review_link">
									<form method="post">
										<div class="row row-margin-top">
											<div class="col-sm-12 col-xs-12">
												<!-- Rating Stars Box -->
											  	<div class='rating-stars text-center'>
											    	<ul id='stars'>
												      	<li class='star' title='Poor' value="1" data-value='1'>
												        	<i class='fa'></i>
												      	</li>
												      	<li class='star' title='Fair' value="2" data-value='2'>
												        	<i class='fa'></i>
												      	</li>
												      	<li class='star' title='Good' value="3" data-value='3'>
												        	<i class='fa'></i>
												      	</li>
												      	<li class='star' title='Excellent' value="4" data-value='4'>
												        	<i class='fa'></i>
												      	</li>
												      	<li class='star' title='WOW!!!' value="5" data-value='5'>
												        	<i class='fa'></i>
												      	</li>
											    	</ul>
											    	<input type="hidden" id="starVal" >
											  	</div>
											</div>
										</div>
										<div class="row">
											<div class="col-sm-12 col-xs-12">
												<div class="form-group">
												   	<textarea id="message" class="form-control review-size" placeholder="Write a review"></textarea>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-sm-12 col-xs-12">
												<div class="form-group">
												   	<button type="button" id="reviewBtn" class="btn submit-btn-style">Submit</button>
												</div>
											</div>
										</div>
									</form>
								</div>
					      	</div>
					      	<div class="row">
					      		<div class="col-sm-12 col-xs-12 margin-left-p">
					      			<p class="total" id="new-title"></p>
					      			<p class="new-table-margin" id="new-review"></p>
					      		</div>
					      	</div>
					      	<?php
					      	foreach ($reviewData as $review) {
					      		$name=$review['firstname'];
					      		$date=strtotime($review['review_date']);
					      		$reviewText=$review['review_text'];
					      		$reviewStar=$review['ratings'];
					      		$dt=date('d-m-Y',$date);
					      	?>
					      	<div class="row">
					      		<div class="col-sm-12 col-xs-12 margin-left-p">
					      			<p class="total" id="title"><?php echo "$name, $dt writes:"; ?></p>
					      			<p class="table-margin"><?php echo $reviewText; ?></p>
					      		</div>
					      	</div>
					      	<?php
					      	}
					      	?>
					    </div>
					    <div id="cms_tab" class="tab-pane fade table-margin ">
					      	<div class="margin-p">
					      		<p><?php echo $desc; ?></p>
					      	</div>
					    </div>
					</div>
				</div>
			</div>
		</div>
		<script src='<?php echo $assets_url; ?>js/imageZoom.js'></script>
	</body>
</html>