<?php

/**
 * Function pr to print array without exit
 */
function pr($printarray)
{
	echo "<pre>";
	print_r($printarray);
	echo "</pre>";
}

/**
 * Function pre to print array with exit
 */
function pre($printarray)
{
	echo "<pre>";
	print_r($printarray);
	echo "</pre>";
	exit;
}

/**
 * Function to check if user is logged-in or not.
 */
function checkIfLogin()
{
	if(isset($_SESSION['user_id'])) {
		return true;
	} else {
		return false;
	}
}

/**
 * Function to get name of user.
 */
function getLoginUserName()
{
	return $_SESSION['name'];
}
function getLoginUserId()
{
	return $_SESSION['user_id'];
}

/**
 * Function to get user-id of logged-in user.
 */
function getUserId()
{
	return (!checkIfLogin() ? 0 : $_SESSION['user_id']);
}

function isAssociative(array $array)
    {
		
        $count_numeric_index = count(array_filter(array_keys($array), function($v){return is_numeric($v);}));
		if($count_numeric_index > 0)
			return false;
		else
			return true;
    }
	
	
function createUrl($route, $params = array())
{
	
	$url = SITE_URL . $route;
	if(!empty($params) && isAssociative($params)) {
		
		$url .= "?";
		$count = 0;
		foreach($params as $key=>$value) {
			if($count == 0)
				$url .= $key . "=" . $value;
			else
				$url .= "&".$key . "=" . $value;
			$count++;
		}
	}
	return $url;		
}

function showCart(){
    $assets_url = ASSETS_URL;
    $cartHTML = "<h3 class=\"popover-title\">Recently added item(s)</h3><table class=\"table table-responsive table-border\"><tbody class=\"scrollContent\">";
    foreach ($_SESSION["cart"] as $cartItem) {
        $totalPerItem=$cartItem['price']*$cartItem['qty'];
        $subtotal+=$totalPerItem;
        $cartHTML   .=  "<tr>
                            <td class=\"cart-img\"><img src=\"" . $assets_url . "images/" . $cartItem['item_image_url'] . "\"></td>
                            <td class=\"font-size-td\">" . $cartItem['name'] . "<div class=\"last-item\">$" . $cartItem['price'] . ".00</div><div class=\"detail\">Qty : " . $cartItem['qty'] . "<br>Size : " . $cartItem['value'] . "</div>
                            <td class=\"td-width\"><div class=\"edit-popup\"></div></td>
                            <td class=\"td-width\"><a><div class=\"cancel-popup\" title=\"" . $cartItem['id'] . "\"></div></a></td>
                        </tr>";
    }
    $cartHTML   .=  "</tbody>
                    <tbody>
                        <tr>
                            <td colspan=\"2\" class=\"font-cart\">Cart Subtotal : </td><td colspan=\"2\"><div class=\"total last-item position-td\">$" . $subtotal . ".00</div></td>
                        </tr>
                    </tbody>
                </table>
                <div class=\"row btn-align\">
                    <div class=\"col-sm-12 col-xs-12\">
                        <a href=\"".  SITE_URL . "cart\" class=\"btn update-btn\">View Cart</a>
                    </div>
                </div>";
    return $cartHTML;
}

?>
