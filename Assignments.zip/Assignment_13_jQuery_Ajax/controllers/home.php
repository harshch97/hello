<?php
error_reporting(0);
class Home extends BaseController {

    /**
     * @author Tatvasoft
     * Default method of Home controller and load header,main content,footer view.
     *   
     */
    public function __construct(){
        $this->load_model('HeaderModel');
    }
    public function index() {

        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $show_products['product']=$this->headermodel->fetchProducts();
        // $show_products['moreProducts']=$this->headermodel->fetchMoreProducts();
        // echo "<pre>";print_r($show_products);exit();
        $this->load_view('header', array('menuList' => $menuItemsList));
        $this->load_view('index',$show_products);
        $this->load_view('footer');
    }
    public function addSubscriber(){
        $address=$_SERVER['HTTP_REFERER'];
        $email=$_POST['email'];
        $success=$this->headermodel->addSubscriber($email);
        if($success){   
            $subject = "Newsletter Subscription";
            $txt = "Thank you for your Subscription!";
            $headers = 'From: krushiva.patel@internal.mail' . "\r\n";
            $headers .= 'Cc: krushiva.patel@internal.mail' . "\r\n";
            if(mail($email,$subject,$txt,$headers)){
                echo "<script>";
                echo "window.location.replace(\"$address?success=1\");";
                echo "</script>";
            }
            // echo "<script>alert(\" $address \");</script>";
        }
        else{
            echo "<script>";
            echo "window.location.replace(\"$address?success=2\");";
            echo "</script>";
        }
    }
    /*public function showCart(){
        $assets_url = ASSETS_URL;
        $cartHTML = "<h3 class=\"popover-title\">Recently added item(s)</h3><table class=\"table table-responsive table-border\"><tbody class=\"scrollContent\">";
        foreach ($_SESSION["cart"] as $cartItem) {
            $totalPerItem=$cartItem['price']*$cartItem['qty'];
            $subtotal+=$totalPerItem;
            $cartHTML   .=  "<tr>
                                <td class=\"cart-img\"><img src=\"" . $assets_url . "images/" . $cartItem['item_image_url'] . "\"></td>
                                <td class=\"font-size-td\">" . $cartItem['name'] . "<div class=\"last-item\">$" . $cartItem['price'] . ".00</div><div class=\"detail\">Qty : " . $cartItem['qty'] . "<br>Size : " . $cartItem['value'] . "</div>
                                <td class=\"td-width\"><div class=\"edit-popup\"></div></td>
                                <td class=\"td-width\"><a><div class=\"cancel-popup\" title=\"" . $cartItem['id'] . "\"></div></a></td>
                            </tr>";
        }
        $cartHTML   .=  "</tbody>
                        <tbody>
                            <tr>
                                <td colspan=\"2\" class=\"font-cart\">Cart Subtotal : </td><td colspan=\"2\"><div class=\"total last-item position-td\">$" . $subtotal . ".00</div></td>
                            </tr>
                        </tbody>
                    </table>
                    <div class=\"row btn-align\">
                        <div class=\"col-sm-12 col-xs-12\">
                            <a href=\"".  SITE_URL . "cart\" class=\"btn update-btn\">View Cart</a>
                        </div>
                    </div>";
        return $cartHTML;
    }*/
    public function addToCart(){
        $id=$_POST['itemId'];
        $address=$_SERVER['HTTP_REFERER'];
        if(!isset($id)){
            if(checkIfLogin()){
                $id=$_POST['id'];
                $qty=array('qty'=>$_POST['qty']);
                // echo json_encode($id);
                $getItemDescription=$this->headermodel->getItemDescription($id);
                foreach ($getItemDescription as $product) {}
                    // echo "<pre>";print_r($product);exit();
                if(empty($_SESSION["cart"])){
                        $i=1;
                        $_SESSION['cart'][$i++] = array_merge($product,$qty);
                }
                else{ 
                    $flag=0;
                    $idIndex=0;
                    foreach ($_SESSION["cart"] as $index => $v) {
                        if ($v['id'] == $id) {
                            $flag=1;
                            $idIndex=$index;
                            break;
                        }
                    }  
                    if($flag==0){
                        foreach ($_SESSION['cart'] as $i => $value){}
                        // $qty=array('qty'=>$qty);
                        $_SESSION['cart'][++$i] = array_merge($product,$qty);
                    }
                    else{
                        $_SESSION["cart"][$idIndex]['qty']+=$_POST['qty'];
                    }
                }
                $cartHTML=showCart();
                echo json_encode(array('status' => 1, 'msg' => 'Added to cart.','content'=>$cartHTML)); 
                // echo "<pre>";print_r($_SESSION["cart"]);exit();
            }
            else{
                echo json_encode(array('status' => 2, 'msg' => 'Login to add product in cart.')); 
            }
        }
        else{
            if(checkIfLogin()){
                $getItemDescription=$this->headermodel->getItemDescription($id);
                foreach ($getItemDescription as $product) {}
                // echo "<pre>";print_r($product);echo "exit";exit();
                if(empty($_SESSION["cart"])){
                    $i=1;
                    $qty=array('qty'=>1);
                    $_SESSION['cart'][$i++] = array_merge($product,$qty);
                }
                else{ 
                    $flag=0;
                    $idIndex=0;
                    foreach ($_SESSION["cart"] as $index => $v) {
                        if ($v['id'] == $id) {
                            $flag=1;
                            $idIndex=$index;
                            break;
                        }
                    }  
                    if($flag==0){
                        foreach ($_SESSION['cart'] as $i => $value){}
                        $qty=array('qty'=>1);
                        $_SESSION['cart'][++$i] = array_merge($product,$qty);
                    }
                    else{
                        ++$_SESSION["cart"][$idIndex]['qty'];
                    }
                }
                $cartHTML=showCart();
                echo json_encode(array('status' => 2, 'msg' => 'Added to cart.','content'=>$cartHTML)); 
                // echo "<pre>";print_r($_SESSION["cart"]);exit();
            }
            else{
                echo json_encode(array('status' => 1, 'msg' => 'Login to add product in cart.')); 
            }
        }
    }
}
?>