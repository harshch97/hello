<?php
error_reporting(0);
class Product extends BaseController {

    /**
     * @author Tatvasoft
     * Default method of Aboutus controller and load header,main content,footer view.
     *   
     */
    public function index() {
        $this->load_model('HeaderModel');
        $this->load_model('ProductModel');

        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $this->load_view('header', array('menuList' => $menuItemsList));
        $show_products['sub_category']=$this->productmodel->fetchSubcategory();
        $show_products['color']=$this->productmodel->fetchColor();
        $show_products['size']=$this->productmodel->fetchSize();
        $show_products['product']=$this->productmodel->fetchProducts();
        $this->load_view('user/product',$show_products);
        $this->load_view('footer');
    }
}