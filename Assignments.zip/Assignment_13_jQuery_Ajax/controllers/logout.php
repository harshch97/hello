<?php

class Logout extends BaseController {

    /**
     * @author Tatvasoft
     * Destroy all session values and redirect to home.
     *
     */
    public function index() {
        session_unset();
        session_destroy();
        $this->redirect();
    }

}
