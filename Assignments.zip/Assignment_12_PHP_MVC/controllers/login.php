<?php

class Login extends BaseController {

    /**
     * @author Tatvasoft
     * Default method of login Controller and check Authentication.
     * @params username/email and password 
     * @return validation message  
     */
    public function index() {
        // echo "here";exit;
        if (!checkIfLogin()) {

            $this->load_model("LoginModel");
            //echo "<pre>";print_r($_POST);exit;
            if ($this->loginmodel->authenticate($_POST['username'], $_POST['password'])) {
                echo json_encode(array('status' => 1, 'msg' => 'You are successfully logged-in.')); 
            } else {
                echo json_encode(array('status' => 0, 'msg' => 'Username or password is incorrect.')); 
            }
        } else {
            echo json_encode(array('status' => 2, 'msg' => 'You have already logged-in.')); 
        }
    }
    
}