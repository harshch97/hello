<?php
error_reporting(0);
class Aboutus extends BaseController {

    /**
     * @author Tatvasoft
     * Default method of Aboutus controller and load header,main content,footer view.
     *   
     */
    public function index() {
        $this->load_model('HeaderModel');

        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $this->load_view('header', array('menuList' => $menuItemsList));
        
        $this->load_view('user/aboutus');
        $this->load_view('footer');
    }
}