<?php
error_reporting(0);
class Home extends BaseController {

    /**
     * @author Tatvasoft
     * Default method of Home controller and load header,main content,footer view.
     *   
     */
    public function __construct(){
        $this->load_model('HeaderModel');
    }
    public function index() {

        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $this->load_view('header', array('menuList' => $menuItemsList));
        $show_products['product']=$this->headermodel->fetchProducts();
        $show_products['moreProducts']=$this->headermodel->fetchMoreProducts();
        
        $this->load_view('index',$show_products);
        $this->load_view('footer');
    }
    public function addSubscriber(){
        $address=$_SERVER['HTTP_REFERER'];
        $email=$_POST['email'];
        $success=$this->headermodel->addSubscriber($email);
        if($success){   
            $subject = "Newsletter Subscription";
            $txt = "Thank you for your Subscription!";
            $headers = 'From: krushiva.patel@internal.mail' . "\r\n";
            $headers .= 'Cc: krushiva.patel@internal.mail' . "\r\n";
            if(mail($email,$subject,$txt,$headers)){
                echo "<script>";
                echo "window.location.replace(\"$address?success=1\");";
                echo "</script>";
            }
            // echo "<script>alert(\" $address \");</script>";
        }
        else{
            echo "<script>";
            echo "window.location.replace(\"$address?success=2\");";
            echo "</script>";
        }
    }
}