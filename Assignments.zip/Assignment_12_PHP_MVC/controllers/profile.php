<?php
error_reporting(0);
class Profile extends BaseController {

    /**
     * @author Tatvasoft
     * Default method of Profile controller and load header,main content,footer view.
     *   
     */
    public function __construct(){
        $this->load_model('ProfileModel');
    }
    public function index() {
        $this->load_model('HeaderModel');

        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $this->load_view('header', array('menuList' => $menuItemsList));

        //Profile information
        
        $data['userDetail']=$this->profilemodel->getLoggedUserDetail(getLoginUserName());
        $data['countries']=$this->profilemodel->getAllCountry();
        if(!empty($data['userDetail'][0]['shipping_add_id'])){
            $data['shipping_address']=$this->profilemodel->getAddressDetail($data['userDetail'][0]['shipping_add_id']);
            $data['shipping_states']=$this->profilemodel->getStatesByCountryId($data['shipping_address'][0]['country_id']);
        }
        
        if(!empty($data['userDetail'][0]['billing_add_id'])){
            $data['billing_address']=$this->profilemodel->getAddressDetail($data['userDetail'][0]['billing_add_id']);
            $data['billing_states']=$this->profilemodel->getStatesByCountryId($data['billing_address'][0]['country_id']);
        }
            // echo "<pre>";
            // print_r($data['shipping_address']);exit();
        $this->load_view('user/profile',$data);
        $this->load_view('footer');
    }
    public function fetchState(){
        $this->load_model('ProfileModel');
        $id=$_POST['id'];
        $getState=$this->profilemodel->getStatesByCountryId($id);
        echo json_encode($getState);
    }
    public function updateProfile(){
        $address=$_SERVER['HTTP_REFERER'];
        if(empty($_POST['street'])){
            $userInfo=$this->profilemodel->updateUser($_POST);
            if($userInfo){
                echo "<script>";
                echo "alert('User information updated successfully');";
                echo "window.location.replace(\"$address\");";
                echo "</script>";
                $_SESSION['name']=$_POST['firstName'];
            }
            else{
                echo "<script>";
                echo "alert('Unable to update user information');";
                echo "window.location.replace(\"$address\");";
                echo "</script>";   
            }
        }
        else{
            $result=$this->profilemodel->updateUserAddress($_POST);
            echo "<script>";
            echo "alert('User information updated successfully');";
            echo "window.location.replace(\"$address\");";
            echo "</script>";
        }
    }
}