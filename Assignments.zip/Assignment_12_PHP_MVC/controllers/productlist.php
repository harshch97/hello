<?php
error_reporting(0);
class Productlist extends BaseController {

    /**
     * @author Tatvasoft
     * Default method of Aboutus controller and load header,main content,footer view.
     *   
     */
    public function __construct(){
        $this->load_model('ProductlistModel');
    }
    public function index($item_id) {
        $this->load_model('HeaderModel');

        $menuItemsList = array();
        $resultMenu['data']=$this->headermodel->fetchCategory();

        $i = 0;
        foreach ($resultMenu['data'] as $value) {
            $resultMenu['subCategory']=$this->headermodel->fetchCategoryByParentId($value['id']);

            $menuItemsList[$i][] = $value;
            $menuItemsList[$i][] = $resultMenu['subCategory'];
            $i++;
        }
        $data['size']=$this->productlistmodel->getSize();
        $data['sliderImages']=$this->productlistmodel->getImages($item_id);
        $data['reviewData']=$this->productlistmodel->getReviews($item_id);
        $data['imageDescription']=$this->productlistmodel->getImageDescription($data['sliderImages'][0]['item_id']);
        // echo "<pre>";print_r($data['reviewData']);exit();
        $this->load_view('header', array('menuList' => $menuItemsList));
        $this->load_view('user/productlist',$data);
        $this->load_view('footer');
        // echo $item_id;
    }
    public function addToWishList(){
        $item_id=$_POST['id'];
        $user_id=$_SESSION['user_id'];
        $wishList=$this->productlistmodel->addToWishList($item_id,$user_id);
        if($wishList==true)
        {
            echo json_encode($wishList);
        }
        else{
            echo json_encode(array('status' => 1, 'msg' => 'You have already added this item to wishlist.'));
        }
    }
    public function addReview(){
        $msg=$_POST['msg'];
        $item_id=$_POST['itemId'];
        $ratings=$_POST['ratings'];
        $user_id=$_SESSION['user_id'];
        // echo "$msg $item_id $ratings $user_id";
        $addReview=$this->productlistmodel->addReview($item_id,$user_id,$msg,$ratings);
        if($addReview==true)
        {
            echo json_encode($addReview);
        }
        else{
            echo json_encode(array('status' => 1, 'msg' => 'Unable to save your review.'));
        }
    }
}