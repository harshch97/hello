/* function Declaration - START */
function showLoginValidationError(msg) {
	$('.login_alert').removeClass('alert-success').addClass('alert-danger');
	$('.login_alert').css('display','block');
	$('.login_msg').text(msg);
	$('#loginForm .form-group').addClass('validation-error');
}
	
function showLoginSuccess(msg) {
	$('.login_alert').removeClass('alert-danger').addClass('alert-success');
	$('.login_alert').css('display','block');
	$('.login_msg').text(msg);
	$('#loginForm .form-group').removeClass('validation-error');
}
	
function loginAlert() {
	alert('You need to login first.');
}

function ajaxError() {
	alert('some error occured.Please try again or later.');
}

function getAlert(msg, alert_type) {
	return '<div class="alert alert-dismissible alert-'+alert_type+'" role="alert">'+
				'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
				'<i> <img src="'+assets_url+'images/'+alert_type+'.svg" alt="'+alert_type+'"></i> <span>'+ msg + '</span>'+
			'</div>';
}

function getReviewHtml(name, review, date) {
	return '<div class="review-detail">'+
				'<span>'+name+', '+date+' writes:</span>'+
				'<p>'+review+'</p>'+
			'</div>';
}
/* function Declaration - END */
	
$(document).ready(function() {

    // Fancybox
    $('.fancybox').fancybox({
        padding : 0,
        openEffect  : 'elastic'
    });

    //cart
    $(".add-to-cart").click(function() {
        $(this).toggleClass("active");
        $(".cart-wrap").slideToggle(500);
    })


    //Prevent Page Reload on all # links
    $("a[href='#']").click(function(e) {
        e.preventDefault();
    });

    $('.back-to-top').click(function () {
        $("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;
    });

    if($(window).width() < 768){
        $(".menu-link").click(function(){
            $(this).closest(".menu-item").toggleClass("active")
            $(this).closest(".menu-item").find(".sub-menu").slideToggle()
        })
    }

    $(window).scroll(function(e) {
        if($(window).scrollTop() > 200)
            $("body").addClass('top-arrow');
        else
            $("body").removeClass('top-arrow');
    });

    $(window).scroll(function(e) {
        if ($(window).scrollTop() > 0)
            $(".wrapper").addClass('small-header');
        else
            $(".wrapper").removeClass('small-header');
    });

    //search
    $(".search-link a").click(function() {
        $(this).closest(".search-link").toggleClass("active");
    });


    //placeholder

    $("[placeholder]").each(function() {
        $(this).attr("data-placeholder", this.placeholder);

        $(this).bind("focus", function() {
            this.placeholder = '';
        });
        $(this).bind("blur", function() {
            this.placeholder = $(this).attr("data-placeholder");
        });
    });



    // Slider
    var sync1 = $("#sync1");
    var sync2 = $("#sync2");

    sync1.owlCarousel({
        singleItem: true,
        slideSpeed: 1000,
        navigation: true,
        pagination: false,
        afterAction: syncPosition,
        responsiveRefreshRate: 200,
    });

    sync2.owlCarousel({
        items: 3,
        itemsDesktop: [1199, 3],
        itemsDesktopSmall: [979, 3],
        itemsTablet: [768, 3],
        itemsMobile: [479, 3],
        pagination: false,
        responsiveRefreshRate: 100,
        afterInit: function(el) {
            el.find(".owl-item").eq(0).addClass("synced");
        }
    });

    function syncPosition(el) {
        var current = this.currentItem;
        $("#sync2")
        .find(".owl-item")
        .removeClass("synced")
        .eq(current)
        .addClass("synced")
        if ($("#sync2").data("owlCarousel") !== undefined) {
            center(current)
        }

    }


    $("#sync2").on("click", ".owl-item", function(e) {
        e.preventDefault();
        var number = $(this).data("owlItem");
        sync1.trigger("owl.goTo", number);
    });

    function center(number) {
        var sync2visible = sync2.data("owlCarousel").owl.visibleItems;

        var num = number;
        var found = false;
        for (var i in sync2visible) {
            if (num === sync2visible[i]) {
                var found = true;
            }
        }

        if (found === false) {
            if (num > sync2visible[sync2visible.length - 1]) {
                sync2.trigger("owl.goTo", num - sync2visible.length + 2)
            } else {
                if (num - 1 === -1) {
                    num = 0;
                }
                sync2.trigger("owl.goTo", num);
            }
        } else if (num === sync2visible[sync2visible.length - 1]) {
            sync2.trigger("owl.goTo", sync2visible[1])
        } else if (num === sync2visible[0]) {
            sync2.trigger("owl.goTo", num - 1)
        }
    }


    //testimonial slider
    $(".testimonial-slider").owlCarousel({
        singleItem: true,
        slideSpeed: 1000,
        navigation: false,
        pagination: true,
        autoPlay: true
    });

    // Fastclick
    FastClick.attach(document.body);


    var sync1 = $(".sync1");
    var sync2 = $(".sync2");

    sync1.owlCarousel({
        autoplay: false,
        auto: false,
        singleItem: true,
        slideSpeed: 1000,
        navigation: false,
        pagination: false,
        afterAction: syncPosition,
        responsiveRefreshRate: 200,
    });

    sync2.owlCarousel({
        autoplay: false,
        auto: false,
        items: 4,
        itemsDesktop: [1199, 4],
        itemsDesktopSmall: [979, 3],
        itemsTablet: [768, 3],
        itemsMobile: [479, 3],
        pagination: false,
        navigation: true,
        responsiveRefreshRate: 100,
        afterInit: function(el) {
            el.find(".owl-item").eq(0).addClass("synced");
        }
    });

    function syncPosition(el) {
        var current = this.currentItem;
        $(".sync2")
        .find(".owl-item")
        .removeClass("synced")
        .eq(current)
        .addClass("synced")
        if ($(".sync2").data("owlCarousel") !== undefined) {
            center(current)
        }
    }

    $(".sync2").on("click", ".owl-item", function(e) {
        e.preventDefault();
        var number = $(this).data("owlItem");
        sync1.trigger("owl.goTo", number);
    });

    function center(number) {
        var sync2visible = sync2.data("owlCarousel").owl.visibleItems;
        var num = number;
        var found = false;
        for (var i in sync2visible) {
            if (num === sync2visible[i]) {
                var found = true;
            }
        }

        if (found === false) {
            if (num > sync2visible[sync2visible.length - 1]) {
                sync2.trigger("owl.goTo", num - sync2visible.length + 2)
            } else {
                if (num - 1 === -1) {
                    num = 0;
                }
                sync2.trigger("owl.goTo", num);
            }
        } else if (num === sync2visible[sync2visible.length - 1]) {
            sync2.trigger("owl.goTo", sync2visible[1])
        } else if (num === sync2visible[0]) {
            sync2.trigger("owl.goTo", num - 1)
        }

    }

    $(".owl-example1").owlCarousel({
        pagination: false,
        autoPlay: true,
        auto: true,
        center: true,
        loop: true,
        margin: 10,


    });

    $(".review-tag").click(function() {
        $(".review-open").slideToggle();
    });
	
	
	
	/* Handle login-form submisstion */
	$("#loginForm").submit(function(e){alert('here');
      e.preventDefault();
      var data = new FormData(this);
	  $('#login_btn').attr('disabled','disabled');
      $.ajax({
        type: 'post',
        url: site_url+'login',
        dataType: 'json',
        data: data,
        processData: false,
        contentType: false,
        success: function(response){
			$('#login_btn').removeAttr('disabled');	
          if(response.status == 0) {
			  showLoginValidationError(response.msg)
		  } else if(response.status == 1) {
			  showLoingSuccess(response.msg);
			  location.reload();
		  } else if(response.status == 2) {
			  $('.login_msg').text(response.msg);
			  location.reload();
		  }
          
        },
		error: function(){
			$('#login_btn').removeAttr('disabled');	
			ajaxError();
		}
      });
    });
	
	/* handle add-to-cart form submission */
	$('#add-to-cart').submit(function(e){
		e.preventDefault();
		if(user_id > 0) {
			//remove jquery submit handler
			$(this).off("submit");
			// submit form with redirect
			$(this).submit();
			return true;
		} else {
			loginAlert();
			return true;	
		}
	})
	
	/* star-rating click handle */
	var star_ratings = 0;
	$('.star_rating').click(function(e){
		star_ratings = $(this).data('star');
	})
	
	/* handle review-form submission */
	$('#review-form').submit(function(e){
		e.preventDefault();
		var review = $(this).find('textarea').val();
		var item = $(this).find('input[name="review-form[item_id]"]').val();
		
		$.ajax({
			type: 'post',
			url: site_url+'product/submitReview',
			dataType: 'json',
			data: {'review':review,'item':item,'ratings':star_ratings},
			success: function(response){
				if(response.status == 1) {
					$('.write-review').remove();
					$('#review-form').remove();
					$('.review_wrap').prepend(getReviewHtml(response.data.name, response.data.review, response.data.date));
				} else if (response.status == 2 || response.status == 3) {
					alert(response.msg);
				} else if (response.status == 0) {
					if(typeof response.validation_errors != 'undefined') {
						if(typeof response.validation_errors.review_text != 'undefined') {
							$('.review_text_error').text(response.validation_errors.review_text);
						} else {
							$('.review_text_error').text('');
						}
						if(typeof response.validation_errors.ratings != 'undefined') {
							$('.rating_error').text(response.validation_errors.ratings);
						} else {
							$('.rating_error').text('');
						}
					}
				}
			},error: function(){
				ajaxError();
			}
		});
	
	})
	
	
});

/* Add to whishlist */
function addTowhishlist(item_id, item_name) {
	
	if(user_id > 0) {
		
		$.ajax({
			type: 'post',
			url: site_url+'product/addToWhishList',
			dataType: 'json',
			data: {'item':item_id},
			success: function(response){
				
				if(response.status == 0) {
					alert('Not added to whishlist please try agin or later.');
				} else if(response.status == 1) {
					var alert_div = getAlert(item_name+' has been added to your whishlst', 'success');
					$('.shopping-wrap').html(alert_div);
					$('.whislisted').css('display','block');
					$('.link-wishlist').css('display','none');
					$('.back-to-top').click();
					
				} else if(response.status == 2) {
					alert('Item already added to whishlist.');
				} else if(response.status == 3) {
					alert('Item not found.');
				} else if(response.status == 4) {
					loginAlert();
				}
			},
			error: function(){
				
				ajaxError();
			}
		});
	} else {
		loginAlert();
	}
}

function editCartItem(id, ths) {
	//console.log(ths.style);
	var is_edit = $(ths).attr('data-edit');
	
	if(is_edit == 1) {
		$('.color_text'+id).css('display','none');
		$('.color_select'+id).css('display','block');
		$('.size_text'+id).css('display','none');
		$('.size_select'+id).css('display','block');
		$(ths).attr('data-edit',0);
	} else {
		$('.color_text'+id).css('display','block');
		$('.color_select'+id).css('display','none');
		$('.size_text'+id).css('display','block');
		$('.size_select'+id).css('display','none');
		$(ths).attr('data-edit',1);
	}
}
