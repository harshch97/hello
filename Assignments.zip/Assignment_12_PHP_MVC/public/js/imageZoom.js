$('#largeImage').elevateZoom({
	// zoomType: "inner",
	borderSize:1,
	responsive: true,
   	zoomType: "lens", 
   	lensSize:250,
   	lensShape:"round",
   	containLensZoom: true
}); 