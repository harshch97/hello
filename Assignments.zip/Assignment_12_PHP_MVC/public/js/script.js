$(document).ready(function(){
  	$("#cart").click(function(){
        $(".popover-data").slideToggle();
    });
    $("#stars li").click(function(){
    	$("#starVal").val(($(this).val()));
    	// alert($(this).val());
    });
    $("#reviewBtn").click(function(e){
    	var star=$("#starVal").val();
    	var msg=$("#message").val();
    	var id=$("#itemId").val();
    	var dataString="itemId=" + id + "&msg=" + msg + "&ratings=" + star;
    	// alert(dataString);
    	$.ajax({
	        type: 'POST',
	        url: site_url+'productlist/addReview',
	        data: dataString,
	       /* dataType : 'json',
	        encode : true,*/
	        success: function(response){
	        	alert("success : " + response);
	        	/*var review = $.parseJSON(response);
				$.each(review, function(i, val) {
					// alert(val.review_text);
					document.getElementById("itemname").innerHTML = val.name;
					document.getElementById("shortDesc").innerHTML = val.short_desc;
					document.getElementById("sku").innerHTML = val.sku;
					document.getElementById("price").innerHTML = val.price;
					document.getElementById("deliveryDesc").innerHTML = val.delivery_desc;
					document.getElementById("shippingDesc").innerHTML = val.shipping_desc;
					document.getElementById("sizeGuideDesc").innerHTML = val.sizeguide_desc;
					document.getElementById("productDesc").innerHTML = val.description;
				});*/
	        },
			error: function(response){
				alert("error : " + response);
			}
		});
      	e.preventDefault();
    });
    $('#wishListBtn').click(function(e){
    	var id=$("#itemId").val();
    	var dataString="id=" + id;
	    $.ajax({
	        type: 'POST',
	        url: site_url+'productlist/addToWishList',
	        data: dataString,
	        dataType : 'json',
	        encode : true,
	        success: function(response){
				var status=JSON.stringify(response);
	        	result = JSON.parse(status);

				// $("#wishList").slideDown(1000);
	        	if(result.status==1){
	        		alert("Already added");
	        	}
	        	else{
					$("#wishList").show();
	        	}
	        },
			error: function(response){
				alert(response);
			}
		});
      	e.preventDefault();
	});
	$("#cart").popover({
	    html: true, 
		content: function() {
          	return $('#popover-content').html();
        }
	});
	$('body').click(function(e) {
		if(e.target.className !== "cart" && e.target.className !== "cart-a")
		{
			$('#popover-content').slideUp();
		}
	});
	
	/*$('body').click(function(e) {
		if(e.target.className !== "search" && e.target.className !== "search1" && e.target.className !== "search-box")
		{
			$('.search-box').toggleClass('expanded');
		}
	});*/
	$('#more-product-btn').click(function () {
		if($('#more-products').hasClass('collapse in'))
		{
			$('#more-product-btn').val('More Products'); 
		}
		else
		{
			$('#more-product-btn').val('Less Products'); 
		}
	});
	$('#country_ship').change(function()
	{
		var id=$(this).val();
		var dataString = 'id='+ id;
		// alert(dataString);
		$.ajax
		({
			type: "POST",
			url: site_url+'profile/fetchState',
			data: dataString,
			cache: false,
			success: function(data)
			{
				// alert(data);
				$("#state").empty();
				var state = $.parseJSON(data);
				$.each(state, function(i, val) {
					$("#state").append("<option value='" + val.id + "'>" + val.name + "</option>");
				});
			},
			error: function(){
				alert('error');
			}
		});
	});
	$('#country_bill').change(function()
	{
		var id=$(this).val();
		var dataString = 'id='+ id;
		$.ajax
		({
			type: "POST",
			url: site_url+'profile/fetchState',
			data: dataString,
			cache: false,
			success: function(data)
			{
				var state_bill = $.parseJSON(data);
				$("#state_bill").empty();
				$.each(state_bill, function(i, val) {
					$("#state_bill").append("<option value='" + val.id + "'>" + val.name + "</option>");
				});
			},
			error: function(){
				alert('error');
			}
		});
	});
	// $('#country_ship').change();
	// $('#country_bill').change();
	$('#cart').click(function() {
   		$('#popover-content').show();
	});
	$('#popover-content').click(function(event){
	   	event.stopPropagation();
	});
	$('.search').click(function () {
      $('.search-box').toggleClass('expanded');
  	});
	$('.search1').click(function () {
      $('.search-box').toggleClass('expanded');
  	});
  	if ($("#billing_address").is(':checked')){
		$("#street").keyup(function(){
			$("#street_bill").val($("#street").val());
		});
		$("#city").keyup(function(){
			$("#city_bill").val($("#city").val());
		});
		$("#country_ship").change(function(){
			$("#country_bill").val($("#country_ship").val());
			$('#country_bill').change();
			// $('#country_ship').change();	
		});
		$("#state").change(function(){
			var $options = $("#state > option").clone();
			$('#state_bill').empty();
		  	$('#state_bill').append($options);
		  	$('#state_bill').val($('#state').val());
		});
	}
  	$("#billing_address").click(function(){
	    var checkBox=document.getElementById("billing_address").checked;
	    if(checkBox==true){
		 	var $options = $("#state > option").clone();
		  	$('#state_bill').empty();
		  	$('#state_bill').append($options);
		  	$('#state_bill').val($('#state').val());
		  	$('#street_bill').attr("readonly", true);
		  	$('#city_bill').attr("readonly", true);
		  	$('#country_bill').attr("readonly", true);
		  	$('#state_bill').attr("readonly", true);
		}
		else{
	  		// $('#state_bill').empty();
	  		$('#country_bill').val();
	  		$('#state_bill').val();
	  		$('#street_bill').attr("readonly", false);
		  	$('#city_bill').attr("readonly", false);
		  	$('#country_bill').attr("readonly", false);
		  	$('#state_bill').attr("readonly", false);
		}
	});

  	$('#testimonial-carousel').carousel({
    	pause: true, interval: 5000,
  	});
	$('#topBtn').click(function(){
	    $('body,html').animate({
				scrollTop: 0
			}, 800);
		return false;
	});
	// $(window).on('resize',function(){(window).reload();});
	$('#myCarousel').carousel({
    	interval: 5000,
  	});
	imgCarousel();
	$(window).on('resize',function(){
		// window.location=window.location;
		location.reload(true);
	});
	$('#thumbs img').click(function(){
		$('#largeImage').fadeOut(00);
	    $('#largeImage').attr('src',$(this).attr('src'));
	    $("#largeImage").data('zoom-image', $(this).data('zoom-image')).elevateZoom({
	  		borderSize:1,
			responsive: true,
   			zoomType: "lens",
   			lensShape:"round", 
   			containLensZoom: true
	    }); 
		$('#largeImage').fadeIn(1000);;
	    // $('#description').html($(this).attr('alt'));
	});
	/*$('#thumbs #selectImg').click(function(){
	    var id=$(this).attr('value');
		var dataString = 'id='+ id;
		// alert(id);
		$.ajax
		({
			type: "POST",
			url: site_url+'productlist/productDescription',
			data: dataString,
			cache: false,
			success: function(data)
			{
				// alert(data);
				var desc = $.parseJSON(data);
				$.each(desc, function(i, val) {
					// alert(val.sku);
					document.getElementById("itemname").innerHTML = val.name;
					document.getElementById("shortDesc").innerHTML = val.short_desc;
					document.getElementById("sku").innerHTML = val.sku;
					document.getElementById("price").innerHTML = val.price;
					document.getElementById("deliveryDesc").innerHTML = val.delivery_desc;
					document.getElementById("shippingDesc").innerHTML = val.shipping_desc;
					document.getElementById("sizeGuideDesc").innerHTML = val.sizeguide_desc;
					document.getElementById("productDesc").innerHTML = val.description;
				});
			},
			error: function(xhr){
				alert("ReadyState : " + xhr.readyState + " Status : " + xhr.status);
			}
		});
	});*/
	$('#stars li').on('mouseover', function(){
    	var onStar = parseInt($(this).data('value'), 10);
   
    	$(this).parent().children('li.star').each(function(e){
      		if (e < onStar) {
        		$(this).addClass('hover');
      		}
      		else {
        		$(this).removeClass('hover');
      		}
    	});
  	}).on('mouseout', function(){
	    $(this).parent().children('li.star').each(function(e){
	      	$(this).removeClass('hover');
	    });
  	});
  
	$('#stars li').on('click', function(){
		var onStar = parseInt($(this).data('value'), 10); 
		var stars = $(this).parent().children('li.star');

	    for (i = 0; i < stars.length; i++) {
	      	$(stars[i]).removeClass('selected');
	    }
	    for (i = 0; i < onStar; i++) {
	      	$(stars[i]).addClass('selected');
	    }
  	});
  	jQuery.validator.addMethod("lettersonly", function(value, element) {
	  	return this.optional(element) || /^[a-z]+$/i.test(value);
	}, "Letters only please"); 
  	/*jQuery.validator.addMethod("passwordValidate", function(value, element) {
	  	return this.optional(element);
	}, "Error"); */
  	/*jQuery.validator.addMethod("passwordValidate", function(value, element) {
	  	return jQuery.validator.methods.passwordValidate.call(this, value, element);
	}, "Error");*/ 
  	jQuery.validator.addMethod("phone_regex", function(value, element) {
	  	return this.optional(element) || /^\d{10}$/i.test(value);
	}, "Enter valid phone number"); 
  	jQuery.validator.addMethod("usmobile", function(value, element) {
	  	return this.optional(element) || /^[+]\d{1}[ ]\d{3}[-]\d{3}[-]\d{3}$/i.test(value) || /^[+]\d{2}[ ]\d{10}$/i.test(value);
	}, "Enter valid number"); 
	// jQuery.validator.addMethod("password_regex", function(value, element) {
 //  		return this.optional(element) || /^(?=.*\d)(?=.*[a-z])(?=.*[!@#$])(?=(.*[A-Z]{2}))(?!.*\s).{8,12}$/ig.test(value);
	// }, "Password must have TWO capital, at least one digit and one special characters");
  	$("form[name='loginForm']").validate({
    	rules: {
    		username:{required:true,lettersonly: true},
    		password:"required"
    		// confirm_password:{required:true,equalTo : "#password"},
    	},
    	messages:{
    		username:{required:"Please enter username!",lettersonly:"Please enter alphabets only"},
    		password:"Please enter password!"
    		// confirm_password:{required:"Please enter password again!",equalTo:"Field value does not match with password"}
    	},
    	submitHandler: function(form) {
     	 	form.submit();
     	 	// alert("Successfully logged in!");
    	}
	});
  	$("form[name='form1']").validate({
    	rules: {
    		street:"required",
    		city:"required",
    		country:"required",
    		state:"required"
    	},
    	messages:{
    		street:"Please select country!",
    		city:"Please select country!",
    		country:"Please select country!",
    		state:"Please select state!"
    	},
    	submitHandler: function(form) {
     	 	form.submit();
    	}
	});
  	$("form[name='registrationForm']").validate({
    	rules: {
    		username:{required:true,lettersonly: true},
    		gender:"required",
    		password:"required",
    		confirm_password:{required:true},
    		email:{required:true,email:true},
    		firstName:{required:true,lettersonly:true},
    		mobile:{required:true,usmobile:true},
    		lastName:{required:true,lettersonly:true},
    		phone:{phone_regex:true},
    		mandatory:"required"
    	},
    	messages:{
    		username:{required:"Please enter username!",lettersonly:"Please enter alphabets only"},
    		gender:"Please select one!",
    		password:{required:"Please enter password!"},
    		confirm_password:{required:"Please enter password again!"},
    		email:{required:"Please enter email address",email:"Please enter valid email!"},
    		firstName:{required:"Please enter first name",lettersonly:"Please enter alphabets only"},
    		mobile:{required:"Please enter mobile number"},
    		lastName:{required:"Please enter last name",lettersonly:"Please enter alphabets only"},
    		mandatory:"Please agree with terms and mandatory!",
		    errorElement : 'label',
		    errorLabelContainer: '.errorMsg'
    	},
    	submitHandler: function(form) {
     	 	form.submit();
     	 	// alert("Successfully Registered!");
    	}
	});
	$("#login_btn").click(function(e){
      	$.ajax({
	        type: 'POST',
	        url: site_url+'login',
	        data: $('#loginForm').serialize(),
	        dataType : 'json',
	        encode : true,
	        success: function(response){
	        	// alert(JSON.stringify(response));
				window.location = site_url+"home";
	        },
			error: function(response){
				console.log(response);
			}
		});
      	e.preventDefault();
    });
});

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("topBtn").style.display = "block";
    } else {
        document.getElementById("topBtn").style.display = "none";
    }
}
function imgCarousel(){
	$('.img-carousel .item').each(function(){
	  	var next = $(this).next();
	  	if (!next.length) {
	    	next = $(this).siblings(':first');
	  	}
	  	next.children(':first-child').clone().appendTo($(this));
	  	if ($(window).width() < 768) {//alert('here');
		  	for (var i=0;i<1;i++) {
		    	next=next.next();
		    	if (!next.length) {
		    		next = $(this).siblings(':first');
		  		}
		    	next.children(':first-child').clone().appendTo($(this));
		  	}
		}
		else{
			for (var i=0;i<2;i++) {
		    	next=next.next();
		    	if (!next.length) {
		    		next = $(this).siblings(':first');
		  		}
		    	next.children(':first-child').clone().appendTo($(this));
		  	}
		}
	});
}
function passwordValidate(password){
	// alert(password);
	var password = document.registrationForm.password;
	var capitalRegex="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	var digitRegex="0123456789";
	var charRegex="$!@#";
	var capital_count = 0; 
	var digit_count = 0;
	var character_count = 0;
	for(var x = 0; x < password.length ; x++)
	{
	    if (capitalRegex.indexOf(password[x]) !== -1)
	    {
			capital_count += 1;
	    }
	    else if(digitRegex.indexOf(password[x]) !== -1){
	    	digit_count += 1;
	    }
	    else if(charRegex.indexOf(password[x]) !== -1){
	    	character_count += 1;
	    }
	}
	if(capital_count==2){
		if(digit_count>0){
			if( character_count>0){
				document.getElementById("password_error").innerHTML = "";
			}
			else{
				document.getElementById("password_error").innerHTML = "Password should be valid.";
				document.registrationForm.password.focus();
				return false;
			}
		}
		else{
			document.getElementById("password_error").innerHTML = "Password should be valid.";
			document.registrationForm.password.focus();
			return false;
		}
	}
	else{
		document.getElementById("password_error").innerHTML = "Password should be valid.";
		document.registrationForm.password.focus();
		return false;
	}
}
/*function loginValidation(){
	var username = document.loginForm.username;
	var password = document.loginForm.password;
	var confirm_password = document.loginForm.confirm_password;
	if(username.value.length==0){
		alert("Username should be filled.");
		username.focus();
		return false;
	}
	if(password.value.length==0){
		alert("Password should be filled.");
		password.focus();
		return false;
	}
	if(confirm_password.value.length==0){
		alert("Password should be filled.");
		password.focus();
		return false;
	}
	if((password.value)!=(confirm_password.value)){
		alert("Confirm Password should be same as Password.");
		document.loginForm.confirm_password.focus();
		return false;
	}
	else{
		alert('Successfully logged in!');
	}
}*/
function registrationValidation(){
	var username = document.registrationForm.username;
	var password = document.registrationForm.password.value;
	var terms = document.registrationForm.mandatory;
	var fname = document.registrationForm.firstName;
	var lname = document.registrationForm.lastName;
	var mobile = document.registrationForm.mobile;
	var email = document.registrationForm.email;
	var phone = document.registrationForm.phone;
	var male = document.registrationForm.male;
	var female = document.registrationForm.female;
	var select = document.registrationForm.select;
	var opt1 = document.registrationForm.opt1;
	var opt2 = document.registrationForm.opt2;
	var opt3 = document.registrationForm.opt3;
	var other = document.registrationForm.interest_other;
	var atpos = (email.value).indexOf("@");
    var dotpos = (email.value).lastIndexOf(".");
	var fname_regex=/^[a-z\s]+$/;
	var phone_regex=/^\d{10}$/;
	var mobile_us_regex=/^[+]\d{1}[ ]\d{3}[-]\d{3}[-]\d{3}$/;
	var mobile_india_regex=/^[+]\d{2}[ ]\d{10}$/;
	var pswdRegex=/^[A-Z]{2}[0-9]$/;
	if(username.value.length==0){
		document.getElementById("username_error").innerHTML = "Username is required.";
		username.focus();
		return false;
	}
	else{
		document.getElementById("username_error").innerHTML = "";
	}
	if(username.value.length<8){
		document.getElementById("username_error").innerHTML = "Username length should be 8 or greater.";
		username.focus();
		return false;
	}
	else{
		document.getElementById("username_error").innerHTML = "";
	}
	if(male.checked==false && female.checked==false){
		document.getElementById("gender_error").innerHTML = "Gender should be selected.";
		return false;
	}
	else{
		document.getElementById("gender_error").innerHTML = "";
	}
	if(password.length==0){
		document.getElementById("password_error").innerHTML = "Password should be filled.";
		document.registrationForm.password.focus();
		return false;
	}
	if(!(password.match(pswdRegex))){
		document.getElementById("password_error").innerHTML = "Password should be valid.";
		document.registrationForm.password.focus();
		return false;
	}
	else{
		document.getElementById("password_error").innerHTML = "";
	}
	if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length) {
		document.getElementById("email_error").innerHTML = "Please enter valid email.";
		email.focus();
        return false;
    }
    else{
		document.getElementById("email_error").innerHTML = "";
    }
	if(fname.value.length==0){
		document.getElementById("fname_error").innerHTML = "First Name should be filled.";
		fname.focus();
		return false;
	}
	else{
		document.getElementById("fname_error").innerHTML = "";
	}
	if(!((fname.value).match(fname_regex))){
		document.getElementById("fname_error").innerHTML = "First Name should be alphabets only.";
		fname.focus();
		return false;
	}
	else
	{
		document.getElementById("fname_error").innerHTML = "";
	}
	if(mobile.value.length==0){
		document.getElementById("mobile_error").innerHTML = "Mobile number should be filled";
		mobile.focus();
		return false;
	}
	if(!((mobile.value).match(mobile_us_regex)) && !((mobile.value).match(mobile_india_regex))){
		document.getElementById("mobile_error").innerHTML = "Mobile format should be correct.";
		mobile.focus();
		return false;
	}
	else{
		document.getElementById("mobile_error").innerHTML = "";
	}
	if(lname.value.length==0){
		document.getElementById("lname_error").innerHTML = "Last Name should be filled.";
		lname.focus();
		return false;
	}
	else{
		document.getElementById("lname_error").innerHTML = "";
	}
	if(!((lname.value).match(fname_regex))){
		document.getElementById("lname_error").innerHTML = "Last Name should be alphabets only.";
		lname.focus();
		return false;
	}
	else{
		document.getElementById("lname_error").innerHTML = "";
	}
	if(phone.value.length!=0){
		if(!(phone.value).match(phone_regex)){
			document.getElementById("phone_error").innerHTML = "Phone field only contain numeric value";
			phone.focus();
			return false;
		}
	}
	else{
		document.getElementById("phone_error").innerHTML = "";
	}
	if(select.checked==false && opt1.checked==false && opt2.checked==false && opt3.checked==false && other.checked==false){
		alert('You haven\'t checked on any of the interest');
		return false;
	}
	if(terms.checked==false){
		alert('You forgot to check terms and condition!!');
		return false;
	}
}
function billingValidation(){
	var street=document.getElementById("street");
	var city=document.getElementById("city");
	var country = document.getElementById("country_ship");
	var country_name = country.options[country.selectedIndex].value;
	var state=document.getElementById("state");
	var state_name = state.options[state.selectedIndex].value;
	var street_bill=document.getElementById("street_bill");
	var city_bill=document.getElementById("city_bill");
	var country_bill=document.getElementById("country_bill");
	var state_bill=document.getElementById("state_bill");
	if(street.value.length==0){
		document.getElementById("street_error").innerHTML = "Street should be filled.";
		street.focus();
		return false;
	}
	else{
		document.getElementById("street_error").innerHTML = "";
	}
	if(city.value.length==0){
		document.getElementById("city_error").innerHTML = "City should be filled.";
		city.focus();
		return false;
	}
	else{
		document.getElementById("city_error").innerHTML = "";
	}
	if(country_name.length==0){
		document.getElementById("country_error").innerHTML = "Country should be selected.";
		country.focus();
		return false;
	}
	else{
		document.getElementById("country_error").innerHTML = "";
	}
	if(state_name.length==0){
		document.getElementById("state_error").innerHTML = "State should be selected.";
		state.focus();
		return false;
	}
	else{
		document.getElementById("state_error").innerHTML = "";
	}
}
/*function displayPrice(){
	var qty=document.getElementById("qty").value;
	var price=qty*120;
	document.getElementById("price").innerHTML = "$" + price + ".00";
}*/
function showInputBox(){
	var checkboxes=document.getElementsByName("interest");
	if(document.getElementById("other").checked){
		document.getElementById("other_tb").style.display = "block";
		for(var i = 0; i < checkboxes.length; i++) 
	    {
	        checkboxes[i].disabled = true;
	    }
	}
	else{
		document.getElementById("other_tb").style.display = "none";
		for(var i = 0; i < checkboxes.length; i++) 
	    {
	        checkboxes[i].disabled = false;
	    }
	}
}
function select_all(select){
	var checkboxes=document.getElementsByName('interest');
	if(select.checked==true)
	{
	    for(var i = 0; i < checkboxes.length; i++) 
	    {
	        checkboxes[i].checked = true;
	        document.getElementById("other").disabled = true;
	    }
	}
	else
	{
		for(var i = 0; i < checkboxes.length; i++) 
		{
			checkboxes[i].checked = false;
	        document.getElementById("other").disabled = false;
	    }
	}
}
function addToCart(){
	var amount=document.getElementById("price").innerHTML;
	var add=confirm("Are you sure you want to purchase this product? Your total bill amount is " + amount + ".");
	if(add){
		/*alert("Added to cart");*/
		window.location.href = 'cart.php'; 
	}
	else{
		alert("You pressed cancel!");
	}
}
function clearAllValue(){
	var confirmClear=confirm("Are you sure you want to clear all values?");
	if(confirmClear){
		location.reload();
		return true;
	}
	else
	{
		return false;
	}
}
function changeSubtotal(){
	var price=document.getElementsByName("price_js");
	var qty=document.getElementsByName("qty_js");
	var total=0;
	for(var i=0;i<price.length;i++){
		document.getElementsByName("subtotal_js")[i].innerHTML = price[i].textContent*qty[i].value;	
		total=total+price[i].textContent*qty[i].value;	
	}
	document.querySelector('#subtotal').innerHTML = total;
	document.querySelector('#total').innerHTML = total;

}
function fill_address(){
	var street=document.getElementById("street");
	var city=document.getElementById("city");
	var country = document.getElementById("country_ship").selectedIndex;
	var state=document.getElementById("state").selectedIndex;
	var street_bill=document.getElementById("street_bill");
	var city_bill=document.getElementById("city_bill");
	var country_bill=document.getElementById("country_bill");
	var state_bill=document.getElementById("state_bill");
	var billing_address=document.getElementById("billing_address");
	if(billing_address.checked){
		street_bill.value=street.value;
		city_bill.value=city.value;
		country_bill.selectedIndex=country;
		// alert(country);
		state_bill.selectedIndex=state;
		// alert(state + " " + state_bill.selectedIndex);
	}
	else{
		// street_bill.value="";
		// city_bill.value="";
		// country_bill.selectedIndex=0;
		// state_bill.selectedIndex=0;
	}
}