How to setup project :-
	Step - 1  Open Include/config.php file and set proper value for SITE_NAME, SITE_URL and SITE_PATH as per your working dir.
	Step - 2   Configure database variables on same file. 	