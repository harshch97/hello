<?php
error_reporting(0);
$success=$_GET['success'];
if($success==1){
	$success_msg="Thank you for your subscription.";
}
elseif($success==2){
	$success_msg="You are already subscribed.";
}
?>
<style type="text/css">
.success-message
{
	visibility: <?php echo (isset($success))?'visible':'hidden'?>;
}
</style>
<body>
	<div class="footer">
		<div class="container">
			<div class="form-container">
				<form class="form-inline" action="<?php echo SITE_URL; ?>home/addSubscriber" method="post">
					<div class="row">
					    <div class="form-group col-sm-4 col-lg-4">
					    	<div class="col-sm-12">&nbsp;</div>
					    	<div class="col-sm-12">
					      		<p>Subscribe for Newsletter</p>
					      	</div>
					    </div>
					    <div class="form-group col-sm-6 col-lg-6">
					    	<div class="col-sm-12 success-message"><?php echo $success_msg; ?>&nbsp;</div>
					      	<input type="email" class="form-control input-box" name="email" placeholder="Enter your email address" required="">
					    </div>
					    <div class="form-group col-sm-2 col-lg-2">
					    	<div class="col-sm-12">&nbsp;</div>
					    	<div class="col-sm-12">
					      		<input type="submit" class="btn footer-btn-style center-block" value="SIGN IN">
					      	</div>
					    </div>
					</div>
				</form>
			</div>
			<div class="footer-menu">
				<div class="container-fluid">
					<ul class="nav navbar-nav navbar-xs">
				        <li class="active menu"><a href="<?php echo SITE_URL; ?>">Home</a></li>
				       	<li><a href="<?php echo SITE_URL; ?>aboutus">About us</a></li>
				       	<?php
						if(!isset($_SESSION['name']) || $_SESSION['name']==''){
							?>
				      		<li><a href="<?php echo SITE_URL; ?>register">Register</a></li>
				      		<?php
						}
						else{
							?>
				      		<li><a href="<?php echo SITE_URL; ?>profile">Profile</a></li>
							<?php
						}
						?>
				      	<li><a href="<?php echo SITE_URL; ?>contact">Contact us</a></li>
				    </ul>
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="col-sm-12 footer-data">
					<p>&copy; 2017 eShopper online store. All rights reserved.</p>
				</div>
			</div>
		</div>
	</div>
</body>