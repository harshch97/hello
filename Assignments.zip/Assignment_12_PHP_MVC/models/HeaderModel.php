<?php

class HeaderModel extends basemodel
{
	public function fetchCategory(){
		$selectMenuItems="SELECT * FROM category WHERE parent_id=0";
		$result=$this->_db->query($selectMenuItems);
		return $this->getResultArray($result);
	}
	public function fetchCategoryByParentId($parent_id){
		$selectMenuItems="SELECT * FROM category WHERE parent_id=".$parent_id;
		$result=$this->_db->query($selectMenuItems);
		return $this->getResultArray($result);
	}
	public function fetchProducts(){
		$getProducts="SELECT `item_options`.id,`item`.name,`item`.price,`item_images`.item_image_url,`attribute_options`.value
					FROM `item_options` 
					LEFT JOIN `item` ON `item_options`.item_id=`item`.id 
					LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
					LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id 
					WHERE `item_images`.is_primary=1 
					LIMIT 8";
		$result=$this->_db->query($getProducts);
		return $this->getResultArray($result);
	}
	public function fetchMoreProducts(){
		$selectProduct="SELECT `item_options`.id,`item`.name,`item`.price,`item_images`.item_image_url,`attribute_options`.value
					FROM `item_options` 
					LEFT JOIN `item` ON `item_options`.item_id=`item`.id 
					LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
					LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id 
					WHERE `item_images`.is_primary=1";
		$resultItem=$this->_db->query($selectProduct);
		$numRows=$resultItem->num_rows;
		// echo $numRows;
		if($numRows>8){
			$moreProducts="SELECT `item_options`.id,`item`.name,`item`.price,`item_images`.item_image_url,`attribute_options`.value
					FROM `item_options` 
					LEFT JOIN `item` ON `item_options`.item_id=`item`.id 
					LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
					LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id 
					WHERE `item_images`.is_primary=1 LIMIT $numRows OFFSET 8";
			$resultMoreProducts=$this->_db->query($moreProducts);
			return $this->getResultArray($resultMoreProducts);
		}
	}
	public function addSubscriber($email){
		$uniqueEmail="SELECT `email` FROM `newsletter_subscriber` WHERE `email`='$email'";
		if($this->_db->query($uniqueEmail)->num_rows==0){
			$addSubscriber="INSERT INTO `newsletter_subscriber`(`email`) VALUES ('$email')";
			if($this->_db->query($addSubscriber)){
				return true;
			}
			else{
				return false;
			}
		}
		else{
			return false;
		}
	}
	public function getItemDescription($id){
		$selectProduct="SELECT `item_options`.id,`item`.name,`item_images`.item_image_url,`item`.price,`attribute_options`.value,(SELECT `attribute_options`.value FROM `item`
					LEFT JOIN `item_options` ON `item_options`.item_id=`item`.id 
					LEFT JOIN `attribute_options` ON `item`.color_id=`attribute_options`.id 
           			WHERE `item`.color_id=`attribute_options`.id AND`item_options`.id=$id)  as color
					FROM `item_options` 
					LEFT JOIN `item` ON `item_options`.item_id=`item`.id 
                    LEFT JOIN `item_images` ON `item`.id=`item_images`.item_id 
					LEFT JOIN `attribute_options` ON `item_options`.ao_id=`attribute_options`.id
					WHERE `item_options`.id=$id AND `item_images`.is_primary=1";
		$result=$this->_db->query($selectProduct);
		// echo "<pre>";print_r($this->getResultArray($result));
		return $this->getResultArray($result);
	}	
}
?>