<?php

class HeaderModel extends basemodel
{
	public function fetchCategory(){
		$selectMenuItems="SELECT * FROM category WHERE parent_id=0";
		$result=$this->_db->query($selectMenuItems);
		return $this->getResultArray($result);
	}
	public function fetchCategoryByParentId($parent_id){
		$selectMenuItems="SELECT * FROM category WHERE parent_id=".$parent_id;
		$result=$this->_db->query($selectMenuItems);
		return $this->getResultArray($result);
	}
	public function fetchProducts(){
		$getProducts="SELECT * FROM `item` LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id LIMIT 8";
		$result=$this->_db->query($getProducts);
		return $this->getResultArray($result);
	}
	public function fetchMoreProducts(){
		$selectProduct="SELECT * FROM `item_images`";
		$resultItem=$this->_db->query($selectProduct);
		$numRows=$resultItem->num_rows;
		// echo $numRows;
		if($numRows>8){
			$moreProducts="SELECT * FROM `item` LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id LIMIT $numRows OFFSET 8";
			$resultMoreProducts=$this->_db->query($moreProducts);
			return $this->getResultArray($resultMoreProducts);
		}
	}
	public function addSubscriber($email){
		$uniqueEmail="SELECT `email` FROM `newsletter_subscriber` WHERE `email`='$email'";
		if($this->_db->query($uniqueEmail)->num_rows==0){
			$addSubscriber="INSERT INTO `newsletter_subscriber`(`email`) VALUES ('$email')";
			if($this->_db->query($addSubscriber)){
				return true;
			}
			else{
				return false;
			}
		}
		else{
			return false;
		}
	}
}
?>