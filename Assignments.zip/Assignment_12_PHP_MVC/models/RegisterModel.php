<?php

class RegisterModel extends basemodel {
    /* Table which is mapped to current model */

    private $_table = 'user';

    /**
     * @author Tatvasoft
     * Check unique email id .
     * 
     * @params email id
     * @return true if email id is already exist else false.
     */
    public function checkEmailExist($email) {
        $sql = "SELECT id FROM " . $this->_table . " where email='" . $email . "'";

        $result = $this->_db->query($sql);

        if ($result->num_rows > 0) {

            return true;
        } else {

            return false;
        }
    }

    /**
     * @author Tatvasoft
     * Check unique username.
     * 
     * @params username
     * @return true if username is already exist else false.
     */
    public function checkUsernameExist($username) {
        $sql = "SELECT id FROM " . $this->_table . " where username='" . $username . "'";

        $result = $this->_db->query($sql);

        if ($result->num_rows > 0) {

            return true;
        } else {

            return false;
        }
    }

    /**
     * @author Tatvasoft
     * Check if user has read terms and condition.
     * 
     * @params is_agree field
     * @return true if user has not read terms and condition with validation message else false.
     */
    public function isAgreed($data) {

        if (!isset($data['is_agree'])) {
            $this->validationError['is_agree'] = 'Please agree terms and Condition Before Procedure further';
        }

        if (empty($data['is_agree'])) {
            $this->validationError['is_agree'] = 'Please agree terms and Condition Before Procedure further';
        }
        if (empty($this->validationError)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * @author Tatvasoft
     * validate user data before save in database.
     * 
     * @params user information
     * @return true if any of user data is not valid  or already exist in system else false.
     */
    public function validate($data) {
        $this->processInput($data);

        if ($this->data['firstName'] == '') {
            $this->validationError['firstName'] = 'Name is required';
        }

        if ($this->data['mobile'] == '') {
            $this->validationError['mobile'] = 'Mobile No. is required';
        } elseif (!is_numeric($this->data['mobile'])) {
            $this->validationError['mobile'] = 'Only Digit Allow.';
        } elseif (strlen($this->data['mobile']) > 10) {
            $this->validationError['mobile'] = 'Mobile no can not be more then 10 digits';
        } elseif (strlen($this->data['mobile']) < 10) {
            $this->validationError['mobile'] = 'Enter 10 digits of Mobile number';
        }

        if ($this->data['phone'] != '' && !is_numeric($this->data['phone'])) {
            $this->validationError['phone'] = 'Only Digit Allow.';
        } elseif ($this->data['phone'] != '' && strlen($this->data['phone']) > 10) {
            $this->validationError['phone'] = 'Phone number can not be more then 10 digits';
        } elseif ($this->data['phone'] != '' && strlen($this->data['phone']) < 10) {
            $this->validationError['phone'] = 'Enter 10 digits of Phone number';
        }

        if ($this->data['username'] == '') {
            $this->validationError['username'] = 'Username is required';
        } elseif ($this->checkUsernameExist($this->data['username'])) {
            $this->validationError['username'] = 'Username is already exist.';
        }
        if ($this->data['email'] == '') {

            $this->validationError['email'] = 'Email-id is required';
        } elseif (filter_var($this->data['email'], FILTER_VALIDATE_EMAIL) === false) {

            $this->validationError['email'] = 'Email-id is not valid.';
        } elseif ($this->checkEmailExist($this->data['email'])) {

            $this->validationError['email'] = 'Email-id already registered.';
        }

        if ($this->data['password'] == '') {

            $this->validationError['password'] = 'Password is required';
        } elseif (strlen($this->data['password']) < 8) {

            $this->validationError['password'] = 'Please enter password at lease 8 characters.';
        } elseif ($this->data['password'] != '' && !preg_match('/^(?=.*[A-Z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,}$/', $this->data['password'])) {
            $this->validationError['password'] = 'Password must contain one number , two Uppercase Alphabet and one special character.';
        }
//                elseif ($this->data['password'] != $this->data['re-password']) {
//			
//			$this->validationError['password'] = 'Password and re-entered password do not match.';
//			
//		}

        if (!in_array($this->data['gender'], array('0', '1'))) {
            $this->validationError['gender'] = 'Please select valid gender.';
        }

        if (empty($this->validationError)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * @author Tatvasoft
     * Insert record in database .
     * 
     * @params user information.
     * @return true if record insert successfully else false.
     */
    public function insert($data) {
        // if ($this->isAgreed($data)) {
        //     if ($this->validate($data)) {
        $uname=$data['username'];
        $email=$data['email'];
        $uniqueEmail="SELECT `username`,`email` FROM `user` WHERE `username`='$uname' OR `email`='$email'";
        // echo "$uniqueEmail";exit();
        if($this->_db->query($uniqueEmail)->num_rows==0){
            $sql = "INSERT INTO " . $this->_table . " (username, firstname,lastname, email, gender, password,mobile_number, phone_number,is_active) VALUES ('" . $data['username'] . "', '" . $data['firstName'] . "','" . $data['lastName'] . "', '" . $data['email'] . "', '" . $data['gender'] . "', '" . md5($data['password']) . "','" . $data['mobile'] . "','" . $data['phone'] . "',1)";
            if ($this->_db->query($sql) === TRUE) 
            {
                $email=$data['email'];
                $subject = "eShopping Registration";
                $txt = "Welcome, " . $fname . " " . $lname . "\r\n";
                $txt .= "\t" . "You are successfully registered!";
                $headers = 'From: krushiva.patel@internal.mail' . "\r\n";
                $headers .= 'Cc: krushiva.patel@internal.mail' . "\r\n";
                if(mail($email,$subject,$txt,$headers)) 
                {
                    return true;
                } 
                else{
                    return false;
                }
            } 
            else {
                return false;
            }
        }
        else{
            echo "<script>alert('Username or email id already exist');</script>";
        }
    }

}
