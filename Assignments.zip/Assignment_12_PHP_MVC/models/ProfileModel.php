<?php
/**
* 
*/
class ProfileModel extends basemodel
{
	public function getLoggedUserDetail($user){
		// echo $user;
		$getUser="SELECT * FROM user WHERE firstname='$user'";
		$result=$this->_db->query($getUser);
		return $this->getResultArray($result);
	}
	public function getAllCountry(){
		$getCountry="SELECT * FROM country";
		$result=$this->_db->query($getCountry);
		return $this->getResultArray($result);
	}
	public function getStatesByCountryId($id){
		$getStateFromCountry="SELECT id,name FROM state WHERE country_id=$id";
		$result=$this->_db->query($getStateFromCountry);
		return $this->getResultArray($result);
	}
	public function getAddressDetail($id){
		$getAddress="SELECT  `address`.street,`address`.city,`address`.state_id,`state`.id,`state`.country_id,`country`.id FROM `address` LEFT JOIN `state` ON `address`.state_id=`state`.id LEFT JOIN `country` ON `state`.country_id=`country`.id WHERE `address`.id=$id";
		$result=$this->_db->query($getAddress);
		return $this->getResultArray($result);
	}
	public function updateUser($user){
		$username=$user['username'];
		$fname=$user['firstName'];
		$lname=$user['lastName'];
		$gender=$user['gender'];
		$email=$user['email'];
		$mobile=$user['mobile'];
		$phone=$user['phone'];

		$uniqEmail="SELECT `email` FROM `user` WHERE `email`='$email' AND `username`!='$username'";
		if($this->_db->query($uniqEmail)->num_rows==0){
			$updateUser="UPDATE `user` SET `firstname`='$fname',`lastname`='$lname',`gender`='$gender',`email`='$email',`mobile_number`='$mobile',`phone_number`='$phone' WHERE `username`='$username'";
			if($this->_db->query($updateUser)){
				return true;
			}
			else{
				return false;
			}
		}
		else{
			echo "<script>alert('Username or email id already exist');</script>";
		}
	}
	public function updateUserAddress($user){
		$username=$user['username'];
		$fname=$user['firstName'];
		$lname=$user['lastName'];
		$gender=$user['gender'];
		$email=$user['email'];
		$mobile=$user['mobile'];
		$phone=$user['phone'];
		$street=$user['street'];
	    $city=$user['city'];
	    $state=$user['state'];
	    $street_bill=$user['street_bill'];
	    $city_bill=$user['city_bill'];
	    $state_bill=$user['state_bill'];
	    if(isset($_POST['billing_address'])){
			$flag=1;
		}
		else{
			$flag=0;
		}
		// echo $flag;exit();
		$uniqEmail="SELECT `email` FROM `user` WHERE `email`='$email' AND `username`!='$username'";
		if($this->_db->query($uniqEmail)->num_rows==0){
			$selectUser="SELECT `shipping_add_id`,`billing_add_id` FROM `user` WHERE `username`='$username' ";
			$result=$this->_db->query($selectUser);
			if($result){
				while($address=mysqli_fetch_assoc($result)){
					$ship_id=$address['shipping_add_id'];
					$bill_id=$address['billing_add_id'];
					if(empty($ship_id)){
						$insertShipAddress="INSERT INTO `address`(`street`, `city`, `state_id`) VALUES ('$street','$city',$state)";
						if($this->_db->query($insertShipAddress)){
							$userShipId=mysqli_insert_id($this->_db);
							$updateShippingAddress="UPDATE user SET `firstname`='$fname',`lastname`='$lname',`gender`='$gender',`email`='$email',`mobile_number`='$mobile',`phone_number`='$phone',`shipping_add_id`=$userShipId WHERE `username`='$username'";
							$this->_db->query($updateShippingAddress);
						}
					}
					else{
						$updateAddress="UPDATE `address` SET `street`='$street',`city`='$city',`state_id`=$state WHERE id=$ship_id";
						$this->_db->query($updateAddress);
					}
					if(empty($bill_id)){
						$insertBillAddress="INSERT INTO `address`(`street`, `city`, `state_id`) VALUES ('$street_bill','$city_bill',$state_bill)";
						if($this->_db->query($insertBillAddress)){
							$userBillId=mysqli_insert_id($this->_db);
							$updateBillingAddress="UPDATE user SET `firstname`='$fname',`lastname`='$lname',`gender`='$gender',`email`='$email',`mobile_number`='$mobile',`phone_number`='$phone',`billing_add_id`=$userBillId,`flag`=$flag WHERE `username`='$username'";
							$this->_db->query($updateBillingAddress);
						}
					}
					else{
						$updateAddress="UPDATE `address` SET `street`='$street_bill',`city`='$city_bill',`state_id`=$state_bill WHERE id=$bill_id";
						if($this->_db->query($updateAddress))
						{
							$updateFlag="UPDATE user SET `firstname`='$fname',`lastname`='$lname',`gender`='$gender',`email`='$email',`mobile_number`='$mobile',`phone_number`='$phone',`flag`=$flag WHERE `username`='$username'";
							$this->_db->query($updateFlag);
						}
					}
				}
			}
		}
		else{
			echo "<script>alert('Username or email id already exist');</script>";
		}
	}
}
?>