<?php
/**
* 
*/
class ProductlistModel extends basemodel
{
	public function getSize() 
	{
		$getSize="SELECT * FROM attribute_options WHERE attribute_id=1";
		$result=$this->_db->query($getSize);
		return $this->getResultArray($result);
	}
	public function getImages($item_id) 
	{
		$getImages="SELECT * FROM item_images WHERE item_id=$item_id";
		$result=$this->_db->query($getImages);
		return $this->getResultArray($result);
	}
	public function getReviews($item_id) 
	{
		$getReviews="SELECT `item_review`.review_text,`item_review`.ratings,`item_review`.review_date,`user`.firstname,`item`.name FROM `item_review` LEFT JOIN `item` ON `item`.id=`item_review`.item_id LEFT JOIN `user` ON `item_review`.user_id=`user`.id WHERE `item_review`.item_id=$item_id ORDER BY `item_review`.id DESC";
		$result=$this->_db->query($getReviews);
		return $this->getResultArray($result);
	}
	public function getImageDescription($item_id) 
	{
		$getImageDescription="SELECT * FROM item WHERE id=$item_id";
		$result=$this->_db->query($getImageDescription);
		return $this->getResultArray($result);
	}
	public function addToWishList($item_id,$user_id) 
	{
		$uniqWishList="SELECT item_id,user_id FROM wishlist WHERE item_id=$item_id AND user_id=$user_id";
		if($this->_db->query($uniqWishList)->num_rows==0){
			$addToWishList="INSERT INTO `wishlist`(`item_id`, `user_id`) VALUES ($item_id,$user_id)";
			$result=$this->_db->query($addToWishList);
			return $result;
		}
		else{
			return false;
		}
	}
	public function addReview($item_id,$user_id,$msg,$ratings){
		$date=date("Y-m-d H:i:s");
		$uniqReview="SELECT item_id,user_id FROM item_review WHERE item_id=$item_id AND user_id=$user_id";
		if($this->_db->query($uniqReview)->num_rows==0){
			$addReview="INSERT INTO `item_review`(`user_id`, `item_id`, `review_text`, `ratings`, `review_date`) VALUES ($user_id,$item_id,'$msg',$ratings,'$date')";
			if($this->_db->query($addReview)){
				$selectReviews="SELECT `item_review`.review_text,`item_review`.ratings,`item_review`.review_date,`user`.firstname,`item`.name FROM `item_review` LEFT JOIN `item` ON `item`.id=`item_review`.item_id LEFT JOIN `user` ON `item_review`.user_id=`user`.id WHERE `item_review`.item_id=$item_id ORDER BY `item_review`.id DESC";
				// echo $selectReviews;exit();
				$result=$this->_db->query($selectReviews);
				return $this->getResultArray($result);
			}
			else{
				return false;
			}
		}
		else{
			return false;
		}
	}
}
?>