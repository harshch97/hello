<?php

class ProductModel extends basemodel
{
	public function fetchProducts(){
		$getProducts="SELECT * FROM `item` LEFT JOIN `item_images` ON `item_images`.item_id=`item`.id";
		$result=$this->_db->query($getProducts);
		return $this->getResultArray($result);
	}
}
?>